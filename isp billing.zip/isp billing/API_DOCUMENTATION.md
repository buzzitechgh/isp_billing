# ISP Billing System API Documentation

## Table of Contents

1. [Authentication](#authentication)
2. [Users](#users)
3. [Plans](#plans)
4. [Transactions](#transactions)
5. [Sessions](#sessions)
6. [Routers](#routers)
7. [Vouchers](#vouchers)
8. [Notifications](#notifications)
9. [Settings](#settings)
10. [Reports](#reports)
11. [Roles](#roles)
12. [Dashboard](#dashboard)

## Authentication

### Register

```
POST /api/auth/register
```

**Request Body:**

```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "password123",
  "phone": "+1234567890",
  "address": "123 Main St, City, Country"
}
```

**Response:**

```json
{
  "success": true,
  "message": "User registered successfully",
  "data": {
    "user": {
      "id": 1,
      "name": "John Doe",
      "email": "john@example.com",
      "role": "customer",
      "status": "active",
      "created_at": "2023-01-01T00:00:00.000Z"
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

### Login

```
POST /api/auth/login
```

**Request Body:**

```json
{
  "email": "john@example.com",
  "password": "password123"
}
```

**Response:**

```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "user": {
      "id": 1,
      "name": "John Doe",
      "email": "john@example.com",
      "role": "customer",
      "status": "active",
      "created_at": "2023-01-01T00:00:00.000Z"
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

### Logout

```
POST /api/auth/logout
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "message": "Logged out successfully"
}
```

### Get Current User

```
GET /api/auth/me
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "data": {
    "user": {
      "id": 1,
      "name": "John Doe",
      "email": "john@example.com",
      "phone": "+1234567890",
      "address": "123 Main St, City, Country",
      "role": "customer",
      "status": "active",
      "created_at": "2023-01-01T00:00:00.000Z",
      "updated_at": "2023-01-01T00:00:00.000Z"
    }
  }
}
```

### Change Password

```
POST /api/auth/change-password
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "current_password": "password123",
  "new_password": "newpassword123",
  "confirm_password": "newpassword123"
}
```

**Response:**

```json
{
  "success": true,
  "message": "Password changed successfully"
}
```

### Request Password Reset

```
POST /api/auth/forgot-password
```

**Request Body:**

```json
{
  "email": "john@example.com"
}
```

**Response:**

```json
{
  "success": true,
  "message": "Password reset link sent to your email"
}
```

### Reset Password

```
POST /api/auth/reset-password
```

**Request Body:**

```json
{
  "token": "reset-token-from-email",
  "new_password": "newpassword123",
  "confirm_password": "newpassword123"
}
```

**Response:**

```json
{
  "success": true,
  "message": "Password reset successful"
}
```

## Users

### Get All Users

```
GET /api/users
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- `page`: Page number (default: 1)
- `limit`: Number of items per page (default: 10)
- `search`: Search term for name or email
- `role`: Filter by role (admin, manager, customer)
- `status`: Filter by status (active, inactive)
- `sort_by`: Field to sort by (created_at, name, email, etc.)
- `sort_order`: Sort order (asc, desc)

**Response:**

```json
{
  "success": true,
  "data": {
    "users": [
      {
        "id": 1,
        "name": "John Doe",
        "email": "john@example.com",
        "role": "customer",
        "status": "active",
        "created_at": "2023-01-01T00:00:00.000Z",
        "updated_at": "2023-01-01T00:00:00.000Z"
      }
    ],
    "pagination": {
      "total": 50,
      "page": 1,
      "limit": 10,
      "total_pages": 5
    }
  }
}
```

### Get User by ID

```
GET /api/users/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "data": {
    "user": {
      "id": 1,
      "name": "John Doe",
      "email": "john@example.com",
      "phone": "+1234567890",
      "address": "123 Main St, City, Country",
      "role": "customer",
      "status": "active",
      "created_at": "2023-01-01T00:00:00.000Z",
      "updated_at": "2023-01-01T00:00:00.000Z"
    }
  }
}
```

### Create User

```
POST /api/users
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "name": "Jane Smith",
  "email": "jane@example.com",
  "password": "password123",
  "phone": "+1987654321",
  "address": "456 Oak St, City, Country",
  "role": "manager"
}
```

**Response:**

```json
{
  "success": true,
  "message": "User created successfully",
  "data": {
    "user": {
      "id": 2,
      "name": "Jane Smith",
      "email": "jane@example.com",
      "role": "manager",
      "status": "active",
      "created_at": "2023-01-02T00:00:00.000Z"
    }
  }
}
```

### Update User

```
PUT /api/users/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "name": "Jane Smith Updated",
  "phone": "+1987654322",
  "address": "789 Pine St, City, Country"
}
```

**Response:**

```json
{
  "success": true,
  "message": "User updated successfully",
  "data": {
    "user": {
      "id": 2,
      "name": "Jane Smith Updated",
      "email": "jane@example.com",
      "phone": "+1987654322",
      "address": "789 Pine St, City, Country",
      "role": "manager",
      "status": "active",
      "updated_at": "2023-01-03T00:00:00.000Z"
    }
  }
}
```

### Delete User

```
DELETE /api/users/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "message": "User deleted successfully"
}
```

### Change User Status

```
PATCH /api/users/:id/status
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "status": "inactive"
}
```

**Response:**

```json
{
  "success": true,
  "message": "User status updated successfully",
  "data": {
    "user": {
      "id": 2,
      "status": "inactive",
      "updated_at": "2023-01-04T00:00:00.000Z"
    }
  }
}
```

### Change User Role

```
PATCH /api/users/:id/role
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "role": "admin"
}
```

**Response:**

```json
{
  "success": true,
  "message": "User role updated successfully",
  "data": {
    "user": {
      "id": 2,
      "role": "admin",
      "updated_at": "2023-01-05T00:00:00.000Z"
    }
  }
}
```

## Plans

### Get All Plans

```
GET /api/plans
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- `page`: Page number (default: 1)
- `limit`: Number of items per page (default: 10)
- `search`: Search term for name or description
- `status`: Filter by status (active, inactive)
- `sort_by`: Field to sort by (created_at, name, price, etc.)
- `sort_order`: Sort order (asc, desc)

**Response:**

```json
{
  "success": true,
  "data": {
    "plans": [
      {
        "id": 1,
        "name": "Basic Plan",
        "description": "Basic internet plan for small households",
        "price": 29.99,
        "currency": "USD",
        "billing_cycle": "monthly",
        "data_limit": 100,
        "data_unit": "GB",
        "bandwidth": 10,
        "bandwidth_unit": "Mbps",
        "features": ["Basic Support", "Standard Installation"],
        "status": "active",
        "created_at": "2023-01-01T00:00:00.000Z",
        "updated_at": "2023-01-01T00:00:00.000Z"
      }
    ],
    "pagination": {
      "total": 5,
      "page": 1,
      "limit": 10,
      "total_pages": 1
    }
  }
}
```

### Get Plan by ID

```
GET /api/plans/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "data": {
    "plan": {
      "id": 1,
      "name": "Basic Plan",
      "description": "Basic internet plan for small households",
      "price": 29.99,
      "currency": "USD",
      "billing_cycle": "monthly",
      "data_limit": 100,
      "data_unit": "GB",
      "bandwidth": 10,
      "bandwidth_unit": "Mbps",
      "features": ["Basic Support", "Standard Installation"],
      "status": "active",
      "created_at": "2023-01-01T00:00:00.000Z",
      "updated_at": "2023-01-01T00:00:00.000Z"
    }
  }
}
```

### Create Plan

```
POST /api/plans
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "name": "Premium Plan",
  "description": "High-speed internet for power users",
  "price": 59.99,
  "currency": "USD",
  "billing_cycle": "monthly",
  "data_limit": 500,
  "data_unit": "GB",
  "bandwidth": 100,
  "bandwidth_unit": "Mbps",
  "features": ["24/7 Premium Support", "Free Installation", "Static IP"]
}
```

**Response:**

```json
{
  "success": true,
  "message": "Plan created successfully",
  "data": {
    "plan": {
      "id": 2,
      "name": "Premium Plan",
      "description": "High-speed internet for power users",
      "price": 59.99,
      "currency": "USD",
      "billing_cycle": "monthly",
      "data_limit": 500,
      "data_unit": "GB",
      "bandwidth": 100,
      "bandwidth_unit": "Mbps",
      "features": ["24/7 Premium Support", "Free Installation", "Static IP"],
      "status": "active",
      "created_at": "2023-01-02T00:00:00.000Z",
      "updated_at": "2023-01-02T00:00:00.000Z"
    }
  }
}
```

### Update Plan

```
PUT /api/plans/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "name": "Premium Plus Plan",
  "description": "Enhanced high-speed internet for power users",
  "price": 69.99,
  "features": ["24/7 Premium Support", "Free Installation", "Static IP", "Priority Bandwidth"]
}
```

**Response:**

```json
{
  "success": true,
  "message": "Plan updated successfully",
  "data": {
    "plan": {
      "id": 2,
      "name": "Premium Plus Plan",
      "description": "Enhanced high-speed internet for power users",
      "price": 69.99,
      "currency": "USD",
      "billing_cycle": "monthly",
      "data_limit": 500,
      "data_unit": "GB",
      "bandwidth": 100,
      "bandwidth_unit": "Mbps",
      "features": ["24/7 Premium Support", "Free Installation", "Static IP", "Priority Bandwidth"],
      "status": "active",
      "updated_at": "2023-01-03T00:00:00.000Z"
    }
  }
}
```

### Delete Plan

```
DELETE /api/plans/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "message": "Plan deleted successfully"
}
```

### Change Plan Status

```
PATCH /api/plans/:id/status
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "status": "inactive"
}
```

**Response:**

```json
{
  "success": true,
  "message": "Plan status updated successfully",
  "data": {
    "plan": {
      "id": 2,
      "status": "inactive",
      "updated_at": "2023-01-04T00:00:00.000Z"
    }
  }
}
```

## Transactions

### Get All Transactions

```
GET /api/transactions
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- `page`: Page number (default: 1)
- `limit`: Number of items per page (default: 10)
- `search`: Search term for reference or description
- `status`: Filter by status (successful, pending, failed)
- `payment_method`: Filter by payment method (card, bank_transfer, cash, etc.)
- `start_date`: Filter transactions from this date (YYYY-MM-DD)
- `end_date`: Filter transactions until this date (YYYY-MM-DD)
- `sort_by`: Field to sort by (created_at, amount, etc.)
- `sort_order`: Sort order (asc, desc)

**Response:**

```json
{
  "success": true,
  "data": {
    "transactions": [
      {
        "id": 1,
        "user_id": 1,
        "amount": 59.99,
        "currency": "USD",
        "payment_method": "card",
        "status": "successful",
        "reference": "TRX12345",
        "description": "Payment for Premium Plan",
        "metadata": {
          "plan_id": 2,
          "card_last4": "4242"
        },
        "created_at": "2023-01-01T00:00:00.000Z",
        "updated_at": "2023-01-01T00:00:00.000Z"
      }
    ],
    "pagination": {
      "total": 50,
      "page": 1,
      "limit": 10,
      "total_pages": 5
    }
  }
}
```

### Get Transaction by ID

```
GET /api/transactions/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "data": {
    "transaction": {
      "id": 1,
      "user_id": 1,
      "amount": 59.99,
      "currency": "USD",
      "payment_method": "card",
      "status": "successful",
      "reference": "TRX12345",
      "description": "Payment for Premium Plan",
      "metadata": {
        "plan_id": 2,
        "card_last4": "4242"
      },
      "created_at": "2023-01-01T00:00:00.000Z",
      "updated_at": "2023-01-01T00:00:00.000Z"
    }
  }
}
```

### Create Transaction

```
POST /api/transactions
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "user_id": 1,
  "amount": 59.99,
  "currency": "USD",
  "payment_method": "card",
  "status": "successful",
  "reference": "TRX12345",
  "description": "Payment for Premium Plan",
  "metadata": {
    "plan_id": 2,
    "card_last4": "4242"
  }
}
```

**Response:**

```json
{
  "success": true,
  "message": "Transaction created successfully",
  "data": {
    "transaction": {
      "id": 1,
      "user_id": 1,
      "amount": 59.99,
      "currency": "USD",
      "payment_method": "card",
      "status": "successful",
      "reference": "TRX12345",
      "description": "Payment for Premium Plan",
      "metadata": {
        "plan_id": 2,
        "card_last4": "4242"
      },
      "created_at": "2023-01-01T00:00:00.000Z",
      "updated_at": "2023-01-01T00:00:00.000Z"
    }
  }
}
```

### Update Transaction

```
PUT /api/transactions/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "status": "failed",
  "description": "Payment failed due to insufficient funds",
  "metadata": {
    "error_code": "INSUFFICIENT_FUNDS",
    "attempt": 2
  }
}
```

**Response:**

```json
{
  "success": true,
  "message": "Transaction updated successfully",
  "data": {
    "id": 1,
    "user_id": 1,
    "amount": 59.99,
    "currency": "USD",
    "payment_method": "card",
    "status": "failed",
    "reference": "TRX12345",
    "description": "Payment failed due to insufficient funds",
    "metadata": {
      "plan_id": 2,
      "card_last4": "4242",
      "error_code": "INSUFFICIENT_FUNDS",
      "attempt": 2
    },
    "updated_at": "2023-01-02T00:00:00.000Z"
  }
}
```

### Delete Transaction

```
DELETE /api/transactions/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "message": "Transaction deleted successfully"
}
```

### Get User Transactions

```
GET /api/users/:id/transactions
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- `page`: Page number (default: 1)
- `limit`: Number of items per page (default: 10)
- `status`: Filter by status (successful, pending, failed)
- `start_date`: Filter transactions from this date (YYYY-MM-DD)
- `end_date`: Filter transactions until this date (YYYY-MM-DD)
- `sort_by`: Field to sort by (created_at, amount, etc.)
- `sort_order`: Sort order (asc, desc)

**Response:**

```json
{
  "success": true,
  "data": {
    "transactions": [
      {
        "id": 1,
        "user_id": 1,
        "amount": 59.99,
        "currency": "USD",
        "payment_method": "card",
        "status": "successful",
        "reference": "TRX12345",
        "description": "Payment for Premium Plan",
        "metadata": {
          "plan_id": 2,
          "card_last4": "4242"
        },
        "created_at": "2023-01-01T00:00:00.000Z",
        "updated_at": "2023-01-01T00:00:00.000Z"
      }
    ],
    "pagination": {
      "total": 5,
      "page": 1,
      "limit": 10,
      "total_pages": 1
    }
  }
}
```

### Initiate Payment

```
POST /api/transactions/initiate-payment
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "user_id": 1,
  "amount": 59.99,
  "currency": "USD",
  "payment_method": "card",
  "description": "Payment for Premium Plan",
  "metadata": {
    "plan_id": 2
  },
  "return_url": "https://example.com/payment/success",
  "cancel_url": "https://example.com/payment/cancel"
}
```

**Response:**

```json
{
  "success": true,
  "message": "Payment initiated successfully",
  "data": {
    "transaction_id": 1,
    "payment_url": "https://payment-gateway.com/checkout/12345",
    "reference": "TRX12345"
  }
}
```

### Verify Payment

```
GET /api/transactions/verify/:reference
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "data": {
    "verified": true,
    "transaction": {
      "id": 1,
      "user_id": 1,
      "amount": 59.99,
      "currency": "USD",
      "payment_method": "card",
      "status": "successful",
      "reference": "TRX12345",
      "description": "Payment for Premium Plan",
      "metadata": {
        "plan_id": 2,
        "card_last4": "4242"
      },
      "created_at": "2023-01-01T00:00:00.000Z",
      "updated_at": "2023-01-01T00:00:00.000Z"
    }
  }
}
```

## Sessions

### Get All Sessions

```
GET /api/sessions
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- `page`: Page number (default: 1)
- `limit`: Number of items per page (default: 10)
- `user_id`: Filter by user ID
- `router_id`: Filter by router ID
- `status`: Filter by status (active, ended)
- `start_date`: Filter sessions from this date (YYYY-MM-DD)
- `end_date`: Filter sessions until this date (YYYY-MM-DD)
- `sort_by`: Field to sort by (created_at, download, upload, etc.)
- `sort_order`: Sort order (asc, desc)

**Response:**

```json
{
  "success": true,
  "data": {
    "sessions": [
      {
        "id": 1,
        "user_id": 1,
        "router_id": 2,
        "ip_address": "192.168.1.100",
        "mac_address": "00:1A:2B:3C:4D:5E",
        "start_time": "2023-01-01T10:00:00.000Z",
        "end_time": "2023-01-01T12:00:00.000Z",
        "duration": 7200,
        "download": 1024,
        "upload": 256,
        "status": "ended",
        "created_at": "2023-01-01T10:00:00.000Z",
        "updated_at": "2023-01-01T12:00:00.000Z",
        "user": {
          "id": 1,
          "name": "John Doe",
          "email": "john@example.com"
        },
        "router": {
          "id": 2,
          "name": "Main Office Router",
          "location": "Main Office"
        }
      }
    ],
    "pagination": {
      "total": 50,
      "page": 1,
      "limit": 10,
      "total_pages": 5
    }
  }
}
```

### Get Session by ID

```
GET /api/sessions/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "data": {
    "session": {
      "id": 1,
      "user_id": 1,
      "router_id": 2,
      "ip_address": "192.168.1.100",
      "mac_address": "00:1A:2B:3C:4D:5E",
      "start_time": "2023-01-01T10:00:00.000Z",
      "end_time": "2023-01-01T12:00:00.000Z",
      "duration": 7200,
      "download": 1024,
      "upload": 256,
      "status": "ended",
      "created_at": "2023-01-01T10:00:00.000Z",
      "updated_at": "2023-01-01T12:00:00.000Z",
      "user": {
        "id": 1,
        "name": "John Doe",
        "email": "john@example.com"
      },
      "router": {
        "id": 2,
        "name": "Main Office Router",
        "location": "Main Office"
      }
    }
  }
}
```

### Get User Sessions

```
GET /api/users/:id/sessions
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- `page`: Page number (default: 1)
- `limit`: Number of items per page (default: 10)
- `status`: Filter by status (active, ended)
- `start_date`: Filter sessions from this date (YYYY-MM-DD)
- `end_date`: Filter sessions until this date (YYYY-MM-DD)
- `sort_by`: Field to sort by (created_at, download, upload, etc.)
- `sort_order`: Sort order (asc, desc)

**Response:**

```json
{
  "success": true,
  "data": {
    "sessions": [
      {
        "id": 1,
        "user_id": 1,
        "router_id": 2,
        "ip_address": "192.168.1.100",
        "mac_address": "00:1A:2B:3C:4D:5E",
        "start_time": "2023-01-01T10:00:00.000Z",
        "end_time": "2023-01-01T12:00:00.000Z",
        "duration": 7200,
        "download": 1024,
        "upload": 256,
        "status": "ended",
        "created_at": "2023-01-01T10:00:00.000Z",
        "updated_at": "2023-01-01T12:00:00.000Z",
        "router": {
          "id": 2,
          "name": "Main Office Router",
          "location": "Main Office"
        }
      }
    ],
    "pagination": {
      "total": 20,
      "page": 1,
      "limit": 10,
      "total_pages": 2
    }
  }
}
```

### Create Session

```
POST /api/sessions
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "user_id": 1,
  "router_id": 2,
  "ip_address": "192.168.1.100",
  "mac_address": "00:1A:2B:3C:4D:5E"
}
```

**Response:**

```json
{
  "success": true,
  "message": "Session created successfully",
  "data": {
    "session": {
      "id": 2,
      "user_id": 1,
      "router_id": 2,
      "ip_address": "192.168.1.100",
      "mac_address": "00:1A:2B:3C:4D:5E",
      "start_time": "2023-01-02T10:00:00.000Z",
      "status": "active",
      "created_at": "2023-01-02T10:00:00.000Z",
      "updated_at": "2023-01-02T10:00:00.000Z"
    }
  }
}
```

### End Session

```
PATCH /api/sessions/:id/end
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "download": 1024,
  "upload": 256
}
```

**Response:**

```json
{
  "success": true,
  "message": "Session ended successfully",
  "data": {
    "session": {
      "id": 2,
      "end_time": "2023-01-02T12:00:00.000Z",
      "duration": 7200,
      "download": 1024,
      "upload": 256,
      "status": "ended",
      "updated_at": "2023-01-02T12:00:00.000Z"
    }
  }
}
```

### Delete Session

```
DELETE /api/sessions/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "message": "Session deleted successfully"
}
```

### Get Session Statistics

```
GET /api/sessions/statistics
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- `user_id`: Filter by user ID
- `router_id`: Filter by router ID
- `start_date`: Filter sessions from this date (YYYY-MM-DD)
- `end_date`: Filter sessions until this date (YYYY-MM-DD)
- `group_by`: Group statistics by (day, week, month, user, router)

**Response:**

```json
{
  "success": true,
  "data": {
    "total_sessions": 100,
    "active_sessions": 10,
    "total_duration": 720000,
    "total_download": 102400,
    "total_upload": 25600,
    "total_data": 128000,
    "average_session_duration": 7200,
    "daily_sessions": [
      {
        "date": "2023-01-01",
        "count": 25,
        "download": 25600,
        "upload": 6400
      },
      {
        "date": "2023-01-02",
        "count": 30,
        "download": 30720,
        "upload": 7680
      }
    ],
    "sessions_by_router": [
      {
        "router_id": 1,
        "router_name": "Main Office Router",
        "count": 60,
        "download": 61440,
        "upload": 15360
      },
      {
        "router_id": 2,
        "router_name": "Branch Office Router",
        "count": 40,
        "download": 40960,
        "upload": 10240
      }
    ]
  }
}
```

## Routers

### Get All Routers

```
GET /api/routers
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- `page`: Page number (default: 1)
- `limit`: Number of items per page (default: 10)
- `search`: Search term for name or location
- `status`: Filter by status (active, inactive)
- `sort_by`: Field to sort by (created_at, name, location, etc.)
- `sort_order`: Sort order (asc, desc)

**Response:**

```json
{
  "success": true,
  "data": {
    "routers": [
      {
        "id": 1,
        "name": "Main Office Router",
        "model": "Mikrotik RB4011",
        "ip_address": "192.168.1.1",
        "mac_address": "00:0C:29:AA:BB:CC",
        "location": "Main Office",
        "status": "active",
        "api_username": "admin",
        "nas_identifier": "MO-RB4011",
        "created_at": "2023-01-01T00:00:00.000Z",
        "updated_at": "2023-01-01T00:00:00.000Z",
        "active_sessions": 15
      }
    ],
    "pagination": {
      "total": 5,
      "page": 1,
      "limit": 10,
      "total_pages": 1
    }
  }
}
```

### Get Router by ID

```
GET /api/routers/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "data": {
    "router": {
      "id": 1,
      "name": "Main Office Router",
      "model": "Mikrotik RB4011",
      "ip_address": "192.168.1.1",
      "mac_address": "00:0C:29:AA:BB:CC",
      "location": "Main Office",
      "status": "active",
      "api_username": "admin",
      "nas_identifier": "MO-RB4011",
      "created_at": "2023-01-01T00:00:00.000Z",
      "updated_at": "2023-01-01T00:00:00.000Z",
      "active_sessions": 15,
      "total_sessions": 150
    }
  }
}
```

### Create Router

```
POST /api/routers
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "name": "Branch Office Router",
  "model": "Mikrotik hAP ac2",
  "ip_address": "192.168.2.1",
  "mac_address": "00:0C:29:DD:EE:FF",
  "location": "Branch Office",
  "api_username": "admin",
  "api_password": "secure_password",
  "nas_identifier": "BO-HAP-AC2"
}
```

**Response:**

```json
{
  "success": true,
  "message": "Router created successfully",
  "data": {
    "router": {
      "id": 2,
      "name": "Branch Office Router",
      "model": "Mikrotik hAP ac2",
      "ip_address": "192.168.2.1",
      "mac_address": "00:0C:29:DD:EE:FF",
      "location": "Branch Office",
      "status": "active",
      "api_username": "admin",
      "nas_identifier": "BO-HAP-AC2",
      "created_at": "2023-01-02T00:00:00.000Z",
      "updated_at": "2023-01-02T00:00:00.000Z"
    }
  }
}
```

### Update Router

```
PUT /api/routers/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "name": "Updated Branch Office Router",
  "location": "New Branch Office",
  "api_password": "new_secure_password"
}
```

**Response:**

```json
{
  "success": true,
  "message": "Router updated successfully",
  "data": {
    "router": {
      "id": 2,
      "name": "Updated Branch Office Router",
      "model": "Mikrotik hAP ac2",
      "ip_address": "192.168.2.1",
      "mac_address": "00:0C:29:DD:EE:FF",
      "location": "New Branch Office",
      "status": "active",
      "api_username": "admin",
      "nas_identifier": "BO-HAP-AC2",
      "updated_at": "2023-01-03T00:00:00.000Z"
    }
  }
}
```

### Delete Router

```
DELETE /api/routers/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "message": "Router deleted successfully"
}
```

### Change Router Status

```
PATCH /api/routers/:id/status
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "status": "inactive"
}
```

**Response:**

```json
{
  "success": true,
  "message": "Router status updated successfully",
  "data": {
    "router": {
      "id": 2,
      "status": "inactive",
      "updated_at": "2023-01-04T00:00:00.000Z"
    }
  }
}
```

### Get Router Sessions

```
GET /api/routers/:id/sessions
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- `page`: Page number (default: 1)
- `limit`: Number of items per page (default: 10)
- `status`: Filter by status (active, ended)
- `start_date`: Filter sessions from this date (YYYY-MM-DD)
- `end_date`: Filter sessions until this date (YYYY-MM-DD)
- `sort_by`: Field to sort by (created_at, download, upload, etc.)
- `sort_order`: Sort order (asc, desc)

**Response:**

```json
{
  "success": true,
  "data": {
    "sessions": [
      {
        "id": 1,
        "user_id": 1,
        "router_id": 2,
        "ip_address": "192.168.1.100",
        "mac_address": "00:1A:2B:3C:4D:5E",
        "start_time": "2023-01-01T10:00:00.000Z",
        "end_time": "2023-01-01T12:00:00.000Z",
        "duration": 7200,
        "download": 1024,
        "upload": 256,
        "status": "ended",
        "created_at": "2023-01-01T10:00:00.000Z",
        "updated_at": "2023-01-01T12:00:00.000Z",
        "user": {
          "id": 1,
          "name": "John Doe",
          "email": "john@example.com"
        }
      }
    ],
    "pagination": {
      "total": 30,
      "page": 1,
      "limit": 10,
      "total_pages": 3
    }
  }
}
```

### Sync Router

```
POST /api/routers/:id/sync
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "message": "Router synchronized successfully",
  "data": {
    "active_sessions": 15,
    "synced_at": "2023-01-05T00:00:00.000Z"
  }
}
```

## Vouchers

### Get All Vouchers

```
GET /api/vouchers
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- `page`: Page number (default: 1)
- `limit`: Number of items per page (default: 10)
- `search`: Search term for code or batch name
- `status`: Filter by status (active, used, expired, inactive)
- `batch_name`: Filter by batch name
- `sort_by`: Field to sort by (created_at, code, expiry_date, etc.)
- `sort_order`: Sort order (asc, desc)

**Response:**

```json
{
  "success": true,
  "data": {
    "vouchers": [
      {
        "id": 1,
        "code": "ABC123XYZ",
        "batch_name": "January Promo",
        "plan_id": 2,
        "duration": 30,
        "duration_unit": "days",
        "data_limit": 100,
        "data_unit": "GB",
        "price": 29.99,
        "currency": "USD",
        "status": "active",
        "created_by": 1,
        "redeemed_by": null,
        "redeemed_at": null,
        "expiry_date": "2023-12-31T23:59:59.000Z",
        "created_at": "2023-01-01T00:00:00.000Z",
        "updated_at": "2023-01-01T00:00:00.000Z",
        "plan": {
          "id": 2,
          "name": "Premium Plan"
        }
      }
    ],
    "pagination": {
      "total": 100,
      "page": 1,
      "limit": 10,
      "total_pages": 10
    }
  }
}
```

### Get Voucher by ID

```
GET /api/vouchers/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "data": {
    "voucher": {
      "id": 1,
      "code": "ABC123XYZ",
      "batch_name": "January Promo",
      "plan_id": 2,
      "duration": 30,
      "duration_unit": "days",
      "data_limit": 100,
      "data_unit": "GB",
      "price": 29.99,
      "currency": "USD",
      "status": "active",
      "created_by": 1,
      "redeemed_by": null,
      "redeemed_at": null,
      "expiry_date": "2023-12-31T23:59:59.000Z",
      "created_at": "2023-01-01T00:00:00.000Z",
      "updated_at": "2023-01-01T00:00:00.000Z",
      "plan": {
        "id": 2,
        "name": "Premium Plan",
        "description": "High-speed internet for power users",
        "bandwidth": 100,
        "bandwidth_unit": "Mbps"
      },
      "creator": {
        "id": 1,
        "name": "Admin User",
        "email": "admin@example.com"
      },
      "redeemer": null
    }
  }
}
```

### Generate Voucher Batch

```
POST /api/vouchers/generate
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "batch_name": "February Promo",
  "plan_id": 2,
  "count": 50,
  "duration": 30,
  "duration_unit": "days",
  "data_limit": 100,
  "data_unit": "GB",
  "price": 29.99,
  "currency": "USD",
  "expiry_date": "2023-12-31T23:59:59.000Z",
  "code_length": 10,
  "code_prefix": "FEB-"
}
```

**Response:**

```json
{
  "success": true,
  "message": "Vouchers generated successfully",
  "data": {
    "batch_name": "February Promo",
    "count": 50,
    "first_code": "FEB-A1B2C3D4",
    "batch_id": "feb-promo-20230102"
  }
}
```

### Redeem Voucher

```
POST /api/vouchers/redeem
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "code": "ABC123XYZ"
}
```

**Response:**

```json
{
  "success": true,
  "message": "Voucher redeemed successfully",
  "data": {
    "voucher": {
      "id": 1,
      "code": "ABC123XYZ",
      "batch_name": "January Promo",
      "plan_id": 2,
      "duration": 30,
      "duration_unit": "days",
      "data_limit": 100,
      "data_unit": "GB",
      "status": "used",
      "redeemed_by": 3,
      "redeemed_at": "2023-01-15T00:00:00.000Z",
      "updated_at": "2023-01-15T00:00:00.000Z",
      "plan": {
        "id": 2,
        "name": "Premium Plan",
        "description": "High-speed internet for power users"
      }
    },
    "subscription": {
      "id": 5,
      "user_id": 3,
      "plan_id": 2,
      "start_date": "2023-01-15T00:00:00.000Z",
      "end_date": "2023-02-14T23:59:59.000Z",
      "status": "active"
    }
  }
}
```

### Verify Voucher

```
GET /api/vouchers/verify/:code
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "data": {
    "valid": true,
    "voucher": {
      "id": 1,
      "code": "ABC123XYZ",
      "batch_name": "January Promo",
      "plan_id": 2,
      "duration": 30,
      "duration_unit": "days",
      "data_limit": 100,
      "data_unit": "GB",
      "price": 29.99,
      "currency": "USD",
      "status": "active",
      "expiry_date": "2023-12-31T23:59:59.000Z",
      "plan": {
        "id": 2,
        "name": "Premium Plan",
        "description": "High-speed internet for power users",
        "bandwidth": 100,
        "bandwidth_unit": "Mbps"
      }
    }
  }
}
```

### Export Vouchers

```
GET /api/vouchers/export
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- `batch_name`: Filter by batch name
- `status`: Filter by status (active, used, expired, inactive)
- `format`: Export format (csv, pdf, excel) (default: csv)

**Response:**

File download response with appropriate content type header.

### Delete Voucher

```
DELETE /api/vouchers/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "message": "Voucher deleted successfully"
}
```

### Send Voucher by Email

```
POST /api/vouchers/:id/send
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "email": "recipient@example.com",
  "subject": "Your Internet Voucher",
  "message": "Here is your internet access voucher as requested."
}
```

**Response:**

```json
{
  "success": true,
  "message": "Voucher sent successfully"
}
```

### Update Voucher Expiry

```
PATCH /api/vouchers/:id/expiry
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "expiry_date": "2024-06-30T23:59:59.000Z"
}
```

**Response:**

```json
{
  "success": true,
  "message": "Voucher expiry updated successfully",
  "data": {
    "voucher": {
      "id": 1,
      "expiry_date": "2024-06-30T23:59:59.000Z",
      "updated_at": "2023-01-20T00:00:00.000Z"
    }
  }
}
```

## Notifications

### Get All Notifications

```
GET /api/notifications
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- `page`: Page number (default: 1)
- `limit`: Number of items per page (default: 10)
- `read`: Filter by read status (true, false)
- `sort_by`: Field to sort by (created_at, etc.)
- `sort_order`: Sort order (asc, desc)

**Response:**

```json
{
  "success": true,
  "data": {
    "notifications": [
      {
        "id": 1,
        "user_id": 1,
        "title": "New Feature Available",
        "message": "We've added a new dashboard feature to help you track your internet usage.",
        "type": "feature_update",
        "read": false,
        "data": {
          "feature_id": 5,
          "feature_name": "Usage Dashboard"
        },
        "created_at": "2023-01-01T00:00:00.000Z",
        "updated_at": "2023-01-01T00:00:00.000Z"
      }
    ],
    "pagination": {
      "total": 15,
      "page": 1,
      "limit": 10,
      "total_pages": 2
    },
    "unread_count": 5
  }
}
```

### Get Notification by ID

```
GET /api/notifications/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "data": {
    "notification": {
      "id": 1,
      "user_id": 1,
      "title": "New Feature Available",
      "message": "We've added a new dashboard feature to help you track your internet usage.",
      "type": "feature_update",
      "read": false,
      "data": {
        "feature_id": 5,
        "feature_name": "Usage Dashboard"
      },
      "created_at": "2023-01-01T00:00:00.000Z",
      "updated_at": "2023-01-01T00:00:00.000Z"
    }
  }
}
```

### Create Notification

```
POST /api/notifications
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "user_id": 1,
  "title": "Payment Reminder",
  "message": "Your subscription will expire in 3 days. Please renew to avoid service interruption.",
  "type": "payment_reminder",
  "data": {
    "subscription_id": 10,
    "expiry_date": "2023-01-15T00:00:00.000Z"
  }
}
```

**Response:**

```json
{
  "success": true,
  "message": "Notification created successfully",
  "data": {
    "notification": {
      "id": 2,
      "user_id": 1,
      "title": "Payment Reminder",
      "message": "Your subscription will expire in 3 days. Please renew to avoid service interruption.",
      "type": "payment_reminder",
      "read": false,
      "data": {
        "subscription_id": 10,
        "expiry_date": "2023-01-15T00:00:00.000Z"
      },
      "created_at": "2023-01-12T00:00:00.000Z",
      "updated_at": "2023-01-12T00:00:00.000Z"
    }
  }
}
```

### Mark Notification as Read

```
PATCH /api/notifications/:id/read
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "message": "Notification marked as read",
  "data": {
    "notification": {
      "id": 1,
      "read": true,
      "updated_at": "2023-01-02T00:00:00.000Z"
    }
  }
}
```

### Mark All Notifications as Read

```
PATCH /api/notifications/read-all
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "message": "All notifications marked as read",
  "data": {
    "count": 5,
    "updated_at": "2023-01-02T00:00:00.000Z"
  }
}
```

### Delete Notification

```
DELETE /api/notifications/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "message": "Notification deleted successfully"
}
```

### Send Bulk Notifications

```
POST /api/notifications/bulk
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "user_ids": [1, 2, 3],
  "title": "System Maintenance",
  "message": "Our system will be undergoing maintenance on January 20th from 2AM to 4AM.",
  "type": "system_maintenance",
  "data": {
    "maintenance_date": "2023-01-20T02:00:00.000Z",
    "duration_hours": 2
  }
}
```

**Response:**

```json
{
  "success": true,
  "message": "Bulk notifications sent successfully",
  "data": {
    "count": 3,
    "created_at": "2023-01-15T00:00:00.000Z"
  }
}
```

## Settings

### Get System Settings

```
GET /api/settings
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "data": {
    "settings": {
      "company_name": "ISP Solutions Ltd",
      "company_address": "123 Internet Street, Server City",
      "company_email": "support@ispsolutions.com",
      "company_phone": "+1234567890",
      "company_website": "https://ispsolutions.com",
      "company_logo_url": "https://ispsolutions.com/logo.png",
      "currency": "USD",
      "tax_rate": 10,
      "payment_methods": ["credit_card", "bank_transfer", "mobile_money"],
      "smtp_settings": {
        "host": "smtp.example.com",
        "port": 587,
        "secure": true,
        "username": "notifications@ispsolutions.com"
      },
      "sms_provider": "twilio",
      "default_language": "en",
      "timezone": "UTC",
      "maintenance_mode": false,
      "updated_at": "2023-01-01T00:00:00.000Z"
    }
  }
}
```

### Update System Settings

```
PUT /api/settings
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "company_name": "ISP Solutions International Ltd",
  "company_address": "456 Broadband Avenue, Network City",
  "tax_rate": 12.5,
  "payment_methods": ["credit_card", "bank_transfer", "mobile_money", "paypal"],
  "maintenance_mode": true,
  "maintenance_message": "System undergoing scheduled maintenance. Please check back in 2 hours."
}
```

**Response:**

```json
{
  "success": true,
  "message": "Settings updated successfully",
  "data": {
    "settings": {
      "company_name": "ISP Solutions International Ltd",
      "company_address": "456 Broadband Avenue, Network City",
      "company_email": "support@ispsolutions.com",
      "company_phone": "+1234567890",
      "company_website": "https://ispsolutions.com",
      "company_logo_url": "https://ispsolutions.com/logo.png",
      "currency": "USD",
      "tax_rate": 12.5,
      "payment_methods": ["credit_card", "bank_transfer", "mobile_money", "paypal"],
      "smtp_settings": {
        "host": "smtp.example.com",
        "port": 587,
        "secure": true,
        "username": "notifications@ispsolutions.com"
      },
      "sms_provider": "twilio",
      "default_language": "en",
      "timezone": "UTC",
      "maintenance_mode": true,
      "maintenance_message": "System undergoing scheduled maintenance. Please check back in 2 hours.",
      "updated_at": "2023-01-15T00:00:00.000Z"
    }
  }
}
```

### Get Email Templates

```
GET /api/settings/email-templates
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- `type`: Template type (welcome, password_reset, invoice, etc.)

**Response:**

```json
{
  "success": true,
  "data": {
    "templates": [
      {
        "id": 1,
        "type": "welcome",
        "subject": "Welcome to ISP Solutions!",
        "body": "<h1>Welcome to ISP Solutions!</h1><p>Dear {{user_name}},</p><p>Thank you for choosing ISP Solutions for your internet needs...</p>",
        "variables": ["user_name", "login_url"],
        "active": true,
        "created_at": "2023-01-01T00:00:00.000Z",
        "updated_at": "2023-01-01T00:00:00.000Z"
      },
      {
        "id": 2,
        "type": "password_reset",
        "subject": "Password Reset Request",
        "body": "<h1>Password Reset</h1><p>Dear {{user_name}},</p><p>You have requested to reset your password. Please click the link below to reset your password:</p><p><a href='{{reset_url}}'>Reset Password</a></p>",
        "variables": ["user_name", "reset_url", "expiry_time"],
        "active": true,
        "created_at": "2023-01-01T00:00:00.000Z",
        "updated_at": "2023-01-01T00:00:00.000Z"
      }
    ]
  }
}
```

### Update Email Template

```
PUT /api/settings/email-templates/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "subject": "Welcome to ISP Solutions - Your Internet Partner!",
  "body": "<h1>Welcome to ISP Solutions!</h1><p>Dear {{user_name}},</p><p>Thank you for choosing ISP Solutions for your internet needs. We're excited to have you on board!</p><p>Your account has been successfully created. You can log in at <a href='{{login_url}}'>our customer portal</a>.</p><p>If you have any questions, please don't hesitate to contact our support team.</p><p>Best regards,<br>The ISP Solutions Team</p>",
  "active": true
}
```

**Response:**

```json
{
  "success": true,
  "message": "Email template updated successfully",
  "data": {
    "template": {
      "id": 1,
      "type": "welcome",
      "subject": "Welcome to ISP Solutions - Your Internet Partner!",
      "body": "<h1>Welcome to ISP Solutions!</h1><p>Dear {{user_name}},</p><p>Thank you for choosing ISP Solutions for your internet needs. We're excited to have you on board!</p><p>Your account has been successfully created. You can log in at <a href='{{login_url}}'>our customer portal</a>.</p><p>If you have any questions, please don't hesitate to contact our support team.</p><p>Best regards,<br>The ISP Solutions Team</p>",
      "variables": ["user_name", "login_url"],
      "active": true,
      "updated_at": "2023-01-15T00:00:00.000Z"
    }
  }
}
```

### Test Email Template

```
POST /api/settings/email-templates/:id/test
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "email": "test@example.com",
  "test_data": {
    "user_name": "John Doe",
    "login_url": "https://ispsolutions.com/login"
  }
}
```

**Response:**

```json
{
  "success": true,
  "message": "Test email sent successfully",
  "data": {
    "to": "test@example.com",
    "subject": "Welcome to ISP Solutions - Your Internet Partner!",
    "sent_at": "2023-01-15T12:30:45.000Z"
  }
}
```

### Get Payment Gateway Settings

```
GET /api/settings/payment-gateways
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "data": {
    "gateways": [
      {
        "id": 1,
        "name": "Stripe",
        "type": "stripe",
        "is_active": true,
        "is_default": true,
        "config": {
          "public_key": "pk_test_****",
          "webhook_url": "https://api.ispsolutions.com/webhooks/stripe",
          "supported_currencies": ["USD", "EUR", "GBP"]
        },
        "created_at": "2023-01-01T00:00:00.000Z",
        "updated_at": "2023-01-01T00:00:00.000Z"
      },
      {
        "id": 2,
        "name": "PayPal",
        "type": "paypal",
        "is_active": true,
        "is_default": false,
        "config": {
          "client_id": "client_****",
          "webhook_url": "https://api.ispsolutions.com/webhooks/paypal",
          "supported_currencies": ["USD", "EUR", "GBP"]
        },
        "created_at": "2023-01-01T00:00:00.000Z",
        "updated_at": "2023-01-01T00:00:00.000Z"
      }
    ]
  }
}
```

### Update Payment Gateway Settings

```
PUT /api/settings/payment-gateways/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "name": "Stripe",
  "is_active": true,
  "is_default": true,
  "config": {
    "public_key": "pk_live_****",
    "secret_key": "sk_live_****",
    "webhook_secret": "whsec_****",
    "webhook_url": "https://api.ispsolutions.com/webhooks/stripe",
    "supported_currencies": ["USD", "EUR", "GBP", "CAD"]
  }
}
```

**Response:**

```json
{
  "success": true,
  "message": "Payment gateway updated successfully",
  "data": {
    "gateway": {
      "id": 1,
      "name": "Stripe",
      "type": "stripe",
      "is_active": true,
      "is_default": true,
      "config": {
        "public_key": "pk_live_****",
        "webhook_url": "https://api.ispsolutions.com/webhooks/stripe",
        "supported_currencies": ["USD", "EUR", "GBP", "CAD"]
      },
      "updated_at": "2023-01-15T00:00:00.000Z"
    }
  }
}
```

## Reports

### Get Revenue Report

```
GET /api/reports/revenue
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- `start_date`: Start date for the report (YYYY-MM-DD)
- `end_date`: End date for the report (YYYY-MM-DD)
- `interval`: Grouping interval (day, week, month, year)
- `payment_method`: Filter by payment method (optional)
- `plan_id`: Filter by plan ID (optional)
- `format`: Response format (json, csv, pdf) - default: json

**Response:**

```json
{
  "success": true,
  "data": {
    "report": {
      "title": "Revenue Report",
      "start_date": "2023-01-01",
      "end_date": "2023-01-31",
      "interval": "day",
      "total_revenue": 15250.75,
      "currency": "USD",
      "items": [
        {
          "date": "2023-01-01",
          "revenue": 520.50,
          "transactions": 5,
          "average": 104.10
        },
        {
          "date": "2023-01-02",
          "revenue": 750.25,
          "transactions": 7,
          "average": 107.18
        }
      ],
      "by_payment_method": [
        {
          "method": "credit_card",
          "revenue": 10500.50,
          "percentage": 68.85
        },
        {
          "method": "bank_transfer",
          "revenue": 3250.25,
          "percentage": 21.31
        },
        {
          "method": "mobile_money",
          "revenue": 1500.00,
          "percentage": 9.84
        }
      ],
      "by_plan": [
        {
          "plan_id": 1,
          "plan_name": "Basic",
          "revenue": 2500.00,
          "percentage": 16.39
        },
        {
          "plan_id": 2,
          "plan_name": "Standard",
          "revenue": 7500.75,
          "percentage": 49.18
        },
        {
          "plan_id": 3,
          "plan_name": "Premium",
          "revenue": 5250.00,
          "percentage": 34.43
        }
      ],
      "generated_at": "2023-02-01T00:00:00.000Z"
    }
  }
}
```

### Get User Growth Report

```
GET /api/reports/user-growth
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- `start_date`: Start date for the report (YYYY-MM-DD)
- `end_date`: End date for the report (YYYY-MM-DD)
- `interval`: Grouping interval (day, week, month, year)
- `format`: Response format (json, csv, pdf) - default: json

**Response:**

```json
{
  "success": true,
  "data": {
    "report": {
      "title": "User Growth Report",
      "start_date": "2023-01-01",
      "end_date": "2023-03-31",
      "interval": "month",
      "total_users": 250,
      "new_users": 75,
      "churn_rate": 2.5,
      "items": [
        {
          "date": "2023-01",
          "new_users": 30,
          "churned_users": 5,
          "total_users": 180,
          "growth_rate": 16.67
        },
        {
          "date": "2023-02",
          "new_users": 25,
          "churned_users": 8,
          "total_users": 197,
          "growth_rate": 9.44
        },
        {
          "date": "2023-03",
          "new_users": 20,
          "churned_users": 7,
          "total_users": 210,
          "growth_rate": 6.60
        }
      ],
      "by_plan": [
        {
          "plan_id": 1,
          "plan_name": "Basic",
          "users": 100,
          "percentage": 40.00
        },
        {
          "plan_id": 2,
          "plan_name": "Standard",
          "users": 100,
          "percentage": 40.00
        },
        {
          "plan_id": 3,
          "plan_name": "Premium",
          "users": 50,
          "percentage": 20.00
        }
      ],
      "generated_at": "2023-04-01T00:00:00.000Z"
    }
  }
}
```

### Get Usage Report

```
GET /api/reports/usage
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- `start_date`: Start date for the report (YYYY-MM-DD)
- `end_date`: End date for the report (YYYY-MM-DD)
- `interval`: Grouping interval (day, week, month, year)
- `router_id`: Filter by router ID (optional)
- `plan_id`: Filter by plan ID (optional)
- `format`: Response format (json, csv, pdf) - default: json

**Response:**

```json
{
  "success": true,
  "data": {
    "report": {
      "title": "Usage Report",
      "start_date": "2023-01-01",
      "end_date": "2023-01-31",
      "interval": "week",
      "total_data_usage": 15240.50,
      "unit": "GB",
      "items": [
        {
          "date": "2023-W01",
          "data_usage": 3500.25,
          "sessions": 1250,
          "unique_users": 180
        },
        {
          "date": "2023-W02",
          "data_usage": 3750.75,
          "sessions": 1300,
          "unique_users": 185
        },
        {
          "date": "2023-W03",
          "data_usage": 4100.50,
          "sessions": 1350,
          "unique_users": 190
        },
        {
          "date": "2023-W04",
          "data_usage": 3889.00,
          "sessions": 1320,
          "unique_users": 188
        }
      ],
      "by_plan": [
        {
          "plan_id": 1,
          "plan_name": "Basic",
          "data_usage": 2500.50,
          "percentage": 16.41,
          "average_per_user": 25.01
        },
        {
          "plan_id": 2,
          "plan_name": "Standard",
          "data_usage": 7500.00,
          "percentage": 49.21,
          "average_per_user": 75.00
        },
        {
          "plan_id": 3,
          "plan_name": "Premium",
          "data_usage": 5240.00,
          "percentage": 34.38,
          "average_per_user": 104.80
        }
      ],
      "by_router": [
        {
          "router_id": 1,
          "router_name": "Main Office",
          "data_usage": 8500.25,
          "percentage": 55.77,
          "sessions": 2800
        },
        {
          "router_id": 2,
          "router_name": "Branch Office",
          "data_usage": 6740.25,
          "percentage": 44.23,
          "sessions": 2420
        }
      ],
      "peak_hours": [
        {
          "hour": 20,
          "data_usage": 1500.50,
          "percentage": 9.84
        },
        {
          "hour": 21,
          "data_usage": 1450.25,
          "percentage": 9.52
        },
        {
          "hour": 19,
          "data_usage": 1350.75,
          "percentage": 8.86
        }
      ],
      "generated_at": "2023-02-01T00:00:00.000Z"
    }
  }
}
```

### Get Payment Status Report

```
GET /api/reports/payment-status
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- `status`: Payment status (paid, pending, failed, overdue)
- `start_date`: Start date for the report (YYYY-MM-DD)
- `end_date`: End date for the report (YYYY-MM-DD)
- `format`: Response format (json, csv, pdf) - default: json

**Response:**

```json
{
  "success": true,
  "data": {
    "report": {
      "title": "Payment Status Report",
      "status": "overdue",
      "start_date": "2023-01-01",
      "end_date": "2023-01-31",
      "total_amount": 2500.75,
      "currency": "USD",
      "total_users": 15,
      "items": [
        {
          "user_id": 1,
          "user_name": "John Doe",
          "email": "john.doe@example.com",
          "phone": "+1234567890",
          "plan_id": 2,
          "plan_name": "Standard",
          "amount": 199.99,
          "due_date": "2023-01-15",
          "days_overdue": 16,
          "last_payment_date": "2022-12-15"
        },
        {
          "user_id": 5,
          "user_name": "Jane Smith",
          "email": "jane.smith@example.com",
          "phone": "+1987654321",
          "plan_id": 3,
          "plan_name": "Premium",
          "amount": 299.99,
          "due_date": "2023-01-10",
          "days_overdue": 21,
          "last_payment_date": "2022-12-10"
        }
      ],
      "by_plan": [
        {
          "plan_id": 1,
          "plan_name": "Basic",
          "amount": 500.00,
          "percentage": 20.00,
          "users": 5
        },
        {
          "plan_id": 2,
          "plan_name": "Standard",
          "amount": 1000.75,
          "percentage": 40.02,
          "users": 5
        },
        {
          "plan_id": 3,
          "plan_name": "Premium",
          "amount": 1000.00,
          "percentage": 39.98,
          "users": 5
        }
      ],
      "generated_at": "2023-02-01T00:00:00.000Z"
    }
  }
}
```

### Export Report

```
GET /api/reports/:type/export
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- All parameters applicable to the specific report type
- `format`: Export format (csv, pdf, excel) - required

**Response:**

For CSV/Excel format:

```
Content-Type: application/octet-stream
Content-Disposition: attachment; filename="revenue-report-2023-01-01-to-2023-01-31.csv"

(Binary file content)
```

For PDF format:

```
Content-Type: application/pdf
Content-Disposition: attachment; filename="revenue-report-2023-01-01-to-2023-01-31.pdf"

(Binary file content)
```

### Schedule Report

```
POST /api/reports/schedule
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "report_type": "revenue",
  "name": "Monthly Revenue Report",
  "frequency": "monthly",
  "day_of_month": 1,
  "time": "00:00:00",
  "timezone": "UTC",
  "format": "pdf",
  "recipients": ["admin@ispsolutions.com", "finance@ispsolutions.com"],
  "parameters": {
    "interval": "day"
  },
  "active": true
}
```

**Response:**

```json
{
  "success": true,
  "message": "Report scheduled successfully",
  "data": {
    "schedule": {
      "id": 1,
      "report_type": "revenue",
      "name": "Monthly Revenue Report",
      "frequency": "monthly",
      "day_of_month": 1,
      "time": "00:00:00",
      "timezone": "UTC",
      "format": "pdf",
      "recipients": ["admin@ispsolutions.com", "finance@ispsolutions.com"],
      "parameters": {
        "interval": "day"
      },
      "active": true,
      "next_run": "2023-02-01T00:00:00.000Z",
      "created_at": "2023-01-15T00:00:00.000Z",
      "updated_at": "2023-01-15T00:00:00.000Z"
    }
  }
}
```

### Get Scheduled Reports

```
GET /api/reports/schedule
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "data": {
    "schedules": [
      {
        "id": 1,
        "report_type": "revenue",
        "name": "Monthly Revenue Report",
        "frequency": "monthly",
        "day_of_month": 1,
        "time": "00:00:00",
        "timezone": "UTC",
        "format": "pdf",
        "recipients": ["admin@ispsolutions.com", "finance@ispsolutions.com"],
        "parameters": {
          "interval": "day"
        },
        "active": true,
        "next_run": "2023-02-01T00:00:00.000Z",
        "last_run": null,
        "created_at": "2023-01-15T00:00:00.000Z",
        "updated_at": "2023-01-15T00:00:00.000Z"
      },
      {
        "id": 2,
        "report_type": "user-growth",
        "name": "Weekly User Growth Report",
        "frequency": "weekly",
        "day_of_week": 1,
        "time": "08:00:00",
        "timezone": "UTC",
        "format": "excel",
        "recipients": ["admin@ispsolutions.com", "marketing@ispsolutions.com"],
        "parameters": {
          "interval": "day"
        },
        "active": true,
        "next_run": "2023-01-16T08:00:00.000Z",
        "last_run": "2023-01-09T08:00:00.000Z",
        "created_at": "2023-01-01T00:00:00.000Z",
        "updated_at": "2023-01-09T08:00:00.000Z"
      }
    ]
  }
}
```

### Update Scheduled Report

```
PUT /api/reports/schedule/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "name": "Monthly Revenue Report - Updated",
  "frequency": "monthly",
  "day_of_month": 2,
  "time": "06:00:00",
  "timezone": "UTC",
  "format": "excel",
  "recipients": ["admin@ispsolutions.com", "finance@ispsolutions.com", "ceo@ispsolutions.com"],
  "parameters": {
    "interval": "week"
  },
  "active": true
}
```

**Response:**

```json
{
  "success": true,
  "message": "Scheduled report updated successfully",
  "data": {
    "schedule": {
      "id": 1,
      "report_type": "revenue",
      "name": "Monthly Revenue Report - Updated",
      "frequency": "monthly",
      "day_of_month": 2,
      "time": "06:00:00",
      "timezone": "UTC",
      "format": "excel",
      "recipients": ["admin@ispsolutions.com", "finance@ispsolutions.com", "ceo@ispsolutions.com"],
      "parameters": {
        "interval": "week"
      },
      "active": true,
      "next_run": "2023-02-02T06:00:00.000Z",
      "updated_at": "2023-01-20T00:00:00.000Z"
    }
  }
}
```

### Delete Scheduled Report

```
DELETE /api/reports/schedule/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "message": "Scheduled report deleted successfully"
}
```

## Roles

### Get All Roles

```
GET /api/roles
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "data": {
    "roles": [
      {
        "id": 1,
        "name": "admin",
        "display_name": "Administrator",
        "description": "Full system access",
        "permissions": [
          "users.view",
          "users.create",
          "users.update",
          "users.delete",
          "plans.view",
          "plans.create",
          "plans.update",
          "plans.delete",
          "transactions.view",
          "transactions.create",
          "transactions.update",
          "transactions.delete",
          "settings.view",
          "settings.update",
          "reports.view",
          "reports.create"
        ],
        "created_at": "2023-01-01T00:00:00.000Z",
        "updated_at": "2023-01-01T00:00:00.000Z"
      },
      {
        "id": 2,
        "name": "manager",
        "display_name": "Manager",
        "description": "Limited administrative access",
        "permissions": [
          "users.view",
          "users.create",
          "users.update",
          "plans.view",
          "transactions.view",
          "transactions.create",
          "reports.view"
        ],
        "created_at": "2023-01-01T00:00:00.000Z",
        "updated_at": "2023-01-01T00:00:00.000Z"
      },
      {
        "id": 3,
        "name": "customer",
        "display_name": "Customer",
        "description": "Regular customer access",
        "permissions": [
          "profile.view",
          "profile.update",
          "transactions.view",
          "sessions.view"
        ],
        "created_at": "2023-01-01T00:00:00.000Z",
        "updated_at": "2023-01-01T00:00:00.000Z"
      }
    ]
  }
}
```

### Get Role by ID

```
GET /api/roles/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "data": {
    "role": {
      "id": 1,
      "name": "admin",
      "display_name": "Administrator",
      "description": "Full system access",
      "permissions": [
        "users.view",
        "users.create",
        "users.update",
        "users.delete",
        "plans.view",
        "plans.create",
        "plans.update",
        "plans.delete",
        "transactions.view",
        "transactions.create",
        "transactions.update",
        "transactions.delete",
        "settings.view",
        "settings.update",
        "reports.view",
        "reports.create"
      ],
      "created_at": "2023-01-01T00:00:00.000Z",
      "updated_at": "2023-01-01T00:00:00.000Z"
    }
  }
}
```

### Create Role

```
POST /api/roles
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "name": "support",
  "display_name": "Support Agent",
  "description": "Customer support access",
  "permissions": [
    "users.view",
    "transactions.view",
    "sessions.view",
    "vouchers.view",
    "vouchers.create"
  ]
}
```

**Response:**

```json
{
  "success": true,
  "message": "Role created successfully",
  "data": {
    "role": {
      "id": 4,
      "name": "support",
      "display_name": "Support Agent",
      "description": "Customer support access",
      "permissions": [
        "users.view",
        "transactions.view",
        "sessions.view",
        "vouchers.view",
        "vouchers.create"
      ],
      "created_at": "2023-01-15T00:00:00.000Z",
      "updated_at": "2023-01-15T00:00:00.000Z"
    }
  }
}
```

### Update Role

```
PUT /api/roles/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "display_name": "Support Team",
  "description": "Customer support team access",
  "permissions": [
    "users.view",
    "transactions.view",
    "sessions.view",
    "vouchers.view",
    "vouchers.create",
    "vouchers.update"
  ]
}
```

**Response:**

```json
{
  "success": true,
  "message": "Role updated successfully",
  "data": {
    "role": {
      "id": 4,
      "name": "support",
      "display_name": "Support Team",
      "description": "Customer support team access",
      "permissions": [
        "users.view",
        "transactions.view",
        "sessions.view",
        "vouchers.view",
        "vouchers.create",
        "vouchers.update"
      ],
      "updated_at": "2023-01-20T00:00:00.000Z"
    }
  }
}
```

### Delete Role

```
DELETE /api/roles/:id
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "message": "Role deleted successfully"
}
```

### Get All Permissions

```
GET /api/permissions
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "data": {
    "permissions": [
      {
        "name": "users.view",
        "display_name": "View Users",
        "description": "Ability to view user accounts",
        "group": "users"
      },
      {
        "name": "users.create",
        "display_name": "Create Users",
        "description": "Ability to create new user accounts",
        "group": "users"
      },
      {
        "name": "users.update",
        "display_name": "Update Users",
        "description": "Ability to update user accounts",
        "group": "users"
      },
      {
        "name": "users.delete",
        "display_name": "Delete Users",
        "description": "Ability to delete user accounts",
        "group": "users"
      },
      {
        "name": "plans.view",
        "display_name": "View Plans",
        "description": "Ability to view subscription plans",
        "group": "plans"
      },
      {
        "name": "plans.create",
        "display_name": "Create Plans",
        "description": "Ability to create new subscription plans",
        "group": "plans"
      }
    ],
    "groups": [
      {
        "name": "users",
        "display_name": "User Management"
      },
      {
        "name": "plans",
        "display_name": "Plan Management"
      },
      {
        "name": "transactions",
        "display_name": "Transaction Management"
      },
      {
        "name": "settings",
        "display_name": "System Settings"
      },
      {
        "name": "reports",
        "display_name": "Reports"
      },
      {
        "name": "sessions",
        "display_name": "Session Management"
      },
      {
        "name": "vouchers",
        "display_name": "Voucher Management"
      },
      {
        "name": "profile",
        "display_name": "User Profile"
      }
    ]
  }
}
```

### Assign Role to User

```
POST /api/users/:id/roles
```

**Headers:**

```
Authorization: Bearer <token>
```

**Request Body:**

```json
{
  "role_id": 2
}
```

**Response:**

```json
{
  "success": true,
  "message": "Role assigned successfully",
  "data": {
    "user": {
      "id": 5,
      "name": "Jane Smith",
      "email": "jane.smith@example.com",
      "role": {
        "id": 2,
        "name": "manager",
        "display_name": "Manager"
      },
      "updated_at": "2023-01-20T00:00:00.000Z"
    }
  }
}
```

### Check User Permission

```
GET /api/users/:id/permissions/:permission
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "data": {
    "user_id": 5,
    "permission": "users.view",
    "has_permission": true
  }
}
```

## Dashboard

### Get Dashboard Summary

```
GET /api/dashboard/summary
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "data": {
    "summary": {
      "total_users": 250,
      "active_users": 230,
      "new_users_today": 5,
      "total_revenue": 25000.50,
      "revenue_this_month": 5250.75,
      "pending_payments": 1500.25,
      "active_sessions": 120,
      "total_data_usage_today": 500.25,
      "unit": "GB"
    },
    "generated_at": "2023-01-15T12:30:45.000Z"
  }
}
```

### Get Revenue Chart Data

```
GET /api/dashboard/charts/revenue
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- `period`: Time period (day, week, month, year) - default: month
- `start_date`: Start date (YYYY-MM-DD) - optional
- `end_date`: End date (YYYY-MM-DD) - optional

**Response:**

```json
{
  "success": true,
  "data": {
    "chart": {
      "title": "Revenue Chart",
      "period": "month",
      "start_date": "2023-01-01",
      "end_date": "2023-01-31",
      "labels": ["Jan 01", "Jan 02", "Jan 03", "Jan 04", "Jan 05"],
      "datasets": [
        {
          "label": "Revenue",
          "data": [520.50, 750.25, 625.75, 800.00, 950.50],
          "total": 3647.00,
          "currency": "USD"
        }
      ]
    },
    "generated_at": "2023-01-15T12:30:45.000Z"
  }
}
```

### Get User Growth Chart Data

```
GET /api/dashboard/charts/user-growth
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- `period`: Time period (day, week, month, year) - default: month
- `start_date`: Start date (YYYY-MM-DD) - optional
- `end_date`: End date (YYYY-MM-DD) - optional

**Response:**

```json
{
  "success": true,
  "data": {
    "chart": {
      "title": "User Growth Chart",
      "period": "month",
      "start_date": "2023-01-01",
      "end_date": "2023-01-31",
      "labels": ["Week 1", "Week 2", "Week 3", "Week 4"],
      "datasets": [
        {
          "label": "New Users",
          "data": [15, 12, 10, 8],
          "total": 45
        },
        {
          "label": "Churned Users",
          "data": [2, 3, 1, 2],
          "total": 8
        }
      ]
    },
    "generated_at": "2023-01-15T12:30:45.000Z"
  }
}
```

### Get Data Usage Chart Data

```
GET /api/dashboard/charts/data-usage
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- `period`: Time period (day, week, month, year) - default: month
- `start_date`: Start date (YYYY-MM-DD) - optional
- `end_date`: End date (YYYY-MM-DD) - optional

**Response:**

```json
{
  "success": true,
  "data": {
    "chart": {
      "title": "Data Usage Chart",
      "period": "day",
      "start_date": "2023-01-15",
      "end_date": "2023-01-15",
      "labels": ["00:00", "04:00", "08:00", "12:00", "16:00", "20:00"],
      "datasets": [
        {
          "label": "Data Usage",
          "data": [50.25, 30.50, 120.75, 200.50, 180.25, 250.50],
          "total": 832.75,
          "unit": "GB"
        }
      ]
    },
    "generated_at": "2023-01-15T12:30:45.000Z"
  }
}
```

### Get Plan Distribution Chart Data

```
GET /api/dashboard/charts/plan-distribution
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "data": {
    "chart": {
      "title": "Plan Distribution Chart",
      "labels": ["Basic", "Standard", "Premium"],
      "datasets": [
        {
          "label": "Users",
          "data": [100, 100, 50],
          "total": 250
        }
      ],
      "percentages": [40, 40, 20]
    },
    "generated_at": "2023-01-15T12:30:45.000Z"
  }
}
```

### Get Recent Transactions

```
GET /api/dashboard/recent-transactions
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- `limit`: Number of transactions to return (default: 5, max: 20)

**Response:**

```json
{
  "success": true,
  "data": {
    "transactions": [
      {
        "id": 1,
        "user_id": 1,
        "user_name": "John Doe",
        "amount": 199.99,
        "currency": "USD",
        "payment_method": "credit_card",
        "status": "completed",
        "type": "subscription",
        "plan_name": "Standard",
        "created_at": "2023-01-15T10:30:00.000Z"
      },
      {
        "id": 2,
        "user_id": 5,
        "user_name": "Jane Smith",
        "amount": 299.99,
        "currency": "USD",
        "payment_method": "bank_transfer",
        "status": "completed",
        "type": "subscription",
        "plan_name": "Premium",
        "created_at": "2023-01-15T09:45:00.000Z"
      }
    ]
  }
}
```

### Get Active Sessions

```
GET /api/dashboard/active-sessions
```

**Headers:**

```
Authorization: Bearer <token>
```

**Query Parameters:**

- `limit`: Number of sessions to return (default: 5, max: 20)

**Response:**

```json
{
  "success": true,
  "data": {
    "sessions": [
      {
        "id": 1,
        "user_id": 1,
        "user_name": "John Doe",
        "router_id": 1,
        "router_name": "Main Office",
        "ip_address": "192.168.1.100",
        "mac_address": "00:1A:2B:3C:4D:5E",
        "data_used": 2.5,
        "unit": "GB",
        "started_at": "2023-01-15T08:30:00.000Z",
        "duration": 14400
      },
      {
        "id": 2,
        "user_id": 5,
        "user_name": "Jane Smith",
        "router_id": 2,
        "router_name": "Branch Office",
        "ip_address": "192.168.2.100",
        "mac_address": "00:5E:4D:3C:2B:1A",
        "data_used": 1.8,
        "unit": "GB",
        "started_at": "2023-01-15T09:15:00.000Z",
        "duration": 12000
      }
    ]
  }
}
```

### Get System Status

```
GET /api/dashboard/system-status
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "data": {
    "status": {
      "system": "operational",
      "database": "operational",
      "payment_gateway": "operational",
      "router_sync": "operational",
      "email_service": "degraded",
      "sms_service": "operational",
      "maintenance_mode": false,
      "uptime": 99.98,
      "last_checked": "2023-01-15T12:30:00.000Z"
    }
  }
}
```

### Get Alerts

```
GET /api/dashboard/alerts
```

**Headers:**

```
Authorization: Bearer <token>
```

**Response:**

```json
{
  "success": true,
  "data": {
    "alerts": [
      {
        "id": 1,
        "type": "system",
        "severity": "warning",
        "message": "Email service experiencing delays",
        "details": "Our email service provider is experiencing technical issues. Some emails may be delayed.",
        "created_at": "2023-01-15T10:00:00.000Z",
        "resolved": false
      },
      {
        "id": 2,
        "type": "payment",
        "severity": "info",
        "message": "New payment method added",
        "details": "Mobile money payment method has been added to the system.",
        "created_at": "2023-01-14T14:30:00.000Z",
        "resolved": true,
        "resolved_at": "2023-01-14T15:00:00.000Z"
      }
    ]
  }
}
```
```