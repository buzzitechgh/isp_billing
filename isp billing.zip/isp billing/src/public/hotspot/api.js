/**
 * API utility functions for MikroTik Hotspot Login Page
 */

/**
 * Fetch plans from the ISP Billing API
 * @returns {Promise<Array>} Array of plan objects
 */
async function fetchPlans() {
    try {
        const response = await fetch(`${API_BASE_URL}/api/plans/public`);
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const data = await response.json();
        return data.data || [];
    } catch (error) {
        console.error('Error fetching plans:', error);
        return [];
    }
}

/**
 * Verify a voucher code
 * @param {string} code - The voucher code to verify
 * @returns {Promise<Object>} Voucher verification result
 */
async function verifyVoucher(code) {
    try {
        const response = await fetch(`${API_BASE_URL}/api/vouchers/verify`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ code })
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || `HTTP error! Status: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('Error verifying voucher:', error);
        throw error;
    }
}

/**
 * Redeem a voucher code
 * @param {string} code - The voucher code to redeem
 * @param {string} mac - The MAC address of the device
 * @returns {Promise<Object>} Voucher redemption result
 */
async function redeemVoucher(code, mac) {
    try {
        const response = await fetch(`${API_BASE_URL}/api/vouchers/redeem`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ 
                code,
                mac,
                ip: getMikroTikVariable('ip') || '',
                linklogin: getMikroTikVariable('link-login') || ''
            })
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || `HTTP error! Status: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('Error redeeming voucher:', error);
        throw error;
    }
}

/**
 * Register a new user
 * @param {Object} userData - User registration data
 * @returns {Promise<Object>} Registration result
 */
async function registerUser(userData) {
    try {
        const response = await fetch(`${API_BASE_URL}/api/auth/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(userData)
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || `HTTP error! Status: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('Error registering user:', error);
        throw error;
    }
}

/**
 * Activate a free trial
 * @param {string} mac - The MAC address of the device
 * @returns {Promise<Object>} Free trial activation result
 */
async function activateFreeTrial(mac) {
    try {
        const response = await fetch(`${API_BASE_URL}/api/hotspot/free-trial`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ 
                mac,
                ip: getMikroTikVariable('ip') || '',
                linklogin: getMikroTikVariable('link-login') || '',
                duration: FREE_TRIAL.duration,
                bandwidth: FREE_TRIAL.bandwidth
            })
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || `HTTP error! Status: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('Error activating free trial:', error);
        throw error;
    }
}

/**
 * Initialize a payment transaction
 * @param {Object} paymentData - Payment initialization data
 * @returns {Promise<Object>} Payment initialization result
 */
async function initializePayment(paymentData) {
    try {
        const response = await fetch(`${API_BASE_URL}/api/transactions/initialize`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(paymentData)
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || `HTTP error! Status: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('Error initializing payment:', error);
        throw error;
    }
}

/**
 * Initialize a Paystack transaction for hotspot plan purchase
 * @param {Object} paymentData - Payment initialization data
 * @returns {Promise<Object>} Payment initialization result
 */
async function initializeHotspotPayment(paymentData) {
    try {
        const response = await fetch(`${API_BASE_URL}/api/hotspot/payments/initialize`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                ...paymentData,
                mac_address: getMikroTikVariable('mac') || ''
            })
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || `HTTP error! Status: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('Error initializing hotspot payment:', error);
        throw error;
    }
}

/**
 * Verify a payment transaction
 * @param {string} reference - The payment reference
 * @returns {Promise<Object>} Payment verification result
 */
async function verifyPayment(reference) {
    try {
        const response = await fetch(`${API_BASE_URL}/api/transactions/verify/${reference}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            }
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || `HTTP error! Status: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('Error verifying payment:', error);
        throw error;
    }
}

/**
 * Purchase a plan directly from hotspot page
 * @param {Object} purchaseData - Plan purchase data
 * @returns {Promise<Object>} Purchase result
 */
async function purchasePlan(purchaseData) {
    try {
        const response = await fetch(`${API_BASE_URL}/api/hotspot/plans/purchase`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                ...purchaseData,
                mac_address: getMikroTikVariable('mac') || ''
            })
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || `HTTP error! Status: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('Error purchasing plan:', error);
        throw error;
    }
}

/**
 * Get MikroTik variable value
 * @param {string} name - Variable name
 * @returns {string|null} Variable value or null if not found
 */
function getMikroTikVariable(name) {
    // MikroTik variables are injected as $(name) in the page
    const varName = `$(${name})`;
    try {
        // Check if the variable exists and has a value
        if (typeof varName !== 'undefined' && varName !== `$(${name})`) {
            return varName;
        }
        return null;
    } catch (error) {
        console.error(`Error getting MikroTik variable ${name}:`, error);
        return null;
    }
}