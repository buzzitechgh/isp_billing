/**
 * UI utility functions for MikroTik Hotspot Login Page
 */

/**
 * Show loading spinner
 * @param {boolean} show - Whether to show or hide the spinner
 */
function showLoading(show = true) {
    const loadingElement = document.getElementById('loading');
    if (loadingElement) {
        loadingElement.style.display = show ? 'flex' : 'none';
    }
}

/**
 * Show error message
 * @param {string} message - Error message to display
 * @param {number} duration - Duration in milliseconds to show the message
 */
function showError(message, duration = 5000) {
    const errorElement = document.getElementById('error-message');
    if (errorElement) {
        errorElement.textContent = message;
        errorElement.style.display = 'block';
        
        // Hide the error message after the specified duration
        setTimeout(() => {
            errorElement.style.display = 'none';
        }, duration);
    }
}

/**
 * Show success message
 * @param {string} message - Success message to display
 * @param {number} duration - Duration in milliseconds to show the message
 */
function showSuccess(message, duration = 5000) {
    const successElement = document.getElementById('success-message');
    if (successElement) {
        successElement.textContent = message;
        successElement.style.display = 'block';
        
        // Hide the success message after the specified duration
        setTimeout(() => {
            successElement.style.display = 'none';
        }, duration);
    }
}

/**
 * Show a specific card and hide others
 * @param {string} cardId - ID of the card to show
 */
function showCard(cardId) {
    // Hide all cards
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        card.style.display = 'none';
    });
    
    // Show the specified card
    const cardToShow = document.getElementById(cardId);
    if (cardToShow) {
        cardToShow.style.display = 'block';
    }
}

/**
 * Create a plan card element
 * @param {Object} plan - Plan object
 * @param {Function} onSelect - Callback function when plan is selected
 * @returns {HTMLElement} Plan card element
 */
function createPlanCard(plan, onSelect) {
    const planCard = document.createElement('div');
    planCard.className = 'plan-card';
    planCard.dataset.planId = plan.id;
    
    // Format plan details
    const duration = formatDuration(plan.duration * 60); // Convert hours to minutes
    const dataLimit = plan.data_limit ? formatDataUsage(plan.data_limit) : 'Unlimited';
    const downloadSpeed = formatBandwidth(plan.download_speed);
    const uploadSpeed = formatBandwidth(plan.upload_speed);
    
    // Create plan card content
    planCard.innerHTML = `
        <div class="plan-header">
            <h3>${plan.name}</h3>
            <div class="plan-price">₦${plan.price.toFixed(2)}</div>
        </div>
        <div class="plan-details">
            <p>${plan.description || ''}</p>
            <ul>
                <li><i class="fas fa-clock"></i> ${duration}</li>
                <li><i class="fas fa-database"></i> ${dataLimit}</li>
                <li><i class="fas fa-download"></i> ${downloadSpeed} down</li>
                <li><i class="fas fa-upload"></i> ${uploadSpeed} up</li>
            </ul>
        </div>
        <button class="btn-primary select-plan-btn">Select Plan</button>
    `;
    
    // Add event listener to the select button
    const selectButton = planCard.querySelector('.select-plan-btn');
    selectButton.addEventListener('click', () => {
        // Remove selected class from all plan cards
        document.querySelectorAll('.plan-card').forEach(card => {
            card.classList.remove('selected');
        });
        
        // Add selected class to this plan card
        planCard.classList.add('selected');
        
        // Call the onSelect callback with the plan
        if (typeof onSelect === 'function') {
            onSelect(plan);
        }
    });
    
    return planCard;
}

/**
 * Populate plans container with plan cards
 * @param {Array} plans - Array of plan objects
 * @param {Function} onSelect - Callback function when plan is selected
 */
function populatePlans(plans, onSelect) {
    const plansContainer = document.getElementById('plans-container');
    if (!plansContainer) return;
    
    // Clear existing plans
    plansContainer.innerHTML = '';
    
    if (plans.length === 0) {
        plansContainer.innerHTML = '<p class="no-plans">No plans available at the moment.</p>';
        return;
    }
    
    // Sort plans by price
    plans.sort((a, b) => a.price - b.price);
    
    // Create and append plan cards
    plans.forEach(plan => {
        const planCard = createPlanCard(plan, onSelect);
        plansContainer.appendChild(planCard);
    });
}

/**
 * Update session info display
 * @param {Object} session - Session object
 */
function updateSessionInfo(session) {
    const sessionInfoElement = document.getElementById('session-info');
    if (!sessionInfoElement) return;
    
    if (!session) {
        sessionInfoElement.style.display = 'none';
        return;
    }
    
    // Format session details
    const uptime = session.uptime || 'N/A';
    const dataUsed = session.bytesIn && session.bytesOut ? 
        formatDataUsage(parseInt(session.bytesIn) + parseInt(session.bytesOut)) : 
        'N/A';
    
    // Update session info content
    sessionInfoElement.innerHTML = `
        <h3>Active Session</h3>
        <p>Username: ${session.user || 'N/A'}</p>
        <p>IP Address: ${session.address || 'N/A'}</p>
        <p>Uptime: ${uptime}</p>
        <p>Data Used: ${dataUsed}</p>
        <button id="reconnect-btn" class="btn-primary">Reconnect</button>
    `;
    
    // Show session info
    sessionInfoElement.style.display = 'block';
    
    // Add event listener to reconnect button
    const reconnectButton = document.getElementById('reconnect-btn');
    if (reconnectButton) {
        reconnectButton.addEventListener('click', () => {
            if (session.user) {
                // Attempt to reconnect using the session username
                doMikroTikLogin(session.user, '');
            }
        });
    }
}

/**
 * Initialize UI elements and event listeners
 */
function initializeUI() {
    // Initialize navigation links
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetCard = link.getAttribute('data-target');
            if (targetCard) {
                showCard(targetCard);
            }
        });
    });
    
    // Initialize form submissions
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const username = loginForm.querySelector('[name="username"]').value;
            const password = loginForm.querySelector('[name="password"]').value;
            
            if (username && password) {
                doMikroTikLogin(username, password);
            } else {
                showError('Please enter both username and password');
            }
        });
    }
    
    // Initialize voucher form
    const voucherForm = document.getElementById('voucher-form');
    if (voucherForm) {
        voucherForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const voucherCode = voucherForm.querySelector('[name="voucher-code"]').value;
            
            if (voucherCode) {
                handleVoucherRedemption(voucherCode);
            } else {
                showError('Please enter a voucher code');
            }
        });
    }
    
    // Initialize registration form
    const registrationForm = document.getElementById('registration-form');
    if (registrationForm) {
        registrationForm.addEventListener('submit', (e) => {
            e.preventDefault();
            handleRegistration(registrationForm);
        });
    }
    
    // Initialize free trial button
    const freeTrialBtn = document.getElementById('free-trial-btn');
    if (freeTrialBtn) {
        freeTrialBtn.addEventListener('click', (e) => {
            e.preventDefault();
            handleFreeTrial();
        });
    }
    
    // Initialize company info
    updateCompanyInfo();
}

/**
 * Update company information in the UI
 */
function updateCompanyInfo() {
    // Update company name
    const companyNameElements = document.querySelectorAll('.company-name');
    companyNameElements.forEach(element => {
        element.textContent = COMPANY_INFO.name;
    });
    
    // Update support email
    const supportEmailElements = document.querySelectorAll('.support-email');
    supportEmailElements.forEach(element => {
        element.textContent = COMPANY_INFO.supportEmail;
        if (element.tagName.toLowerCase() === 'a') {
            element.href = `mailto:${COMPANY_INFO.supportEmail}`;
        }
    });
    
    // Update support phone
    const supportPhoneElements = document.querySelectorAll('.support-phone');
    supportPhoneElements.forEach(element => {
        element.textContent = COMPANY_INFO.supportPhone;
        if (element.tagName.toLowerCase() === 'a') {
            element.href = `tel:${COMPANY_INFO.supportPhone.replace(/\s+/g, '')}`;
        }
    });
    
    // Update website
    const websiteElements = document.querySelectorAll('.website');
    websiteElements.forEach(element => {
        element.textContent = COMPANY_INFO.website;
        if (element.tagName.toLowerCase() === 'a') {
            element.href = COMPANY_INFO.website;
        }
    });
}