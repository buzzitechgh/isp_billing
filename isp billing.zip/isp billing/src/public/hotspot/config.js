/**
 * Configuration for MikroTik Hotspot Login Page
 */

// API Base URL - Change this to match your ISP Billing System API URL
const API_BASE_URL = window.location.origin; // Automatically use the current domain

// Paystack Public Key - Replace with your actual Paystack public key
const PAYSTACK_PUBLIC_KEY = 'pk_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';

// Company Information
const COMPANY_INFO = {
    name: 'ISP Billing System',
    supportEmail: 'support@example.com',
    supportPhone: '+234 800 123 4567',
    website: 'https://example.com'
};

// Free Trial Settings
const FREE_TRIAL = {
    enabled: true,
    duration: 30, // minutes
    bandwidth: 1, // Mbps
    maxUsagePerDevice: 1 // How many times a device can use free trial
};

// Session Settings
const SESSION_SETTINGS = {
    checkInterval: 60, // seconds - how often to check for active sessions
    autoReconnect: true // whether to automatically reconnect to active sessions
};