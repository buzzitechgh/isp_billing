/**
 * MikroTik utility functions for Hotspot Login Page
 */

/**
 * Get MikroTik variable value
 * @param {string} name - Variable name
 * @returns {string|null} Variable value or null if not found
 */
function getMikroTikVariable(name) {
    // MikroTik variables are injected as $(name) in the page
    const varName = `$(${name})`;
    try {
        // Check if the variable exists and has a value
        if (typeof varName !== 'undefined' && varName !== `$(${name})`) {
            return varName;
        }
        return null;
    } catch (error) {
        console.error(`Error getting MikroTik variable ${name}:`, error);
        return null;
    }
}

/**
 * Check if user has an active session
 * @returns {Promise<Object|null>} Session info or null if no active session
 */
async function checkActiveSession() {
    const mac = getMikroTikVariable('mac');
    const ip = getMikroTikVariable('ip');
    
    if (!mac || !ip) {
        console.error('Cannot check session: MAC or IP address not available');
        return null;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/api/hotspot/sessions/check`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ mac, ip })
        });
        
        if (!response.ok) {
            return null;
        }
        
        const data = await response.json();
        return data.session || null;
    } catch (error) {
        console.error('Error checking active session:', error);
        return null;
    }
}

/**
 * Submit login to MikroTik
 * @param {string} username - Username
 * @param {string} password - Password
 */
function doMikroTikLogin(username, password) {
    // Create a hidden form to submit to MikroTik
    const form = document.createElement('form');
    form.method = 'post';
    form.action = getMikroTikVariable('link-login-only') || '';
    form.style.display = 'none';
    
    // Add username field
    const usernameInput = document.createElement('input');
    usernameInput.type = 'text';
    usernameInput.name = 'username';
    usernameInput.value = username;
    form.appendChild(usernameInput);
    
    // Add password field
    const passwordInput = document.createElement('input');
    passwordInput.type = 'password';
    passwordInput.name = 'password';
    passwordInput.value = password;
    form.appendChild(passwordInput);
    
    // Add dst field if available
    const dst = getMikroTikVariable('link-orig') || '';
    if (dst) {
        const dstInput = document.createElement('input');
        dstInput.type = 'hidden';
        dstInput.name = 'dst';
        dstInput.value = dst;
        form.appendChild(dstInput);
    }
    
    // Add domain field if available
    const domain = getMikroTikVariable('domain') || '';
    if (domain) {
        const domainInput = document.createElement('input');
        domainInput.type = 'hidden';
        domainInput.name = 'domain';
        domainInput.value = domain;
        form.appendChild(domainInput);
    }
    
    // Add the form to the document and submit it
    document.body.appendChild(form);
    form.submit();
}

/**
 * Format data usage in human-readable format
 * @param {number} bytes - Data usage in bytes
 * @returns {string} Formatted data usage
 */
function formatDataUsage(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * Format duration in human-readable format
 * @param {number} minutes - Duration in minutes
 * @returns {string} Formatted duration
 */
function formatDuration(minutes) {
    if (minutes < 60) {
        return `${minutes} minute${minutes !== 1 ? 's' : ''}`;
    } else if (minutes < 1440) { // Less than a day
        const hours = Math.floor(minutes / 60);
        return `${hours} hour${hours !== 1 ? 's' : ''}`;
    } else if (minutes < 10080) { // Less than a week
        const days = Math.floor(minutes / 1440);
        return `${days} day${days !== 1 ? 's' : ''}`;
    } else if (minutes < 43200) { // Less than a month (30 days)
        const weeks = Math.floor(minutes / 10080);
        return `${weeks} week${weeks !== 1 ? 's' : ''}`;
    } else {
        const months = Math.floor(minutes / 43200);
        return `${months} month${months !== 1 ? 's' : ''}`;
    }
}

/**
 * Format bandwidth in human-readable format
 * @param {number} kbps - Bandwidth in kbps
 * @returns {string} Formatted bandwidth
 */
function formatBandwidth(kbps) {
    if (kbps < 1000) {
        return `${kbps} Kbps`;
    } else {
        const mbps = kbps / 1000;
        return `${mbps.toFixed(1)} Mbps`;
    }
}