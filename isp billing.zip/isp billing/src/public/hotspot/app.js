/**
 * MikroTik Hotspot Login Page JavaScript
 * Integrates with ISP Billing System API
 * 
 * This file integrates with mikrotik.js, api.js, and ui.js utility functions
 */

// DOM Elements
const loginCard = document.getElementById('loginCard');
const voucherCard = document.getElementById('voucherCard');
const registerCard = document.getElementById('registerCard');
const plansCard = document.getElementById('plansCard');
const paymentCard = document.getElementById('paymentCard');
const wifiSignal = document.getElementById('wifiSignal');
const loadingSpinner = document.getElementById('loadingSpinner');
const sessionMessage = document.getElementById('sessionMessage');
const plansList = document.getElementById('plansList');
const selectedPlanSummary = document.getElementById('selectedPlanSummary');

// Forms
const loginForm = document.getElementById('loginForm');
const voucherForm = document.getElementById('voucherForm');
const registerForm = document.getElementById('registerForm');
const paymentForm = document.getElementById('paymentForm');

// Buttons
const voucherBtn = document.getElementById('voucherBtn');
const registerBtn = document.getElementById('registerBtn');
const freeTrialBtn = document.getElementById('freeTrialBtn');
const backToLoginBtn = document.getElementById('backToLoginBtn');
const backToLoginFromRegBtn = document.getElementById('backToLoginFromRegBtn');
const backToLoginFromPlansBtn = document.getElementById('backToLoginFromPlansBtn');
const backToPlansBtn = document.getElementById('backToPlansBtn');
const initiatePaymentBtn = document.getElementById('initiatePaymentBtn');

// State variables
let selectedPlan = null;
let currentUser = null;
let activeSessions = [];

/**
 * Initialize the application
 */
function init() {
    // Check for active sessions
    checkForActiveSessions();
    
    // Load available plans
    loadPlans();
    
    // Set up event listeners
    setupEventListeners();
}

/**
 * Set up event listeners for all interactive elements
 */
function setupEventListeners() {
    // Navigation between cards
    voucherBtn.addEventListener('click', () => showCard(voucherCard));
    registerBtn.addEventListener('click', () => showCard(registerCard));
    backToLoginBtn.addEventListener('click', () => showCard(loginCard));
    backToLoginFromRegBtn.addEventListener('click', () => showCard(loginCard));
    backToLoginFromPlansBtn.addEventListener('click', () => showCard(loginCard));
    backToPlansBtn.addEventListener('click', () => showCard(plansCard));
    
    // Free trial button
    freeTrialBtn.addEventListener('click', handleFreeTrial);
    
    // Form submissions
    loginForm.addEventListener('submit', handleLogin);
    voucherForm.addEventListener('submit', handleVoucherRedeem);
    registerForm.addEventListener('submit', handleRegistration);
    
    // Payment button
    initiatePaymentBtn.addEventListener('click', initiatePayment);
}

/**
 * Show a specific card and hide others
 * @param {HTMLElement} cardToShow - The card element to display
 */
function showCard(cardToShow) {
    // Hide all cards
    loginCard.classList.add('hidden');
    voucherCard.classList.add('hidden');
    registerCard.classList.add('hidden');
    plansCard.classList.add('hidden');
    paymentCard.classList.add('hidden');
    
    // Show the selected card
    cardToShow.classList.remove('hidden');
}

/**
 * Check for active user sessions
 */
async function checkForActiveSessions() {
    try {
        showLoading(true);
        
        // Get client MAC address from MikroTik variables
        const macAddress = '$(mac)'; // MikroTik will replace this with actual MAC
        const ipAddress = '$(ip)';   // MikroTik will replace this with actual IP
        
        // Call the API to check for active sessions
        const response = await fetch(`${API_BASE_URL}/api/sessions/check?mac_address=${macAddress}&ip_address=${ipAddress}`);
        const data = await response.json();
        
        if (data.success && data.data.active_session) {
            // Show session message
            sessionMessage.style.display = 'block';
            
            // Store session info
            activeSessions = data.data.sessions || [];
            
            // Auto reconnect after 2 seconds
            setTimeout(() => {
                // Use MikroTik login with stored credentials
                const session = data.data.active_session;
                autoLogin(session.username, session.password);
            }, 2000);
        }
    } catch (error) {
        console.error('Error checking for active sessions:', error);
    } finally {
        showLoading(false);
    }
}

/**
 * Load available plans from the API
 */
async function loadPlans() {
    try {
        // Call the API to get public plans
        const response = await fetch(`${API_BASE_URL}/api/plans/public`);
        const data = await response.json();
        
        if (data.success && data.data.length > 0) {
            // Clear loading indicator
            plansList.innerHTML = '';
            
            // Render each plan
            data.data.forEach(plan => {
                const planElement = createPlanElement(plan);
                plansList.appendChild(planElement);
            });
        } else {
            plansList.innerHTML = '<p class="no-plans">No plans available at the moment.</p>';
        }
    } catch (error) {
        console.error('Error loading plans:', error);
        plansList.innerHTML = '<p class="error">Failed to load plans. Please try again later.</p>';
    }
}

/**
 * Create a plan element for display
 * @param {Object} plan - Plan data from API
 * @returns {HTMLElement} - The plan element
 */
function createPlanElement(plan) {
    const planDiv = document.createElement('div');
    planDiv.className = 'plan-item';
    
    // Format price
    const formattedPrice = new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'NGN'
    }).format(plan.price);
    
    // Format duration based on plan type
    let duration = '';
    switch (plan.type) {
        case 'hourly':
            duration = `${plan.duration} hour${plan.duration > 1 ? 's' : ''}`;
            break;
        case 'daily':
            duration = `${plan.duration / 24} day${plan.duration / 24 > 1 ? 's' : ''}`;
            break;
        case 'weekly':
            duration = `${plan.duration / 168} week${plan.duration / 168 > 1 ? 's' : ''}`;
            break;
        case 'monthly':
            duration = `${plan.duration / 720} month${plan.duration / 720 > 1 ? 's' : ''}`;
            break;
        case 'yearly':
            duration = `${plan.duration / 8760} year${plan.duration / 8760 > 1 ? 's' : ''}`;
            break;
        default:
            duration = `${plan.duration} hours`;
    }
    
    // Format speeds
    const downloadSpeed = plan.download_speed >= 1024 ? 
        `${(plan.download_speed / 1024).toFixed(1)} Mbps` : 
        `${plan.download_speed} Kbps`;
    
    const uploadSpeed = plan.upload_speed >= 1024 ? 
        `${(plan.upload_speed / 1024).toFixed(1)} Mbps` : 
        `${plan.upload_speed} Kbps`;
    
    // Create plan HTML
    planDiv.innerHTML = `
        <div class="plan-title">
            <span>${plan.name}</span>
            <span class="plan-type">${plan.type.charAt(0).toUpperCase() + plan.type.slice(1)}</span>
        </div>
        <div class="plan-price">${formattedPrice}</div>
        <div class="plan-details">${plan.description || 'High-speed internet access'}</div>
        <ul class="plan-features">
            <li>Duration: ${duration}</li>
            <li>Download: ${downloadSpeed}</li>
            <li>Upload: ${uploadSpeed}</li>
            <li>Devices: ${plan.simultaneous_use}</li>
        </ul>
        <button class="btn btn-primary buy-plan-btn">Buy Now</button>
    `;
    
    // Add click event to buy button
    const buyButton = planDiv.querySelector('.buy-plan-btn');
    buyButton.addEventListener('click', () => selectPlan(plan));
    
    return planDiv;
}

/**
 * Handle plan selection
 * @param {Object} plan - The selected plan
 */
function selectPlan(plan) {
    selectedPlan = plan;
    
    // Show plan summary
    selectedPlanSummary.innerHTML = `
        <h3>${plan.name}</h3>
        <div class="plan-summary-item">
            <span>Price:</span>
            <strong>${new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: 'NGN'
            }).format(plan.price)}</strong>
        </div>
        <div class="plan-summary-item">
            <span>Duration:</span>
            <strong>${plan.duration} hours</strong>
        </div>
        <div class="plan-summary-item">
            <span>Speed:</span>
            <strong>${plan.download_speed / 1024} Mbps / ${plan.upload_speed / 1024} Mbps</strong>
        </div>
        <div class="plan-summary-item">
            <span>Devices:</span>
            <strong>${plan.simultaneous_use}</strong>
        </div>
    `;
    
    // Show payment card
    showCard(paymentCard);
}

/**
 * Handle login form submission
 * @param {Event} event - Form submit event
 */
function handleLogin(event) {
    // MikroTik will handle the actual form submission
    showLoading(true);
    // The form will be submitted to MikroTik's login URL
}

/**
 * Handle voucher redemption
 * @param {Event} event - Form submit event
 */
async function handleVoucherRedeem(event) {
    // For vouchers, we'll first validate with our API before submitting to MikroTik
    event.preventDefault();
    
    const voucherCode = document.getElementById('voucherCode').value.trim();
    
    if (!voucherCode) {
        alert('Please enter a valid voucher code');
        return;
    }
    
    try {
        showLoading(true);
        
        // Verify voucher with our API
        const response = await fetch(`${API_BASE_URL}/api/vouchers/verify`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ code: voucherCode })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Voucher is valid, submit to MikroTik
            document.getElementById('voucherCode').value = data.data.username;
            document.querySelector('input[name="password"]').value = data.data.password;
            voucherForm.submit();
        } else {
            alert(data.message || 'Invalid voucher code');
            showLoading(false);
        }
    } catch (error) {
        console.error('Error verifying voucher:', error);
        alert('Failed to verify voucher. Please try again.');
        showLoading(false);
    }
}

/**
 * Handle user registration
 * @param {Event} event - Form submit event
 */
async function handleRegistration(event) {
    event.preventDefault();
    
    const username = document.getElementById('regUsername').value.trim();
    const password = document.getElementById('regPassword').value.trim();
    const email = document.getElementById('regEmail').value.trim();
    const phone = document.getElementById('regPhone').value.trim();
    
    if (!username || !password || !email) {
        alert('Please fill in all required fields');
        return;
    }
    
    try {
        showLoading(true);
        
        // Register user with our API
        const response = await fetch(`${API_BASE_URL}/api/auth/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username,
                password,
                email,
                phone,
                full_name: username // Using username as full name for simplicity
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Registration successful
            currentUser = data.data.user;
            
            // Show plans for purchase
            alert('Registration successful! Please choose a plan.');
            showCard(plansCard);
        } else {
            alert(data.message || 'Registration failed. Please try again.');
        }
    } catch (error) {
        console.error('Error during registration:', error);
        alert('Registration failed. Please try again.');
    } finally {
        showLoading(false);
    }
}

/**
 * Handle free trial activation
 * @param {Event} event - Click event
 */
async function handleFreeTrial(event) {
    event.preventDefault();
    
    try {
        showLoading(true);
        
        // Get client MAC address from MikroTik variables
        const macAddress = '$(mac)'; // MikroTik will replace this with actual MAC
        
        // Request free trial from API
        const response = await fetch(`${API_BASE_URL}/api/sessions/free-trial`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                mac_address: macAddress
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Free trial activated, login automatically
            autoLogin(data.data.username, data.data.password);
        } else {
            alert(data.message || 'Failed to activate free trial. You may have used it already.');
            showLoading(false);
        }
    } catch (error) {
        console.error('Error activating free trial:', error);
        alert('Failed to activate free trial. Please try again.');
        showLoading(false);
    }
}

/**
 * Initiate payment process
 */
async function initiatePayment() {
    // Validate selected plan
    if (!selectedPlan) {
        showError('Please select a plan first');
        return;
    }
    
    // Validate email
    const email = document.getElementById('paymentEmail').value.trim();
    if (!email || !validateEmail(email)) {
        showError('Please enter a valid email address');
        return;
    }
    
    // Get phone number if provided
    const phoneInput = document.getElementById('paymentPhone');
    const phone = phoneInput ? phoneInput.value.trim() : '';
    
    // Get MAC address from MikroTik variables
    const macAddress = getMikroTikVariable('mac') || '';
    if (!macAddress) {
        showError('Unable to determine device MAC address');
        return;
    }
    
    try {
        showLoading(true);
        
        // Initialize hotspot payment with Paystack
        const response = await initializeHotspotPayment({
            email,
            phone,
            plan_id: selectedPlan.id,
            mac_address: macAddress
        });
        
        if (response.success) {
            // Open Paystack payment modal
            const handler = PaystackPop.setup({
                key: PAYSTACK_PUBLIC_KEY,
                email: email,
                amount: selectedPlan.price * 100, // Convert to kobo
                ref: response.data.reference,
                metadata: {
                    plan_id: selectedPlan.id,
                    mac_address: macAddress,
                    phone: phone || ''
                },
                callback: function(response) {
                    // Redirect to verification endpoint
                    window.location.href = `${API_BASE_URL}/api/hotspot/payments/verify?reference=${response.reference}`;
                },
                onClose: function() {
                    showLoading(false);
                    showError('Payment window closed');
                }
            });
            handler.openIframe();
        } else {
            showError(response.message || 'Failed to initialize payment');
        }
    } catch (error) {
        console.error('Payment initialization error:', error);
        showError('An error occurred while initializing payment');
    } finally {
        showLoading(false);
    }
}

/**
 * Verify payment after Paystack callback
 * @param {string} reference - Payment reference
 */
async function verifyPayment(reference) {
    try {
        showLoading(true);
        
        // Verify payment with our API
        const response = await fetch(`${API_BASE_URL}/api/transactions/verify-payment`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                reference: reference
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Payment verified, show success message
            alert('Payment successful! You will be connected shortly.');
            
            // Auto login with the credentials
            if (data.data.credentials) {
                autoLogin(data.data.credentials.username, data.data.credentials.password);
            } else {
                showLoading(false);
                showCard(loginCard);
            }
        } else {
            alert(data.message || 'Payment verification failed');
            showLoading(false);
        }
    } catch (error) {
        console.error('Error verifying payment:', error);
        alert('Failed to verify payment. Please contact support.');
        showLoading(false);
    }
}

/**
 * Automatically log in to MikroTik hotspot
 * @param {string} username - Username
 * @param {string} password - Password
 */
function autoLogin(username, password) {
    // Create a hidden form for MikroTik login
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '$(link-login-only)';
    form.style.display = 'none';
    
    // Add necessary fields
    const fields = {
        username: username,
        password: password,
        dst: '$(link-orig)',
        popup: 'true'
    };
    
    for (const key in fields) {
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = key;
        input.value = fields[key];
        form.appendChild(input);
    }
    
    // Add form to document and submit
    document.body.appendChild(form);
    form.submit();
}

/**
 * Show or hide loading indicators
 * @param {boolean} show - Whether to show loading indicators
 */
function showLoading(show) {
    if (show) {
        loadingSpinner.style.display = 'block';
        wifiSignal.style.display = 'none';
    } else {
        loadingSpinner.style.display = 'none';
        wifiSignal.style.display = 'block';
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', init);