/**
 * Creates a standardized error object
 * @param {number} statusCode - HTTP status code
 * @param {string} message - Error message
 * @param {Error|null} originalError - Original error object (optional)
 * @returns {Error} - Enhanced error object
 */
const createError = (statusCode, message, originalError = null) => {
  const error = new Error(message);
  error.statusCode = statusCode;
  
  // Add original error details if provided
  if (originalError) {
    error.stack = originalError.stack;
    error.originalError = originalError;
  }
  
  return error;
};

/**
 * Formats validation errors from express-validator
 * @param {Array} errors - Array of validation errors
 * @returns {Object} - Formatted error object
 */
const formatValidationErrors = (errors) => {
  const formattedErrors = {};
  
  errors.forEach(error => {
    formattedErrors[error.param] = error.msg;
  });
  
  return {
    message: 'Validation failed',
    errors: formattedErrors
  };
};

/**
 * Formats Sequelize validation errors
 * @param {Error} error - Sequelize validation error
 * @returns {Object} - Formatted error object
 */
const formatSequelizeErrors = (error) => {
  const formattedErrors = {};
  
  error.errors.forEach(err => {
    formattedErrors[err.path] = err.message;
  });
  
  return {
    message: 'Validation failed',
    errors: formattedErrors
  };
};

/**
 * Formats JWT errors
 * @param {Error} error - JWT error
 * @returns {Object} - Formatted error object
 */
const formatJwtError = (error) => {
  let message = 'Authentication failed';
  
  if (error.name === 'TokenExpiredError') {
    message = 'Token expired';
  } else if (error.name === 'JsonWebTokenError') {
    message = 'Invalid token';
  } else if (error.name === 'NotBeforeError') {
    message = 'Token not active';
  }
  
  return { message };
};

/**
 * Determines if an error is a Sequelize validation error
 * @param {Error} error - Error to check
 * @returns {boolean} - True if it's a Sequelize validation error
 */
const isSequelizeValidationError = (error) => {
  return error.name === 'SequelizeValidationError' || 
         error.name === 'SequelizeUniqueConstraintError';
};

/**
 * Determines if an error is a JWT error
 * @param {Error} error - Error to check
 * @returns {boolean} - True if it's a JWT error
 */
const isJwtError = (error) => {
  return error.name === 'JsonWebTokenError' || 
         error.name === 'TokenExpiredError' || 
         error.name === 'NotBeforeError';
};

module.exports = {
  createError,
  formatValidationErrors,
  formatSequelizeErrors,
  formatJwtError,
  isSequelizeValidationError,
  isJwtError
};