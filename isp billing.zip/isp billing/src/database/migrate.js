require('dotenv').config();
const { sequelize } = require('./config');
const User = require('../models/User');
const Role = require('../models/Role');
const Plan = require('../models/Plan');
const Voucher = require('../models/Voucher');
const Transaction = require('../models/Transaction');
const Session = require('../models/Session');
const Router = require('../models/Router');
const Notification = require('../models/Notification');

// Define model associations
const setupAssociations = () => {
  // User associations
  User.belongsTo(Role);
  User.hasMany(Transaction);
  User.hasMany(Session);
  User.hasMany(Notification);
  User.hasMany(Voucher);

  // Role associations
  Role.hasMany(User);

  // Plan associations
  Plan.hasMany(Transaction);
  Plan.hasMany(Voucher);

  // Voucher associations
  Voucher.belongsTo(Plan);
  Voucher.belongsTo(User);

  // Transaction associations
  Transaction.belongsTo(User);
  Transaction.belongsTo(Plan);

  // Session associations
  Session.belongsTo(User);

  // Router associations
  Router.hasMany(Session);

  // Notification associations
  Notification.belongsTo(User);
};

// Sync all models with database
const migrateDatabase = async () => {
  try {
    // Setup model associations
    setupAssociations();

    // Sync all models with database
    await sequelize.sync({ alter: true });
    console.log('Database migration completed successfully.');

    // Create default roles if they don't exist
    await createDefaultRoles();
    
    // Create admin user if it doesn't exist
    await createAdminUser();

    process.exit(0);
  } catch (error) {
    console.error('Database migration failed:', error);
    process.exit(1);
  }
};

// Create default roles
const createDefaultRoles = async () => {
  const roles = [
    { name: 'admin', description: 'Administrator with full access' },
    { name: 'manager', description: 'Manager with limited administrative access' },
    { name: 'user', description: 'Regular user with basic access' }
  ];

  for (const role of roles) {
    await Role.findOrCreate({
      where: { name: role.name },
      defaults: role
    });
  }

  console.log('Default roles created successfully.');
};

// Create admin user
const createAdminUser = async () => {
  const adminRole = await Role.findOne({ where: { name: 'admin' } });
  
  if (!adminRole) {
    throw new Error('Admin role not found');
  }

  const [admin, created] = await User.findOrCreate({
    where: { email: 'admin@example.com' },
    defaults: {
      username: 'admin',
      password: 'admin123', // Will be hashed by the model hook
      full_name: 'System Administrator',
      phone: '1234567890',
      role_id: adminRole.id,
      is_active: true
    }
  });

  if (created) {
    console.log('Admin user created successfully.');
  } else {
    console.log('Admin user already exists.');
  }
};

// Run migration
migrateDatabase();