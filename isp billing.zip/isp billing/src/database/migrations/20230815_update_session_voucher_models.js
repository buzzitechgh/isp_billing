/**
 * Migration to update Session and Voucher models for hotspot integration
 */

const { DataTypes } = require('sequelize');

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Update Session model
    await queryInterface.changeColumn('sessions', 'user_id', {
      type: DataTypes.UUID,
      allowNull: true,
      references: {
        model: 'users',
        key: 'id'
      }
    });
    
    await queryInterface.addColumn('sessions', 'is_trial', {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false
    });
    
    await queryInterface.addColumn('sessions', 'plan_id', {
      type: DataTypes.UUID,
      allowNull: true,
      references: {
        model: 'plans',
        key: 'id'
      }
    });
    
    await queryInterface.addColumn('sessions', 'voucher_id', {
      type: DataTypes.UUID,
      allowNull: true,
      references: {
        model: 'vouchers',
        key: 'id'
      }
    });
    
    // Update Voucher model
    await queryInterface.renameColumn('vouchers', 'activation_date', 'redeemed_at');
    
    await queryInterface.addColumn('vouchers', 'redeemed_by', {
      type: DataTypes.STRING,
      allowNull: true,
      comment: 'MAC address of the device that redeemed this voucher'
    });
  },

  down: async (queryInterface, Sequelize) => {
    // Revert Session model changes
    await queryInterface.changeColumn('sessions', 'user_id', {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      }
    });
    
    await queryInterface.removeColumn('sessions', 'is_trial');
    await queryInterface.removeColumn('sessions', 'plan_id');
    await queryInterface.removeColumn('sessions', 'voucher_id');
    
    // Revert Voucher model changes
    await queryInterface.renameColumn('vouchers', 'redeemed_at', 'activation_date');
    await queryInterface.removeColumn('vouchers', 'redeemed_by');
  }
};