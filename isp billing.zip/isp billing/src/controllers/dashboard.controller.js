const { User, Plan, Transaction, Session, Router, Voucher } = require('../models');
const { createError } = require('../utils/errorUtils');
const { Op, Sequelize } = require('sequelize');
const moment = require('moment');

/**
 * Get dashboard statistics
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getDashboardStats = async (req, res, next) => {
  try {
    // Get time periods for different stats
    const today = moment().startOf('day');
    const yesterday = moment().subtract(1, 'days').startOf('day');
    const thisWeekStart = moment().startOf('week');
    const thisMonthStart = moment().startOf('month');
    const lastMonthStart = moment().subtract(1, 'month').startOf('month');
    const lastMonthEnd = moment().subtract(1, 'month').endOf('month');
    
    // Get user stats
    const totalUsers = await User.count();
    const newUsersToday = await User.count({
      where: {
        created_at: {
          [Op.gte]: today.toDate()
        }
      }
    });
    const newUsersThisWeek = await User.count({
      where: {
        created_at: {
          [Op.gte]: thisWeekStart.toDate()
        }
      }
    });
    const newUsersThisMonth = await User.count({
      where: {
        created_at: {
          [Op.gte]: thisMonthStart.toDate()
        }
      }
    });
    const activeUsers = await User.count({
      where: {
        is_active: true
      }
    });
    
    // Get revenue stats
    const totalRevenue = await Transaction.sum('amount', {
      where: {
        status: 'completed'
      }
    }) || 0;
    
    const revenueToday = await Transaction.sum('amount', {
      where: {
        status: 'completed',
        created_at: {
          [Op.gte]: today.toDate()
        }
      }
    }) || 0;
    
    const revenueThisWeek = await Transaction.sum('amount', {
      where: {
        status: 'completed',
        created_at: {
          [Op.gte]: thisWeekStart.toDate()
        }
      }
    }) || 0;
    
    const revenueThisMonth = await Transaction.sum('amount', {
      where: {
        status: 'completed',
        created_at: {
          [Op.gte]: thisMonthStart.toDate()
        }
      }
    }) || 0;
    
    const revenueLastMonth = await Transaction.sum('amount', {
      where: {
        status: 'completed',
        created_at: {
          [Op.between]: [lastMonthStart.toDate(), lastMonthEnd.toDate()]
        }
      }
    }) || 0;
    
    // Calculate revenue growth
    const revenueGrowth = lastMonthStart && revenueLastMonth > 0
      ? ((revenueThisMonth - revenueLastMonth) / revenueLastMonth) * 100
      : 0;
    
    // Get transaction stats
    const totalTransactions = await Transaction.count({
      where: {
        status: 'completed'
      }
    });
    
    const transactionsToday = await Transaction.count({
      where: {
        status: 'completed',
        created_at: {
          [Op.gte]: today.toDate()
        }
      }
    });
    
    // Get session stats
    const activeSessions = await Session.count({
      where: {
        status: 'active'
      }
    });
    
    const sessionsToday = await Session.count({
      where: {
        start_time: {
          [Op.gte]: today.toDate()
        }
      }
    });
    
    // Get router stats
    const totalRouters = await Router.count();
    const activeRouters = await Router.count({
      where: {
        status: 'active'
      }
    });
    
    // Get plan stats
    const totalPlans = await Plan.count();
    const activePlans = await Plan.count({
      where: {
        is_active: true
      }
    });
    
    // Get voucher stats
    const totalVouchers = await Voucher.count();
    const unusedVouchers = await Voucher.count({
      where: {
        status: 'unused'
      }
    });
    
    // Get payment method distribution
    const paymentMethods = await Transaction.findAll({
      attributes: [
        'payment_method',
        [Sequelize.fn('COUNT', Sequelize.col('id')), 'count'],
        [Sequelize.fn('SUM', Sequelize.col('amount')), 'total']
      ],
      where: {
        status: 'completed'
      },
      group: ['payment_method']
    });
    
    // Format payment methods data
    const paymentMethodsData = paymentMethods.map(method => ({
      method: method.payment_method,
      count: parseInt(method.getDataValue('count')),
      total: parseFloat(method.getDataValue('total') || 0)
    }));
    
    // Get daily revenue for the last 30 days
    const last30Days = [];
    for (let i = 0; i < 30; i++) {
      last30Days.push(moment().subtract(i, 'days').format('YYYY-MM-DD'));
    }
    
    const dailyRevenue = await Transaction.findAll({
      attributes: [
        [Sequelize.fn('DATE', Sequelize.col('created_at')), 'date'],
        [Sequelize.fn('SUM', Sequelize.col('amount')), 'total']
      ],
      where: {
        status: 'completed',
        created_at: {
          [Op.gte]: moment().subtract(30, 'days').startOf('day').toDate()
        }
      },
      group: [Sequelize.fn('DATE', Sequelize.col('created_at'))],
      order: [[Sequelize.fn('DATE', Sequelize.col('created_at')), 'ASC']]
    });
    
    // Format daily revenue data
    const dailyRevenueData = {};
    last30Days.forEach(date => {
      dailyRevenueData[date] = 0;
    });
    
    dailyRevenue.forEach(day => {
      const date = moment(day.getDataValue('date')).format('YYYY-MM-DD');
      dailyRevenueData[date] = parseFloat(day.getDataValue('total') || 0);
    });
    
    // Get top selling plans
    const topPlans = await Transaction.findAll({
      attributes: [
        'metadata',
        [Sequelize.fn('COUNT', Sequelize.col('id')), 'count'],
        [Sequelize.fn('SUM', Sequelize.col('amount')), 'total']
      ],
      where: {
        status: 'completed',
        metadata: {
          [Op.not]: null
        }
      },
      group: ['metadata'],
      order: [[Sequelize.fn('SUM', Sequelize.col('amount')), 'DESC']],
      limit: 5
    });
    
    // Format top plans data
    const topPlansData = topPlans.map(plan => {
      const metadata = plan.metadata || {};
      return {
        plan_id: metadata.plan_id,
        plan_name: metadata.plan_name || 'Unknown Plan',
        count: parseInt(plan.getDataValue('count')),
        total: parseFloat(plan.getDataValue('total') || 0)
      };
    });
    
    // Get recent transactions
    const recentTransactions = await Transaction.findAll({
      include: [{ model: User, attributes: ['id', 'username', 'email', 'full_name'] }],
      order: [['created_at', 'DESC']],
      limit: 10
    });
    
    // Format recent transactions
    const formattedTransactions = recentTransactions.map(transaction => ({
      id: transaction.id,
      reference: transaction.reference,
      amount: parseFloat(transaction.amount),
      payment_method: transaction.payment_method,
      status: transaction.status,
      user: transaction.User ? {
        id: transaction.User.id,
        username: transaction.User.username,
        full_name: transaction.User.full_name
      } : null,
      created_at: transaction.created_at
    }));
    
    // Get recent users
    const recentUsers = await User.findAll({
      attributes: ['id', 'username', 'email', 'full_name', 'is_active', 'created_at'],
      order: [['created_at', 'DESC']],
      limit: 10
    });
    
    // Prepare response data
    const dashboardData = {
      users: {
        total: totalUsers,
        active: activeUsers,
        new_today: newUsersToday,
        new_this_week: newUsersThisWeek,
        new_this_month: newUsersThisMonth
      },
      revenue: {
        total: parseFloat(totalRevenue).toFixed(2),
        today: parseFloat(revenueToday).toFixed(2),
        this_week: parseFloat(revenueThisWeek).toFixed(2),
        this_month: parseFloat(revenueThisMonth).toFixed(2),
        last_month: parseFloat(revenueLastMonth).toFixed(2),
        growth_percentage: revenueGrowth.toFixed(2)
      },
      transactions: {
        total: totalTransactions,
        today: transactionsToday
      },
      sessions: {
        active: activeSessions,
        today: sessionsToday
      },
      routers: {
        total: totalRouters,
        active: activeRouters
      },
      plans: {
        total: totalPlans,
        active: activePlans
      },
      vouchers: {
        total: totalVouchers,
        unused: unusedVouchers
      },
      charts: {
        payment_methods: paymentMethodsData,
        daily_revenue: dailyRevenueData,
        top_plans: topPlansData
      },
      recent: {
        transactions: formattedTransactions,
        users: recentUsers
      }
    };
    
    res.status(200).json({
      success: true,
      data: dashboardData
    });
  } catch (error) {
    next(createError(500, 'Error retrieving dashboard statistics', error));
  }
};

/**
 * Get user statistics
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getUserStats = async (req, res, next) => {
  try {
    // Get time periods
    const last7Days = moment().subtract(7, 'days').startOf('day').toDate();
    const last30Days = moment().subtract(30, 'days').startOf('day').toDate();
    const last90Days = moment().subtract(90, 'days').startOf('day').toDate();
    
    // Get user counts by period
    const total = await User.count();
    const last7DaysCount = await User.count({
      where: {
        created_at: {
          [Op.gte]: last7Days
        }
      }
    });
    const last30DaysCount = await User.count({
      where: {
        created_at: {
          [Op.gte]: last30Days
        }
      }
    });
    const last90DaysCount = await User.count({
      where: {
        created_at: {
          [Op.gte]: last90Days
        }
      }
    });
    
    // Get active vs inactive users
    const activeUsers = await User.count({
      where: {
        is_active: true
      }
    });
    const inactiveUsers = total - activeUsers;
    
    // Get users by role
    const usersByRole = await User.findAll({
      attributes: [
        'role_id',
        [Sequelize.fn('COUNT', Sequelize.col('id')), 'count']
      ],
      group: ['role_id']
    });
    
    // Format users by role
    const roleData = usersByRole.map(role => ({
      role_id: role.role_id,
      count: parseInt(role.getDataValue('count'))
    }));
    
    // Get daily signups for the last 30 days
    const dailySignups = await User.findAll({
      attributes: [
        [Sequelize.fn('DATE', Sequelize.col('created_at')), 'date'],
        [Sequelize.fn('COUNT', Sequelize.col('id')), 'count']
      ],
      where: {
        created_at: {
          [Op.gte]: last30Days
        }
      },
      group: [Sequelize.fn('DATE', Sequelize.col('created_at'))],
      order: [[Sequelize.fn('DATE', Sequelize.col('created_at')), 'ASC']]
    });
    
    // Format daily signups
    const dailySignupsData = {};
    for (let i = 0; i < 30; i++) {
      const date = moment().subtract(i, 'days').format('YYYY-MM-DD');
      dailySignupsData[date] = 0;
    }
    
    dailySignups.forEach(day => {
      const date = moment(day.getDataValue('date')).format('YYYY-MM-DD');
      dailySignupsData[date] = parseInt(day.getDataValue('count'));
    });
    
    // Prepare response data
    const userData = {
      total,
      active: activeUsers,
      inactive: inactiveUsers,
      periods: {
        last_7_days: last7DaysCount,
        last_30_days: last30DaysCount,
        last_90_days: last90DaysCount
      },
      by_role: roleData,
      daily_signups: dailySignupsData
    };
    
    res.status(200).json({
      success: true,
      data: userData
    });
  } catch (error) {
    next(createError(500, 'Error retrieving user statistics', error));
  }
};

/**
 * Get revenue statistics
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getRevenueStats = async (req, res, next) => {
  try {
    // Get time periods
    const today = moment().startOf('day').toDate();
    const yesterday = moment().subtract(1, 'days').startOf('day').toDate();
    const thisWeekStart = moment().startOf('week').toDate();
    const lastWeekStart = moment().subtract(1, 'week').startOf('week').toDate();
    const lastWeekEnd = moment().subtract(1, 'week').endOf('week').toDate();
    const thisMonthStart = moment().startOf('month').toDate();
    const lastMonthStart = moment().subtract(1, 'month').startOf('month').toDate();
    const lastMonthEnd = moment().subtract(1, 'month').endOf('month').toDate();
    
    // Get revenue by period
    const totalRevenue = await Transaction.sum('amount', {
      where: {
        status: 'completed'
      }
    }) || 0;
    
    const todayRevenue = await Transaction.sum('amount', {
      where: {
        status: 'completed',
        created_at: {
          [Op.gte]: today
        }
      }
    }) || 0;
    
    const yesterdayRevenue = await Transaction.sum('amount', {
      where: {
        status: 'completed',
        created_at: {
          [Op.between]: [yesterday, today]
        }
      }
    }) || 0;
    
    const thisWeekRevenue = await Transaction.sum('amount', {
      where: {
        status: 'completed',
        created_at: {
          [Op.gte]: thisWeekStart
        }
      }
    }) || 0;
    
    const lastWeekRevenue = await Transaction.sum('amount', {
      where: {
        status: 'completed',
        created_at: {
          [Op.between]: [lastWeekStart, lastWeekEnd]
        }
      }
    }) || 0;
    
    const thisMonthRevenue = await Transaction.sum('amount', {
      where: {
        status: 'completed',
        created_at: {
          [Op.gte]: thisMonthStart
        }
      }
    }) || 0;
    
    const lastMonthRevenue = await Transaction.sum('amount', {
      where: {
        status: 'completed',
        created_at: {
          [Op.between]: [lastMonthStart, lastMonthEnd]
        }
      }
    }) || 0;
    
    // Calculate growth rates
    const dayGrowth = yesterdayRevenue > 0 
      ? ((todayRevenue - yesterdayRevenue) / yesterdayRevenue) * 100 
      : 0;
      
    const weekGrowth = lastWeekRevenue > 0 
      ? ((thisWeekRevenue - lastWeekRevenue) / lastWeekRevenue) * 100 
      : 0;
      
    const monthGrowth = lastMonthRevenue > 0 
      ? ((thisMonthRevenue - lastMonthRevenue) / lastMonthRevenue) * 100 
      : 0;
    
    // Get revenue by payment method
    const revenueByMethod = await Transaction.findAll({
      attributes: [
        'payment_method',
        [Sequelize.fn('SUM', Sequelize.col('amount')), 'total']
      ],
      where: {
        status: 'completed'
      },
      group: ['payment_method'],
      order: [[Sequelize.fn('SUM', Sequelize.col('amount')), 'DESC']]
    });
    
    // Format revenue by method
    const methodData = revenueByMethod.map(method => ({
      method: method.payment_method,
      total: parseFloat(method.getDataValue('total') || 0)
    }));
    
    // Get revenue by plan
    const revenueByPlan = await Transaction.findAll({
      attributes: [
        'metadata',
        [Sequelize.fn('SUM', Sequelize.col('amount')), 'total'],
        [Sequelize.fn('COUNT', Sequelize.col('id')), 'count']
      ],
      where: {
        status: 'completed',
        metadata: {
          [Op.not]: null
        }
      },
      group: ['metadata'],
      order: [[Sequelize.fn('SUM', Sequelize.col('amount')), 'DESC']]
    });
    
    // Format revenue by plan
    const planData = revenueByPlan.map(plan => {
      const metadata = plan.metadata || {};
      return {
        plan_id: metadata.plan_id,
        plan_name: metadata.plan_name || 'Unknown Plan',
        total: parseFloat(plan.getDataValue('total') || 0),
        count: parseInt(plan.getDataValue('count'))
      };
    });
    
    // Get monthly revenue for the last 12 months
    const monthlyRevenue = [];
    for (let i = 0; i < 12; i++) {
      const startOfMonth = moment().subtract(i, 'months').startOf('month');
      const endOfMonth = moment().subtract(i, 'months').endOf('month');
      
      const revenue = await Transaction.sum('amount', {
        where: {
          status: 'completed',
          created_at: {
            [Op.between]: [startOfMonth.toDate(), endOfMonth.toDate()]
          }
        }
      }) || 0;
      
      monthlyRevenue.unshift({
        month: startOfMonth.format('YYYY-MM'),
        month_name: startOfMonth.format('MMM YYYY'),
        total: parseFloat(revenue)
      });
    }
    
    // Prepare response data
    const revenueData = {
      total: parseFloat(totalRevenue).toFixed(2),
      periods: {
        today: parseFloat(todayRevenue).toFixed(2),
        yesterday: parseFloat(yesterdayRevenue).toFixed(2),
        this_week: parseFloat(thisWeekRevenue).toFixed(2),
        last_week: parseFloat(lastWeekRevenue).toFixed(2),
        this_month: parseFloat(thisMonthRevenue).toFixed(2),
        last_month: parseFloat(lastMonthRevenue).toFixed(2)
      },
      growth: {
        day: dayGrowth.toFixed(2),
        week: weekGrowth.toFixed(2),
        month: monthGrowth.toFixed(2)
      },
      by_payment_method: methodData,
      by_plan: planData,
      monthly: monthlyRevenue
    };
    
    res.status(200).json({
      success: true,
      data: revenueData
    });
  } catch (error) {
    next(createError(500, 'Error retrieving revenue statistics', error));
  }
};

/**
 * Get session statistics
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getSessionStats = async (req, res, next) => {
  try {
    // Get time periods
    const today = moment().startOf('day').toDate();
    const yesterday = moment().subtract(1, 'days').startOf('day').toDate();
    const last7Days = moment().subtract(7, 'days').startOf('day').toDate();
    const last30Days = moment().subtract(30, 'days').startOf('day').toDate();
    
    // Get session counts by period
    const totalSessions = await Session.count();
    const activeSessions = await Session.count({
      where: {
        status: 'active'
      }
    });
    
    const todaySessions = await Session.count({
      where: {
        start_time: {
          [Op.gte]: today
        }
      }
    });
    
    const yesterdaySessions = await Session.count({
      where: {
        start_time: {
          [Op.between]: [yesterday, today]
        }
      }
    });
    
    const last7DaysSessions = await Session.count({
      where: {
        start_time: {
          [Op.gte]: last7Days
        }
      }
    });
    
    const last30DaysSessions = await Session.count({
      where: {
        start_time: {
          [Op.gte]: last30Days
        }
      }
    });
    
    // Get sessions by router
    const sessionsByRouter = await Session.findAll({
      attributes: [
        'router_id',
        [Sequelize.fn('COUNT', Sequelize.col('id')), 'count']
      ],
      include: [{ model: Router, attributes: ['name'] }],
      group: ['router_id', 'Router.id'],
      order: [[Sequelize.fn('COUNT', Sequelize.col('id')), 'DESC']]
    });
    
    // Format sessions by router
    const routerData = sessionsByRouter.map(router => ({
      router_id: router.router_id,
      router_name: router.Router ? router.Router.name : 'Unknown Router',
      count: parseInt(router.getDataValue('count'))
    }));
    
    // Get daily sessions for the last 30 days
    const dailySessions = await Session.findAll({
      attributes: [
        [Sequelize.fn('DATE', Sequelize.col('start_time')), 'date'],
        [Sequelize.fn('COUNT', Sequelize.col('id')), 'count']
      ],
      where: {
        start_time: {
          [Op.gte]: last30Days
        }
      },
      group: [Sequelize.fn('DATE', Sequelize.col('start_time'))],
      order: [[Sequelize.fn('DATE', Sequelize.col('start_time')), 'ASC']]
    });
    
    // Format daily sessions
    const dailySessionsData = {};
    for (let i = 0; i < 30; i++) {
      const date = moment().subtract(i, 'days').format('YYYY-MM-DD');
      dailySessionsData[date] = 0;
    }
    
    dailySessions.forEach(day => {
      const date = moment(day.getDataValue('date')).format('YYYY-MM-DD');
      dailySessionsData[date] = parseInt(day.getDataValue('count'));
    });
    
    // Get data usage statistics
    const totalDownload = await Session.sum('bytes_down') || 0;
    const totalUpload = await Session.sum('bytes_up') || 0;
    const totalData = totalDownload + totalUpload;
    
    // Format data size
    const formatBytes = (bytes) => {
      if (bytes === 0) return '0 Bytes';
      const k = 1024;
      const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };
    
    // Prepare response data
    const sessionData = {
      total: totalSessions,
      active: activeSessions,
      periods: {
        today: todaySessions,
        yesterday: yesterdaySessions,
        last_7_days: last7DaysSessions,
        last_30_days: last30DaysSessions
      },
      by_router: routerData,
      daily_sessions: dailySessionsData,
      data_usage: {
        download: formatBytes(totalDownload),
        upload: formatBytes(totalUpload),
        total: formatBytes(totalData)
      }
    };
    
    res.status(200).json({
      success: true,
      data: sessionData
    });
  } catch (error) {
    next(createError(500, 'Error retrieving session statistics', error));
  }
};

module.exports = {
  getDashboardStats,
  getUserStats,
  getRevenueStats,
  getSessionStats
};