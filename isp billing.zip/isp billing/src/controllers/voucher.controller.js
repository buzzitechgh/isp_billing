const { Voucher, Plan, User, Transaction } = require('../models');
const { validationResult } = require('express-validator');
const { createError, formatValidationErrors } = require('../utils/errorUtils');
const { Op } = require('sequelize');
const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');
const csv = require('fast-csv');

/**
 * Get all vouchers with pagination
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getAllVouchers = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const search = req.query.search || '';
    const status = req.query.status;
    const batchName = req.query.batch_name;
    
    // Build query conditions
    const whereConditions = {};
    
    if (search) {
      whereConditions[Op.or] = [
        { code: { [Op.like]: `%${search}%` } },
        { batch_name: { [Op.like]: `%${search}%` } }
      ];
    }
    
    if (status) {
      whereConditions.status = status;
    }
    
    if (batchName) {
      whereConditions.batch_name = batchName;
    }
    
    // Get vouchers with pagination
    const { count, rows: vouchers } = await Voucher.findAndCountAll({
      where: whereConditions,
      limit,
      offset,
      order: [['created_at', 'DESC']],
      include: [{ model: Plan }]
    });
    
    // Calculate pagination info
    const totalPages = Math.ceil(count / limit);
    
    res.status(200).json({
      success: true,
      data: {
        vouchers,
        pagination: {
          total: count,
          page,
          limit,
          totalPages
        }
      }
    });
  } catch (error) {
    next(createError(500, 'Error retrieving vouchers', error));
  }
};

/**
 * Get voucher by ID
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getVoucherById = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    const voucher = await Voucher.findByPk(id, {
      include: [{ model: Plan }]
    });
    
    if (!voucher) {
      return next(createError(404, 'Voucher not found'));
    }
    
    res.status(200).json({
      success: true,
      data: voucher
    });
  } catch (error) {
    next(createError(500, 'Error retrieving voucher', error));
  }
};

/**
 * Generate batch of vouchers
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const generateVoucherBatch = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const { plan_id, quantity, prefix, length, batch_name, expiry_date } = req.body;
    
    // Find the plan
    const plan = await Plan.findByPk(plan_id);
    
    if (!plan) {
      return next(createError(404, 'Plan not found'));
    }
    
    // Generate batch name if not provided
    const batchNameToUse = batch_name || `BATCH-${Date.now()}`;
    
    // Generate vouchers
    const vouchers = await Voucher.generateBatch({
      plan_id,
      quantity: parseInt(quantity),
      prefix: prefix || '',
      length: length || 8,
      batch_name: batchNameToUse,
      expiry_date: expiry_date || null,
      created_by: req.user.id
    });
    
    res.status(201).json({
      success: true,
      message: `${quantity} vouchers generated successfully`,
      data: {
        batch_name: batchNameToUse,
        plan_name: plan.name,
        quantity: vouchers.length,
        vouchers: vouchers.map(v => ({
          id: v.id,
          code: v.code,
          status: v.status
        }))
      }
    });
  } catch (error) {
    next(createError(500, 'Error generating vouchers', error));
  }
};

/**
 * Create a single voucher
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const createVoucher = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const { plan_id, code, expiry_date } = req.body;
    
    // Find the plan
    const plan = await Plan.findByPk(plan_id);
    
    if (!plan) {
      return next(createError(404, 'Plan not found'));
    }
    
    // Create the voucher
    const voucher = await Voucher.create({
      plan_id,
      code: code || Voucher.generateCode(8),
      status: 'unused',
      expiry_date: expiry_date || null,
      batch_name: `SINGLE-${Date.now()}`,
      created_by: req.user.id
    });
    
    res.status(201).json({
      success: true,
      message: 'Voucher created successfully',
      data: {
        id: voucher.id,
        code: voucher.code,
        plan_id: voucher.plan_id,
        plan_name: plan.name,
        status: voucher.status,
        expiry_date: voucher.expiry_date
      }
    });
  } catch (error) {
    next(createError(500, 'Error creating voucher', error));
  }
};

/**
 * Validate a voucher code
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const validateVoucher = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const { code } = req.body;
    
    // Find the voucher
    const voucher = await Voucher.findOne({
      where: { code },
      include: [{ model: Plan }]
    });
    
    if (!voucher) {
      return res.status(200).json({
        success: false,
        message: 'Invalid voucher code',
        data: { valid: false }
      });
    }
    
    if (voucher.status !== 'unused') {
      return res.status(200).json({
        success: false,
        message: `Voucher has already been ${voucher.status}`,
        data: { valid: false, status: voucher.status }
      });
    }
    
    if (voucher.expiry_date && new Date(voucher.expiry_date) < new Date()) {
      return res.status(200).json({
        success: false,
        message: 'Voucher has expired',
        data: { valid: false, expired: true }
      });
    }
    
    res.status(200).json({
      success: true,
      message: 'Valid voucher code',
      data: {
        valid: true,
        voucher: {
          id: voucher.id,
          code: voucher.code,
          plan: {
            id: voucher.Plan.id,
            name: voucher.Plan.name,
            type: voucher.Plan.type,
            duration: voucher.Plan.duration,
            price: voucher.Plan.price,
            download_speed: voucher.Plan.download_speed,
            upload_speed: voucher.Plan.upload_speed
          }
        }
      }
    });
  } catch (error) {
    next(createError(500, 'Error validating voucher', error));
  }
};

/**
 * Redeem a voucher
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const redeemVoucher = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const { code, username, phone } = req.body;
    
    // Find the voucher
    const voucher = await Voucher.findOne({
      where: { code },
      include: [{ model: Plan }]
    });
    
    if (!voucher) {
      return next(createError(404, 'Invalid voucher code'));
    }
    
    if (voucher.status !== 'unused') {
      return next(createError(400, `Voucher has already been ${voucher.status}`));
    }
    
    if (voucher.expiry_date && new Date(voucher.expiry_date) < new Date()) {
      return next(createError(400, 'Voucher has expired'));
    }
    
    // If user is authenticated, use their account
    let userId = null;
    if (req.user) {
      userId = req.user.id;
    } else if (username) {
      // Check if username exists
      const existingUser = await User.findOne({ where: { username } });
      
      if (existingUser) {
        userId = existingUser.id;
      } else {
        // Create a new user if username is provided
        const newUser = await User.create({
          username,
          password: Voucher.generateCode(8), // Generate a random password
          email: `${username}@example.com`, // Placeholder email
          full_name: username,
          phone: phone || null,
          role_id: 3, // Assuming 3 is the customer role
          is_active: true
        });
        
        userId = newUser.id;
      }
    }
    
    // Activate the voucher
    await voucher.update({
      status: 'used',
      activation_date: new Date(),
      user_id: userId
    });
    
    // Create a transaction record
    const transaction = await Transaction.create({
      user_id: userId,
      plan_id: voucher.plan_id,
      amount: voucher.Plan.price,
      payment_method: 'voucher',
      status: 'completed',
      reference: `VOUCHER-${voucher.code}`,
      notes: `Voucher redemption for ${voucher.Plan.name} plan`
    });
    
    // Return the credentials
    res.status(200).json({
      success: true,
      message: 'Voucher redeemed successfully',
      data: {
        transaction_id: transaction.id,
        voucher_code: voucher.code,
        mikrotik_username: voucher.mikrotik_username,
        mikrotik_password: voucher.mikrotik_password,
        plan: {
          name: voucher.Plan.name,
          duration: voucher.Plan.duration,
          type: voucher.Plan.type,
          download_speed: voucher.Plan.download_speed,
          upload_speed: voucher.Plan.upload_speed
        }
      }
    });
  } catch (error) {
    next(createError(500, 'Error redeeming voucher', error));
  }
};

/**
 * Delete voucher
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const deleteVoucher = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // Find the voucher
    const voucher = await Voucher.findByPk(id);
    
    if (!voucher) {
      return next(createError(404, 'Voucher not found'));
    }
    
    if (voucher.status === 'used') {
      return next(createError(400, 'Cannot delete a used voucher'));
    }
    
    // Delete the voucher
    await voucher.destroy();
    
    res.status(200).json({
      success: true,
      message: 'Voucher deleted successfully'
    });
  } catch (error) {
    next(createError(500, 'Error deleting voucher', error));
  }
};

/**
 * Delete voucher batch
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const deleteVoucherBatch = async (req, res, next) => {
  try {
    const { batchName } = req.params;
    
    // Find unused vouchers in the batch
    const unusedVouchers = await Voucher.findAll({
      where: {
        batch_name: batchName,
        status: 'unused'
      }
    });
    
    if (unusedVouchers.length === 0) {
      return next(createError(404, 'No unused vouchers found in this batch'));
    }
    
    // Delete the vouchers
    await Voucher.destroy({
      where: {
        batch_name: batchName,
        status: 'unused'
      }
    });
    
    res.status(200).json({
      success: true,
      message: `${unusedVouchers.length} unused vouchers deleted successfully`
    });
  } catch (error) {
    next(createError(500, 'Error deleting voucher batch', error));
  }
};

/**
 * Export voucher batch (PDF, CSV)
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const exportVoucherBatch = async (req, res, next) => {
  try {
    const { batchName } = req.params;
    const format = req.query.format || 'pdf';
    
    // Find vouchers in the batch
    const vouchers = await Voucher.findAll({
      where: { batch_name: batchName },
      include: [{ model: Plan }],
      order: [['created_at', 'ASC']]
    });
    
    if (vouchers.length === 0) {
      return next(createError(404, 'No vouchers found in this batch'));
    }
    
    if (format === 'pdf') {
      // Generate PDF
      const doc = new PDFDocument({ margin: 50 });
      
      // Set response headers
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename=vouchers-${batchName}.pdf`);
      
      // Pipe the PDF to the response
      doc.pipe(res);
      
      // Add content to the PDF
      doc.fontSize(20).text('Voucher Batch: ' + batchName, { align: 'center' });
      doc.moveDown();
      doc.fontSize(12).text(`Generated on: ${new Date().toLocaleString()}`);
      doc.moveDown();
      
      // Add voucher table
      const tableTop = 150;
      const tableLeft = 50;
      const colWidth = 100;
      
      // Table headers
      doc.fontSize(10).text('Code', tableLeft, tableTop);
      doc.text('Plan', tableLeft + colWidth, tableTop);
      doc.text('Status', tableLeft + colWidth * 2, tableTop);
      doc.text('Username', tableLeft + colWidth * 3, tableTop);
      doc.text('Password', tableLeft + colWidth * 4, tableTop);
      
      // Draw header line
      doc.moveTo(tableLeft, tableTop + 15)
         .lineTo(tableLeft + colWidth * 5, tableTop + 15)
         .stroke();
      
      // Table rows
      let rowTop = tableTop + 25;
      
      vouchers.forEach((voucher, index) => {
        // Add a new page if needed
        if (rowTop > 700) {
          doc.addPage();
          rowTop = 50;
          
          // Add headers to new page
          doc.fontSize(10).text('Code', tableLeft, rowTop);
          doc.text('Plan', tableLeft + colWidth, rowTop);
          doc.text('Status', tableLeft + colWidth * 2, rowTop);
          doc.text('Username', tableLeft + colWidth * 3, rowTop);
          doc.text('Password', tableLeft + colWidth * 4, rowTop);
          
          // Draw header line
          doc.moveTo(tableLeft, rowTop + 15)
             .lineTo(tableLeft + colWidth * 5, rowTop + 15)
             .stroke();
          
          rowTop += 25;
        }
        
        doc.fontSize(8).text(voucher.code, tableLeft, rowTop);
        doc.text(voucher.Plan.name, tableLeft + colWidth, rowTop);
        doc.text(voucher.status, tableLeft + colWidth * 2, rowTop);
        doc.text(voucher.mikrotik_username || '-', tableLeft + colWidth * 3, rowTop);
        doc.text(voucher.mikrotik_password || '-', tableLeft + colWidth * 4, rowTop);
        
        rowTop += 20;
      });
      
      // Finalize the PDF
      doc.end();
    } else if (format === 'csv') {
      // Generate CSV
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename=vouchers-${batchName}.csv`);
      
      const csvStream = csv.format({ headers: true });
      csvStream.pipe(res);
      
      vouchers.forEach(voucher => {
        csvStream.write({
          Code: voucher.code,
          Plan: voucher.Plan.name,
          Status: voucher.status,
          Username: voucher.mikrotik_username || '',
          Password: voucher.mikrotik_password || '',
          Created: voucher.created_at.toISOString(),
          Expiry: voucher.expiry_date ? new Date(voucher.expiry_date).toISOString() : ''
        });
      });
      
      csvStream.end();
    } else {
      return next(createError(400, 'Invalid export format. Supported formats: pdf, csv'));
    }
  } catch (error) {
    next(createError(500, 'Error exporting voucher batch', error));
  }
};

/**
 * Print single voucher
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const printVoucher = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // Find the voucher
    const voucher = await Voucher.findByPk(id, {
      include: [{ model: Plan }]
    });
    
    if (!voucher) {
      return next(createError(404, 'Voucher not found'));
    }
    
    // Generate PDF
    const doc = new PDFDocument({ margin: 50, size: [300, 200] });
    
    // Set response headers
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=voucher-${voucher.code}.pdf`);
    
    // Pipe the PDF to the response
    doc.pipe(res);
    
    // Add content to the PDF
    doc.fontSize(12).text('Internet Access Voucher', { align: 'center' });
    doc.moveDown(0.5);
    
    // Add a border
    doc.rect(10, 10, 280, 180).stroke();
    
    // Add voucher details
    doc.fontSize(10).text(`Plan: ${voucher.Plan.name}`, { align: 'center' });
    doc.moveDown(0.5);
    doc.fontSize(10).text(`Duration: ${voucher.Plan.duration} ${voucher.Plan.type}`, { align: 'center' });
    doc.moveDown(0.5);
    doc.fontSize(10).text(`Speed: ${voucher.Plan.download_speed}/${voucher.Plan.upload_speed} Kbps`, { align: 'center' });
    doc.moveDown(1);
    
    // Add credentials
    doc.fontSize(12).text('Voucher Code:', { align: 'center' });
    doc.fontSize(14).text(voucher.code, { align: 'center' });
    doc.moveDown(0.5);
    
    if (voucher.mikrotik_username && voucher.mikrotik_password) {
      doc.fontSize(10).text(`Username: ${voucher.mikrotik_username}`, { align: 'center' });
      doc.fontSize(10).text(`Password: ${voucher.mikrotik_password}`, { align: 'center' });
    }
    
    // Add expiry info if applicable
    if (voucher.expiry_date) {
      doc.moveDown(0.5);
      doc.fontSize(8).text(`Expires: ${new Date(voucher.expiry_date).toLocaleDateString()}`, { align: 'center' });
    }
    
    // Add instructions
    doc.moveDown(0.5);
    doc.fontSize(8).text('Connect to WiFi network and enter these credentials when prompted.', { align: 'center' });
    
    // Finalize the PDF
    doc.end();
  } catch (error) {
    next(createError(500, 'Error printing voucher', error));
  }
};

module.exports = {
  getAllVouchers,
  getVoucherById,
  generateVoucherBatch,
  createVoucher,
  validateVoucher,
  redeemVoucher,
  deleteVoucher,
  deleteVoucherBatch,
  exportVoucherBatch,
  printVoucher
};