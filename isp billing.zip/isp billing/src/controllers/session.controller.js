const { Session, User, Router } = require('../models');
const { validationResult } = require('express-validator');
const { createError, formatValidationErrors } = require('../utils/errorUtils');
const { Op } = require('sequelize');
const MikroTikService = require('../services/MikroTikService');
const sequelize = require('sequelize');
const moment = require('moment');

/**
 * Get all sessions with pagination
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getAllSessions = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const search = req.query.search || '';
    const status = req.query.status || 'active'; // 'active', 'ended', 'all'
    const routerId = req.query.router_id;
    const userId = req.query.user_id;
    
    // Build query conditions
    const whereConditions = {};
    
    if (search) {
      whereConditions[Op.or] = [
        { session_id: { [Op.like]: `%${search}%` } },
        { username: { [Op.like]: `%${search}%` } },
        { ip_address: { [Op.like]: `%${search}%` } },
        { mac_address: { [Op.like]: `%${search}%` } },
        { '$User.full_name$': { [Op.like]: `%${search}%` } }
      ];
    }
    
    if (status !== 'all') {
      whereConditions.status = status;
    }
    
    if (routerId) {
      whereConditions.router_id = routerId;
    }
    
    if (userId) {
      whereConditions.user_id = userId;
    }
    
    // Get sessions with pagination
    const { count, rows: sessions } = await Session.findAndCountAll({
      where: whereConditions,
      limit,
      offset,
      order: [['start_time', 'DESC']],
      include: [
        { model: User, attributes: ['id', 'username', 'email', 'full_name'] },
        { model: Router, attributes: ['id', 'name', 'ip_address', 'location'] }
      ]
    });
    
    // Calculate pagination info
    const totalPages = Math.ceil(count / limit);
    
    res.status(200).json({
      success: true,
      data: {
        sessions,
        pagination: {
          total: count,
          page,
          limit,
          totalPages
        }
      }
    });
  } catch (error) {
    next(createError(500, 'Error retrieving sessions', error));
  }
};

/**
 * Get active sessions
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getActiveSessions = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const search = req.query.search || '';
    const routerId = req.query.router_id;
    
    // Build query conditions
    const whereConditions = {
      status: 'active'
    };
    
    if (search) {
      whereConditions[Op.or] = [
        { session_id: { [Op.like]: `%${search}%` } },
        { username: { [Op.like]: `%${search}%` } },
        { ip_address: { [Op.like]: `%${search}%` } },
        { mac_address: { [Op.like]: `%${search}%` } },
        { '$User.full_name$': { [Op.like]: `%${search}%` } }
      ];
    }
    
    if (routerId) {
      whereConditions.router_id = routerId;
    }
    
    // Get active sessions with pagination
    const { count, rows: sessions } = await Session.findAndCountAll({
      where: whereConditions,
      limit,
      offset,
      order: [['start_time', 'DESC']],
      include: [
        { model: User, attributes: ['id', 'username', 'email', 'full_name'] },
        { model: Router, attributes: ['id', 'name', 'ip_address', 'location'] }
      ]
    });
    
    // Calculate pagination info
    const totalPages = Math.ceil(count / limit);
    
    res.status(200).json({
      success: true,
      data: {
        sessions,
        pagination: {
          total: count,
          page,
          limit,
          totalPages
        }
      }
    });
  } catch (error) {
    next(createError(500, 'Error retrieving active sessions', error));
  }
};

/**
 * Get session by ID
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getSessionById = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    const session = await Session.findByPk(id, {
      include: [
        { model: User, attributes: ['id', 'username', 'email', 'full_name'] },
        { model: Router, attributes: ['id', 'name', 'ip_address', 'location'] }
      ]
    });
    
    if (!session) {
      return next(createError(404, 'Session not found'));
    }
    
    // Check if user is authorized to view this session
    if (req.user.role_id !== 1 && req.user.role_id !== 2 && req.user.id !== session.user_id) {
      return next(createError(403, 'You are not authorized to view this session'));
    }
    
    res.status(200).json({
      success: true,
      data: session
    });
  } catch (error) {
    next(createError(500, 'Error retrieving session', error));
  }
};

/**
 * Get sessions by user ID
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getSessionsByUserId = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const status = req.query.status || 'all'; // 'active', 'ended', 'all'
    
    // Check if user exists
    const user = await User.findByPk(userId);
    if (!user) {
      return next(createError(404, 'User not found'));
    }
    
    // Check if user is authorized to view these sessions
    if (req.user.role_id !== 1 && req.user.role_id !== 2 && req.user.id !== parseInt(userId)) {
      return next(createError(403, 'You are not authorized to view these sessions'));
    }
    
    // Build query conditions
    const whereConditions = {
      user_id: userId
    };
    
    if (status !== 'all') {
      whereConditions.status = status;
    }
    
    // Get sessions with pagination
    const { count, rows: sessions } = await Session.findAndCountAll({
      where: whereConditions,
      limit,
      offset,
      order: [['start_time', 'DESC']],
      include: [
        { model: Router, attributes: ['id', 'name', 'ip_address', 'location'] }
      ]
    });
    
    // Calculate pagination info
    const totalPages = Math.ceil(count / limit);
    
    res.status(200).json({
      success: true,
      data: {
        sessions,
        pagination: {
          total: count,
          page,
          limit,
          totalPages
        }
      }
    });
  } catch (error) {
    next(createError(500, 'Error retrieving user sessions', error));
  }
};

/**
 * Get sessions by router ID
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getSessionsByRouterId = async (req, res, next) => {
  try {
    const { routerId } = req.params;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const status = req.query.status || 'active'; // 'active', 'ended', 'all'
    
    // Check if router exists
    const router = await Router.findByPk(routerId);
    if (!router) {
      return next(createError(404, 'Router not found'));
    }
    
    // Build query conditions
    const whereConditions = {
      router_id: routerId
    };
    
    if (status !== 'all') {
      whereConditions.status = status;
    }
    
    // Get sessions with pagination
    const { count, rows: sessions } = await Session.findAndCountAll({
      where: whereConditions,
      limit,
      offset,
      order: [['start_time', 'DESC']],
      include: [
        { model: User, attributes: ['id', 'username', 'email', 'full_name'] }
      ]
    });
    
    // Calculate pagination info
    const totalPages = Math.ceil(count / limit);
    
    res.status(200).json({
      success: true,
      data: {
        sessions,
        pagination: {
          total: count,
          page,
          limit,
          totalPages
        }
      }
    });
  } catch (error) {
    next(createError(500, 'Error retrieving router sessions', error));
  }
};

/**
 * Sync sessions from MikroTik router
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const syncSessionsFromMikroTik = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const { router_id } = req.body;
    
    // Find the router
    const router = await Router.findByPk(router_id);
    if (!router) {
      return next(createError(404, 'Router not found'));
    }
    
    // Connect to MikroTik router
    const mikroTikService = new MikroTikService();
    await mikroTikService.connect({
      host: router.ip_address,
      username: router.username,
      password: router.password,
      port: router.port
    });
    
    // Get active sessions from MikroTik
    const activeSessions = await mikroTikService.getActiveSessions();
    
    // Update or create sessions in database
    let created = 0;
    let updated = 0;
    let ended = 0;
    
    // Mark all active sessions for this router as potentially ended
    await Session.update(
      { potentially_ended: true },
      { where: { router_id, status: 'active' } }
    );
    
    // Process each active session from MikroTik
    for (const session of activeSessions) {
      // Find user by username
      const user = await User.findOne({
        where: { username: session.username }
      });
      
      // Find existing session
      const existingSession = await Session.findOne({
        where: {
          router_id,
          session_id: session.id
        }
      });
      
      if (existingSession) {
        // Update existing session
        await existingSession.update({
          uptime: session.uptime,
          bytes_in: session.bytes_in,
          bytes_out: session.bytes_out,
          packets_in: session.packets_in,
          packets_out: session.packets_out,
          last_updated: new Date(),
          potentially_ended: false
        });
        updated++;
      } else {
        // Create new session
        await Session.create({
          router_id,
          user_id: user ? user.id : null,
          session_id: session.id,
          username: session.username,
          ip_address: session.address,
          mac_address: session.mac_address,
          start_time: new Date(Date.now() - (parseInt(session.uptime) * 1000)),
          uptime: session.uptime,
          bytes_in: session.bytes_in,
          bytes_out: session.bytes_out,
          packets_in: session.packets_in,
          packets_out: session.packets_out,
          status: 'active',
          last_updated: new Date()
        });
        created++;
      }
    }
    
    // Mark sessions that are no longer active as ended
    const endedSessions = await Session.findAll({
      where: {
        router_id,
        status: 'active',
        potentially_ended: true
      }
    });
    
    for (const session of endedSessions) {
      await session.update({
        status: 'ended',
        end_time: new Date(),
        potentially_ended: false
      });
      ended++;
    }
    
    // Disconnect from MikroTik
    await mikroTikService.disconnect();
    
    res.status(200).json({
      success: true,
      message: 'Sessions synced successfully',
      data: {
        created,
        updated,
        ended,
        total_active: activeSessions.length
      }
    });
  } catch (error) {
    next(createError(500, 'Error syncing sessions from MikroTik', error));
  }
};

/**
 * Disconnect a session
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const disconnectSession = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // Find the session
    const session = await Session.findByPk(id, {
      include: [{ model: Router }]
    });
    
    if (!session) {
      return next(createError(404, 'Session not found'));
    }
    
    if (session.status !== 'active') {
      return next(createError(400, 'Session is not active'));
    }
    
    // Check if user is authorized to disconnect this session
    if (req.user.role_id !== 1 && req.user.role_id !== 2 && req.user.id !== session.user_id) {
      return next(createError(403, 'You are not authorized to disconnect this session'));
    }
    
    // Connect to MikroTik router
    const mikroTikService = new MikroTikService();
    await mikroTikService.connect({
      host: session.Router.ip_address,
      username: session.Router.username,
      password: session.Router.password,
      port: session.Router.port
    });
    
    // Disconnect the session
    await mikroTikService.disconnectSession(session.session_id);
    
    // Update session status
    await session.update({
      status: 'ended',
      end_time: new Date(),
      disconnected_by: req.user.id
    });
    
    // Disconnect from MikroTik
    await mikroTikService.disconnect();
    
    res.status(200).json({
      success: true,
      message: 'Session disconnected successfully',
      data: session
    });
  } catch (error) {
    next(createError(500, 'Error disconnecting session', error));
  }
};

/**
 * Disconnect all sessions for a user
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const disconnectUserSessions = async (req, res, next) => {
  try {
    const { userId } = req.params;
    
    // Check if user exists
    const user = await User.findByPk(userId);
    if (!user) {
      return next(createError(404, 'User not found'));
    }
    
    // Check if user is authorized to disconnect these sessions
    if (req.user.role_id !== 1 && req.user.role_id !== 2 && req.user.id !== parseInt(userId)) {
      return next(createError(403, 'You are not authorized to disconnect these sessions'));
    }
    
    // Find active sessions for the user
    const activeSessions = await Session.findAll({
      where: {
        user_id: userId,
        status: 'active'
      },
      include: [{ model: Router }]
    });
    
    if (activeSessions.length === 0) {
      return res.status(200).json({
        success: true,
        message: 'No active sessions found for this user',
        data: { disconnected: 0 }
      });
    }
    
    // Group sessions by router to minimize connections
    const sessionsByRouter = {};
    activeSessions.forEach(session => {
      if (!sessionsByRouter[session.router_id]) {
        sessionsByRouter[session.router_id] = {
          router: session.Router,
          sessions: []
        };
      }
      sessionsByRouter[session.router_id].sessions.push(session);
    });
    
    let disconnectedCount = 0;
    
    // Disconnect sessions for each router
    for (const routerId in sessionsByRouter) {
      const { router, sessions } = sessionsByRouter[routerId];
      
      // Connect to MikroTik router
      const mikroTikService = new MikroTikService();
      await mikroTikService.connect({
        host: router.ip_address,
        username: router.username,
        password: router.password,
        port: router.port
      });
      
      // Disconnect each session
      for (const session of sessions) {
        try {
          await mikroTikService.disconnectSession(session.session_id);
          
          // Update session status
          await session.update({
            status: 'ended',
            end_time: new Date(),
            disconnected_by: req.user.id
          });
          
          disconnectedCount++;
        } catch (sessionError) {
          console.error(`Error disconnecting session ${session.id}:`, sessionError);
        }
      }
      
      // Disconnect from MikroTik
      await mikroTikService.disconnect();
    }
    
    res.status(200).json({
      success: true,
      message: `${disconnectedCount} sessions disconnected successfully`,
      data: { disconnected: disconnectedCount }
    });
  } catch (error) {
    next(createError(500, 'Error disconnecting user sessions', error));
  }
};

/**
 * Get daily session statistics
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getDailySessionStats = async (req, res, next) => {
  try {
    const days = parseInt(req.query.days) || 7;
    
    // Get start and end dates
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    
    // Query for daily sessions
    const dailyStats = await Session.findAll({
      attributes: [
        [sequelize.fn('DATE', sequelize.col('start_time')), 'date'],
        [sequelize.fn('COUNT', sequelize.col('id')), 'count']
      ],
      where: {
        start_time: { [Op.between]: [startDate, endDate] }
      },
      group: [sequelize.fn('DATE', sequelize.col('start_time'))],
      order: [[sequelize.fn('DATE', sequelize.col('start_time')), 'ASC']]
    });
    
    // Format the results
    const formattedStats = dailyStats.map(stat => ({
      date: stat.dataValues.date,
      count: parseInt(stat.dataValues.count)
    }));
    
    // Fill in missing dates with zero values
    const result = [];
    for (let i = 0; i < days; i++) {
      const date = new Date(endDate);
      date.setDate(date.getDate() - i);
      const dateString = moment(date).format('YYYY-MM-DD');
      
      const existingStat = formattedStats.find(stat => moment(stat.date).format('YYYY-MM-DD') === dateString);
      
      if (existingStat) {
        result.unshift(existingStat);
      } else {
        result.unshift({
          date: dateString,
          count: 0
        });
      }
    }
    
    res.status(200).json({
      success: true,
      data: result
    });
  } catch (error) {
    next(createError(500, 'Error retrieving daily session statistics', error));
  }
};

/**
 * Get hourly session statistics
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getHourlySessionStats = async (req, res, next) => {
  try {
    const hours = parseInt(req.query.hours) || 24;
    
    // Get start and end dates
    const endDate = new Date();
    const startDate = new Date();
    startDate.setHours(startDate.getHours() - hours);
    
    // Query for hourly sessions
    const hourlyStats = await Session.findAll({
      attributes: [
        [sequelize.fn('DATE_FORMAT', sequelize.col('start_time'), '%Y-%m-%d %H:00:00'), 'hour'],
        [sequelize.fn('COUNT', sequelize.col('id')), 'count']
      ],
      where: {
        start_time: { [Op.between]: [startDate, endDate] }
      },
      group: [sequelize.fn('DATE_FORMAT', sequelize.col('start_time'), '%Y-%m-%d %H:00:00')],
      order: [[sequelize.fn('DATE_FORMAT', sequelize.col('start_time'), '%Y-%m-%d %H:00:00'), 'ASC']]
    });
    
    // Format the results
    const formattedStats = hourlyStats.map(stat => ({
      hour: stat.dataValues.hour,
      count: parseInt(stat.dataValues.count)
    }));
    
    // Fill in missing hours with zero values
    const result = [];
    for (let i = 0; i < hours; i++) {
      const date = new Date(endDate);
      date.setHours(date.getHours() - i);
      date.setMinutes(0, 0, 0); // Set minutes, seconds, and milliseconds to 0
      const hourString = moment(date).format('YYYY-MM-DD HH:00:00');
      
      const existingStat = formattedStats.find(stat => stat.hour === hourString);
      
      if (existingStat) {
        result.unshift(existingStat);
      } else {
        result.unshift({
          hour: hourString,
          count: 0
        });
      }
    }
    
    res.status(200).json({
      success: true,
      data: result
    });
  } catch (error) {
    next(createError(500, 'Error retrieving hourly session statistics', error));
  }
};

/**
 * Get data usage statistics
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getDataUsageStats = async (req, res, next) => {
  try {
    const period = req.query.period || 'day'; // 'day', 'week', 'month', 'year'
    const userId = req.query.user_id;
    const routerId = req.query.router_id;
    
    // Determine date range based on period
    const endDate = new Date();
    let startDate = new Date();
    
    switch (period) {
      case 'day':
        startDate.setDate(startDate.getDate() - 1);
        break;
      case 'week':
        startDate.setDate(startDate.getDate() - 7);
        break;
      case 'month':
        startDate.setMonth(startDate.getMonth() - 1);
        break;
      case 'year':
        startDate.setFullYear(startDate.getFullYear() - 1);
        break;
      default:
        startDate.setDate(startDate.getDate() - 1);
    }
    
    // Build query conditions
    const whereConditions = {
      [Op.or]: [
        { start_time: { [Op.between]: [startDate, endDate] } },
        { end_time: { [Op.between]: [startDate, endDate] } },
        {
          [Op.and]: [
            { start_time: { [Op.lte]: startDate } },
            { [Op.or]: [
              { end_time: { [Op.gte]: endDate } },
              { end_time: null, status: 'active' }
            ]}
          ]
        }
      ]
    };
    
    if (userId) {
      whereConditions.user_id = userId;
      
      // Check if user is authorized to view these stats
      if (req.user.role_id !== 1 && req.user.role_id !== 2 && req.user.id !== parseInt(userId)) {
        return next(createError(403, 'You are not authorized to view these statistics'));
      }
    }
    
    if (routerId) {
      whereConditions.router_id = routerId;
    }
    
    // Get sessions for the period
    const sessions = await Session.findAll({
      where: whereConditions,
      attributes: [
        'id', 'user_id', 'router_id', 'username', 'start_time', 'end_time',
        'bytes_in', 'bytes_out', 'status'
      ],
      include: [
        { model: User, attributes: ['id', 'username', 'full_name'] },
        { model: Router, attributes: ['id', 'name', 'location'] }
      ]
    });
    
    // Calculate total data usage
    let totalBytesIn = 0;
    let totalBytesOut = 0;
    let totalBytes = 0;
    
    sessions.forEach(session => {
      totalBytesIn += parseInt(session.bytes_in) || 0;
      totalBytesOut += parseInt(session.bytes_out) || 0;
    });
    
    totalBytes = totalBytesIn + totalBytesOut;
    
    // Format data sizes
    const formatBytes = (bytes) => {
      if (bytes === 0) return '0 Bytes';
      
      const k = 1024;
      const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      
      return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };
    
    // Group data by user if no specific user is requested
    let userStats = [];
    if (!userId) {
      const userDataMap = {};
      
      sessions.forEach(session => {
        if (session.user_id) {
          if (!userDataMap[session.user_id]) {
            userDataMap[session.user_id] = {
              user_id: session.user_id,
              username: session.User ? session.User.username : 'Unknown',
              full_name: session.User ? session.User.full_name : 'Unknown',
              bytes_in: 0,
              bytes_out: 0,
              total_bytes: 0
            };
          }
          
          userDataMap[session.user_id].bytes_in += parseInt(session.bytes_in) || 0;
          userDataMap[session.user_id].bytes_out += parseInt(session.bytes_out) || 0;
          userDataMap[session.user_id].total_bytes = userDataMap[session.user_id].bytes_in + userDataMap[session.user_id].bytes_out;
        }
      });
      
      userStats = Object.values(userDataMap).sort((a, b) => b.total_bytes - a.total_bytes);
    }
    
    res.status(200).json({
      success: true,
      data: {
        period,
        start_date: startDate,
        end_date: endDate,
        total_sessions: sessions.length,
        data_usage: {
          download: {
            bytes: totalBytesIn,
            formatted: formatBytes(totalBytesIn)
          },
          upload: {
            bytes: totalBytesOut,
            formatted: formatBytes(totalBytesOut)
          },
          total: {
            bytes: totalBytes,
            formatted: formatBytes(totalBytes)
          }
        },
        user_stats: userStats.length > 0 ? userStats.map(user => ({
          ...user,
          bytes_in_formatted: formatBytes(user.bytes_in),
          bytes_out_formatted: formatBytes(user.bytes_out),
          total_bytes_formatted: formatBytes(user.total_bytes)
        })) : undefined
      }
    });
  } catch (error) {
    next(createError(500, 'Error retrieving data usage statistics', error));
  }
};

module.exports = {
  getAllSessions,
  getActiveSessions,
  getSessionById,
  getSessionsByUserId,
  getSessionsByRouterId,
  syncSessionsFromMikroTik,
  disconnectSession,
  disconnectUserSessions,
  getDailySessionStats,
  getHourlySessionStats,
  getDataUsageStats
};