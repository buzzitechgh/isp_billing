const { Plan, User, Transaction, Router } = require('../models');
const { validationResult } = require('express-validator');
const { createError, formatValidationErrors } = require('../utils/errorUtils');
const { Op } = require('sequelize');
const MikroTikService = require('../services/MikroTikService');
const PaystackService = require('../services/PaystackService');

/**
 * Get all plans with pagination
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getAllPlans = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const search = req.query.search || '';
    const status = req.query.status;
    const type = req.query.type;
    
    // Build query conditions
    const whereConditions = {};
    
    if (search) {
      whereConditions.name = { [Op.like]: `%${search}%` };
    }
    
    if (status === 'active') {
      whereConditions.is_active = true;
    } else if (status === 'inactive') {
      whereConditions.is_active = false;
    }
    
    if (type) {
      whereConditions.type = type;
    }
    
    // Get plans with pagination
    const { count, rows: plans } = await Plan.findAndCountAll({
      where: whereConditions,
      limit,
      offset,
      order: [['price', 'ASC']]
    });
    
    // Calculate pagination info
    const totalPages = Math.ceil(count / limit);
    
    res.status(200).json({
      success: true,
      data: {
        plans,
        pagination: {
          total: count,
          page,
          limit,
          totalPages
        }
      }
    });
  } catch (error) {
    next(createError(500, 'Error retrieving plans', error));
  }
};

/**
 * Get public plans for hotspot page
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getPublicPlans = async (req, res, next) => {
  try {
    const plans = await Plan.findAll({
      where: {
        is_public: true,
        is_active: true
      },
      order: [['price', 'ASC']]
    });
    
    res.status(200).json({
      success: true,
      data: plans
    });
  } catch (error) {
    next(createError(500, 'Error retrieving public plans', error));
  }
};

/**
 * Get plan by ID
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getPlanById = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    const plan = await Plan.findByPk(id);
    
    if (!plan) {
      return next(createError(404, 'Plan not found'));
    }
    
    res.status(200).json({
      success: true,
      data: plan
    });
  } catch (error) {
    next(createError(500, 'Error retrieving plan', error));
  }
};

/**
 * Create a new plan
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const createPlan = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const {
      name,
      type,
      price,
      duration,
      download_speed,
      upload_speed,
      simultaneous_use,
      data_limit,
      shared_users,
      priority,
      is_public,
      description
    } = req.body;
    
    // Create the plan
    const plan = await Plan.create({
      name,
      type,
      price,
      duration,
      download_speed,
      upload_speed,
      simultaneous_use: simultaneous_use || 1,
      data_limit: data_limit || 0,
      shared_users: shared_users || 1,
      priority: priority || 8,
      is_public: is_public !== undefined ? is_public : true,
      description,
      created_by: req.user.id
    });
    
    // Sync with MikroTik routers
    try {
      const routers = await Router.findAll();
      for (const router of routers) {
        const mikroTikService = new MikroTikService(router);
        await mikroTikService.createHotspotUserProfile(plan);
      }
    } catch (mikroTikError) {
      console.error('Error syncing plan with MikroTik:', mikroTikError);
      // Continue despite MikroTik error
    }
    
    res.status(201).json({
      success: true,
      message: 'Plan created successfully',
      data: plan
    });
  } catch (error) {
    next(createError(500, 'Error creating plan', error));
  }
};

/**
 * Update plan
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const updatePlan = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const { id } = req.params;
    const {
      name,
      type,
      price,
      duration,
      download_speed,
      upload_speed,
      simultaneous_use,
      data_limit,
      shared_users,
      priority,
      is_public,
      is_active,
      description
    } = req.body;
    
    // Find the plan
    const plan = await Plan.findByPk(id);
    
    if (!plan) {
      return next(createError(404, 'Plan not found'));
    }
    
    // Update the plan
    await plan.update({
      name: name || plan.name,
      type: type || plan.type,
      price: price !== undefined ? price : plan.price,
      duration: duration !== undefined ? duration : plan.duration,
      download_speed: download_speed !== undefined ? download_speed : plan.download_speed,
      upload_speed: upload_speed !== undefined ? upload_speed : plan.upload_speed,
      simultaneous_use: simultaneous_use !== undefined ? simultaneous_use : plan.simultaneous_use,
      data_limit: data_limit !== undefined ? data_limit : plan.data_limit,
      shared_users: shared_users !== undefined ? shared_users : plan.shared_users,
      priority: priority !== undefined ? priority : plan.priority,
      is_public: is_public !== undefined ? is_public : plan.is_public,
      is_active: is_active !== undefined ? is_active : plan.is_active,
      description: description !== undefined ? description : plan.description,
      updated_by: req.user.id
    });
    
    // Sync with MikroTik routers
    try {
      const routers = await Router.findAll();
      for (const router of routers) {
        const mikroTikService = new MikroTikService(router);
        await mikroTikService.updateHotspotUserProfile(plan);
      }
    } catch (mikroTikError) {
      console.error('Error syncing updated plan with MikroTik:', mikroTikError);
      // Continue despite MikroTik error
    }
    
    res.status(200).json({
      success: true,
      message: 'Plan updated successfully',
      data: plan
    });
  } catch (error) {
    next(createError(500, 'Error updating plan', error));
  }
};

/**
 * Update plan status (activate/deactivate)
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const updatePlanStatus = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const { id } = req.params;
    const { is_active } = req.body;
    
    // Find the plan
    const plan = await Plan.findByPk(id);
    
    if (!plan) {
      return next(createError(404, 'Plan not found'));
    }
    
    // Update the plan status
    await plan.update({
      is_active,
      updated_by: req.user.id
    });
    
    res.status(200).json({
      success: true,
      message: `Plan ${is_active ? 'activated' : 'deactivated'} successfully`,
      data: plan
    });
  } catch (error) {
    next(createError(500, 'Error updating plan status', error));
  }
};

/**
 * Delete plan
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const deletePlan = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // Find the plan
    const plan = await Plan.findByPk(id);
    
    if (!plan) {
      return next(createError(404, 'Plan not found'));
    }
    
    // Check if plan is in use
    const usersWithPlan = await User.count({
      where: { active_plan_id: id }
    });
    
    if (usersWithPlan > 0) {
      return next(createError(400, 'Cannot delete plan that is currently in use'));
    }
    
    // Delete from MikroTik routers
    try {
      const routers = await Router.findAll();
      for (const router of routers) {
        const mikroTikService = new MikroTikService(router);
        await mikroTikService.deleteHotspotUserProfile(plan.name);
      }
    } catch (mikroTikError) {
      console.error('Error deleting plan from MikroTik:', mikroTikError);
      // Continue despite MikroTik error
    }
    
    // Delete the plan
    await plan.destroy();
    
    res.status(200).json({
      success: true,
      message: 'Plan deleted successfully'
    });
  } catch (error) {
    next(createError(500, 'Error deleting plan', error));
  }
};

/**
 * Purchase a plan
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const purchasePlan = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const { id } = req.params;
    const { payment_method } = req.body;
    const userId = req.user.id;
    
    // Find the plan
    const plan = await Plan.findByPk(id);
    
    if (!plan) {
      return next(createError(404, 'Plan not found'));
    }
    
    if (!plan.is_active) {
      return next(createError(400, 'This plan is currently unavailable'));
    }
    
    // Handle different payment methods
    if (payment_method === 'paystack') {
      // Initialize Paystack transaction
      const user = await User.findByPk(userId);
      
      if (!user) {
        return next(createError(404, 'User not found'));
      }
      
      const paystackService = new PaystackService();
      const reference = paystackService.generateReference();
      
      const initializeData = await paystackService.initializeTransaction({
        amount: plan.price * 100, // Paystack amount in kobo
        email: user.email,
        reference,
        metadata: {
          user_id: userId,
          plan_id: plan.id,
          plan_name: plan.name
        }
      });
      
      // Create a pending transaction
      await Transaction.create({
        user_id: userId,
        plan_id: plan.id,
        amount: plan.price,
        payment_method: 'paystack',
        status: 'pending',
        reference,
        notes: `Paystack payment for ${plan.name} plan`
      });
      
      res.status(200).json({
        success: true,
        message: 'Payment initialized',
        data: {
          authorization_url: initializeData.authorization_url,
          reference
        }
      });
    } else if (payment_method === 'cash' || payment_method === 'bank_transfer') {
      // Create a pending transaction for manual payment methods
      const transaction = await Transaction.create({
        user_id: userId,
        plan_id: plan.id,
        amount: plan.price,
        payment_method,
        status: 'pending',
        reference: `MANUAL-${Date.now()}`,
        notes: `Manual ${payment_method} payment for ${plan.name} plan`
      });
      
      res.status(200).json({
        success: true,
        message: 'Payment request submitted',
        data: {
          transaction_id: transaction.id,
          instructions: payment_method === 'cash' 
            ? 'Please visit our office to complete the cash payment' 
            : 'Please make a bank transfer to our account and provide the transaction reference'
        }
      });
    } else {
      return next(createError(400, 'Invalid payment method'));
    }
  } catch (error) {
    next(createError(500, 'Error processing plan purchase', error));
  }
};

/**
 * Get users with this plan
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getPlanUsers = async (req, res, next) => {
  try {
    const { id } = req.params;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    
    // Find the plan
    const plan = await Plan.findByPk(id);
    
    if (!plan) {
      return next(createError(404, 'Plan not found'));
    }
    
    // Get users with this plan
    const { count, rows: users } = await User.findAndCountAll({
      where: { active_plan_id: id },
      limit,
      offset,
      order: [['plan_activation', 'DESC']],
      attributes: { exclude: ['password'] }
    });
    
    // Calculate pagination info
    const totalPages = Math.ceil(count / limit);
    
    res.status(200).json({
      success: true,
      data: {
        plan: {
          id: plan.id,
          name: plan.name
        },
        users,
        pagination: {
          total: count,
          page,
          limit,
          totalPages
        }
      }
    });
  } catch (error) {
    next(createError(500, 'Error retrieving plan users', error));
  }
};

/**
 * Sync plan with MikroTik router
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const syncPlanWithMikroTik = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // Find the plan
    const plan = await Plan.findByPk(id);
    
    if (!plan) {
      return next(createError(404, 'Plan not found'));
    }
    
    // Get all routers
    const routers = await Router.findAll();
    
    if (routers.length === 0) {
      return next(createError(404, 'No routers found'));
    }
    
    const results = [];
    
    // Sync with each router
    for (const router of routers) {
      try {
        const mikroTikService = new MikroTikService(router);
        await mikroTikService.createHotspotUserProfile(plan);
        
        results.push({
          router_id: router.id,
          router_name: router.name,
          status: 'success',
          message: `Plan synced with router ${router.name}`
        });
      } catch (error) {
        results.push({
          router_id: router.id,
          router_name: router.name,
          status: 'error',
          message: `Failed to sync with router ${router.name}: ${error.message}`
        });
      }
    }
    
    res.status(200).json({
      success: true,
      message: 'Plan sync completed',
      data: {
        plan: {
          id: plan.id,
          name: plan.name
        },
        results
      }
    });
  } catch (error) {
    next(createError(500, 'Error syncing plan with MikroTik', error));
  }
};

module.exports = {
  getAllPlans,
  getPublicPlans,
  getPlanById,
  createPlan,
  updatePlan,
  updatePlanStatus,
  deletePlan,
  purchasePlan,
  getPlanUsers,
  syncPlanWithMikroTik
};