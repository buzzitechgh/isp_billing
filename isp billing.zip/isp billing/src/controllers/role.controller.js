const { Role, User, Permission, RolePermission } = require('../models');
const { validationResult } = require('express-validator');
const { createError, formatValidationErrors } = require('../utils/errorUtils');
const { Op } = require('sequelize');
const db = require('../database/connection');

/**
 * Get all roles
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getAllRoles = async (req, res, next) => {
  try {
    const roles = await Role.findAll({
      include: [{
        model: Permission,
        through: { attributes: [] }, // Exclude join table attributes
        as: 'permissions'
      }],
      order: [['id', 'ASC']]
    });

    res.status(200).json({
      success: true,
      data: roles
    });
  } catch (error) {
    next(createError(500, 'Error retrieving roles', error));
  }
};

/**
 * Get role by ID
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getRoleById = async (req, res, next) => {
  try {
    const { id } = req.params;

    const role = await Role.findByPk(id, {
      include: [{
        model: Permission,
        through: { attributes: [] }, // Exclude join table attributes
        as: 'permissions'
      }]
    });

    if (!role) {
      return next(createError(404, 'Role not found'));
    }

    res.status(200).json({
      success: true,
      data: role
    });
  } catch (error) {
    next(createError(500, 'Error retrieving role', error));
  }
};

/**
 * Create role
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const createRole = async (req, res, next) => {
  const transaction = await db.transaction();
  
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }

    const { name, description, permissions } = req.body;

    // Check if role with the same name already exists
    const existingRole = await Role.findOne({
      where: { name },
      transaction
    });

    if (existingRole) {
      await transaction.rollback();
      return next(createError(400, `Role with name '${name}' already exists`));
    }

    // Create the role
    const role = await Role.create({
      name,
      description: description || ''
    }, { transaction });

    // Assign permissions if provided
    if (permissions && Array.isArray(permissions) && permissions.length > 0) {
      // Verify all permissions exist
      const existingPermissions = await Permission.findAll({
        where: { id: { [Op.in]: permissions } },
        transaction
      });

      if (existingPermissions.length !== permissions.length) {
        await transaction.rollback();
        return next(createError(400, 'One or more permissions do not exist'));
      }

      // Create role-permission associations
      const rolePermissions = permissions.map(permissionId => ({
        role_id: role.id,
        permission_id: permissionId
      }));

      await RolePermission.bulkCreate(rolePermissions, { transaction });
    }

    await transaction.commit();

    // Fetch the role with its permissions
    const createdRole = await Role.findByPk(role.id, {
      include: [{
        model: Permission,
        through: { attributes: [] }, // Exclude join table attributes
        as: 'permissions'
      }]
    });

    res.status(201).json({
      success: true,
      message: 'Role created successfully',
      data: createdRole
    });
  } catch (error) {
    await transaction.rollback();
    next(createError(500, 'Error creating role', error));
  }
};

/**
 * Update role
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const updateRole = async (req, res, next) => {
  const transaction = await db.transaction();
  
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }

    const { id } = req.params;
    const { name, description, permissions } = req.body;

    // Find the role
    const role = await Role.findByPk(id, { transaction });

    if (!role) {
      await transaction.rollback();
      return next(createError(404, 'Role not found'));
    }

    // Prevent updating system roles (admin, manager, user)
    if (role.id <= 3) {
      await transaction.rollback();
      return next(createError(403, 'System roles cannot be modified'));
    }

    // Check if the new name already exists (if name is being changed)
    if (name && name !== role.name) {
      const existingRole = await Role.findOne({
        where: { name },
        transaction
      });

      if (existingRole) {
        await transaction.rollback();
        return next(createError(400, `Role with name '${name}' already exists`));
      }
    }

    // Update the role
    const updateData = {};
    if (name) updateData.name = name;
    if (description !== undefined) updateData.description = description;

    await role.update(updateData, { transaction });

    // Update permissions if provided
    if (permissions && Array.isArray(permissions)) {
      // Verify all permissions exist
      const existingPermissions = await Permission.findAll({
        where: { id: { [Op.in]: permissions } },
        transaction
      });

      if (existingPermissions.length !== permissions.length) {
        await transaction.rollback();
        return next(createError(400, 'One or more permissions do not exist'));
      }

      // Remove existing role-permission associations
      await RolePermission.destroy({
        where: { role_id: role.id },
        transaction
      });

      // Create new role-permission associations
      if (permissions.length > 0) {
        const rolePermissions = permissions.map(permissionId => ({
          role_id: role.id,
          permission_id: permissionId
        }));

        await RolePermission.bulkCreate(rolePermissions, { transaction });
      }
    }

    await transaction.commit();

    // Fetch the updated role with its permissions
    const updatedRole = await Role.findByPk(role.id, {
      include: [{
        model: Permission,
        through: { attributes: [] }, // Exclude join table attributes
        as: 'permissions'
      }]
    });

    res.status(200).json({
      success: true,
      message: 'Role updated successfully',
      data: updatedRole
    });
  } catch (error) {
    await transaction.rollback();
    next(createError(500, 'Error updating role', error));
  }
};

/**
 * Delete role
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const deleteRole = async (req, res, next) => {
  const transaction = await db.transaction();
  
  try {
    const { id } = req.params;

    // Find the role
    const role = await Role.findByPk(id, { transaction });

    if (!role) {
      await transaction.rollback();
      return next(createError(404, 'Role not found'));
    }

    // Prevent deleting system roles (admin, manager, user)
    if (role.id <= 3) {
      await transaction.rollback();
      return next(createError(403, 'System roles cannot be deleted'));
    }

    // Check if any users are using this role
    const usersWithRole = await User.count({
      where: { role_id: role.id },
      transaction
    });

    if (usersWithRole > 0) {
      await transaction.rollback();
      return next(createError(400, `Cannot delete role. ${usersWithRole} users are assigned to this role.`));
    }

    // Delete role-permission associations
    await RolePermission.destroy({
      where: { role_id: role.id },
      transaction
    });

    // Delete the role
    await role.destroy({ transaction });

    await transaction.commit();

    res.status(200).json({
      success: true,
      message: 'Role deleted successfully'
    });
  } catch (error) {
    await transaction.rollback();
    next(createError(500, 'Error deleting role', error));
  }
};

/**
 * Get role permissions
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getRolePermissions = async (req, res, next) => {
  try {
    const { id } = req.params;

    // Find the role
    const role = await Role.findByPk(id);

    if (!role) {
      return next(createError(404, 'Role not found'));
    }

    // Get role permissions
    const permissions = await Permission.findAll({
      include: [{
        model: Role,
        where: { id },
        through: { attributes: [] }, // Exclude join table attributes
        attributes: []
      }]
    });

    res.status(200).json({
      success: true,
      data: permissions
    });
  } catch (error) {
    next(createError(500, 'Error retrieving role permissions', error));
  }
};

/**
 * Get all permissions
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getAllPermissions = async (req, res, next) => {
  try {
    const permissions = await Permission.findAll({
      order: [['resource', 'ASC'], ['action', 'ASC']]
    });

    // Group permissions by resource
    const groupedPermissions = permissions.reduce((acc, permission) => {
      if (!acc[permission.resource]) {
        acc[permission.resource] = [];
      }
      acc[permission.resource].push(permission);
      return acc;
    }, {});

    res.status(200).json({
      success: true,
      data: {
        permissions,
        grouped: groupedPermissions
      }
    });
  } catch (error) {
    next(createError(500, 'Error retrieving permissions', error));
  }
};

/**
 * Initialize default roles and permissions
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const initializeRolesAndPermissions = async (req, res, next) => {
  const transaction = await db.transaction();
  
  try {
    // Define default permissions
    const defaultPermissions = [
      // User permissions
      { resource: 'user', action: 'create', description: 'Create users' },
      { resource: 'user', action: 'read', description: 'View users' },
      { resource: 'user', action: 'update', description: 'Update users' },
      { resource: 'user', action: 'delete', description: 'Delete users' },
      { resource: 'user', action: 'manage', description: 'Manage all user operations' },
      
      // Plan permissions
      { resource: 'plan', action: 'create', description: 'Create plans' },
      { resource: 'plan', action: 'read', description: 'View plans' },
      { resource: 'plan', action: 'update', description: 'Update plans' },
      { resource: 'plan', action: 'delete', description: 'Delete plans' },
      { resource: 'plan', action: 'manage', description: 'Manage all plan operations' },
      
      // Transaction permissions
      { resource: 'transaction', action: 'create', description: 'Create transactions' },
      { resource: 'transaction', action: 'read', description: 'View transactions' },
      { resource: 'transaction', action: 'update', description: 'Update transactions' },
      { resource: 'transaction', action: 'delete', description: 'Delete transactions' },
      { resource: 'transaction', action: 'manage', description: 'Manage all transaction operations' },
      
      // Session permissions
      { resource: 'session', action: 'create', description: 'Create sessions' },
      { resource: 'session', action: 'read', description: 'View sessions' },
      { resource: 'session', action: 'update', description: 'Update sessions' },
      { resource: 'session', action: 'delete', description: 'Delete sessions' },
      { resource: 'session', action: 'manage', description: 'Manage all session operations' },
      
      // Router permissions
      { resource: 'router', action: 'create', description: 'Create routers' },
      { resource: 'router', action: 'read', description: 'View routers' },
      { resource: 'router', action: 'update', description: 'Update routers' },
      { resource: 'router', action: 'delete', description: 'Delete routers' },
      { resource: 'router', action: 'manage', description: 'Manage all router operations' },
      
      // Voucher permissions
      { resource: 'voucher', action: 'create', description: 'Create vouchers' },
      { resource: 'voucher', action: 'read', description: 'View vouchers' },
      { resource: 'voucher', action: 'update', description: 'Update vouchers' },
      { resource: 'voucher', action: 'delete', description: 'Delete vouchers' },
      { resource: 'voucher', action: 'manage', description: 'Manage all voucher operations' },
      
      // Notification permissions
      { resource: 'notification', action: 'create', description: 'Create notifications' },
      { resource: 'notification', action: 'read', description: 'View notifications' },
      { resource: 'notification', action: 'update', description: 'Update notifications' },
      { resource: 'notification', action: 'delete', description: 'Delete notifications' },
      { resource: 'notification', action: 'manage', description: 'Manage all notification operations' },
      
      // Settings permissions
      { resource: 'setting', action: 'read', description: 'View settings' },
      { resource: 'setting', action: 'update', description: 'Update settings' },
      { resource: 'setting', action: 'manage', description: 'Manage all setting operations' },
      
      // Role permissions
      { resource: 'role', action: 'create', description: 'Create roles' },
      { resource: 'role', action: 'read', description: 'View roles' },
      { resource: 'role', action: 'update', description: 'Update roles' },
      { resource: 'role', action: 'delete', description: 'Delete roles' },
      { resource: 'role', action: 'manage', description: 'Manage all role operations' },
      
      // Dashboard permissions
      { resource: 'dashboard', action: 'view', description: 'View dashboard' },
      { resource: 'dashboard', action: 'manage', description: 'Manage dashboard' },
      
      // Report permissions
      { resource: 'report', action: 'view', description: 'View reports' },
      { resource: 'report', action: 'generate', description: 'Generate reports' },
      { resource: 'report', action: 'manage', description: 'Manage all report operations' }
    ];

    // Create permissions if they don't exist
    for (const permissionData of defaultPermissions) {
      await Permission.findOrCreate({
        where: {
          resource: permissionData.resource,
          action: permissionData.action
        },
        defaults: permissionData,
        transaction
      });
    }

    // Define default roles
    const defaultRoles = [
      {
        id: 1,
        name: 'Admin',
        description: 'Administrator with full access to all features'
      },
      {
        id: 2,
        name: 'Manager',
        description: 'Manager with access to most features except system settings'
      },
      {
        id: 3,
        name: 'User',
        description: 'Regular user with limited access'
      }
    ];

    // Create roles if they don't exist
    for (const roleData of defaultRoles) {
      await Role.findOrCreate({
        where: { id: roleData.id },
        defaults: roleData,
        transaction
      });
    }

    // Get all permissions
    const allPermissions = await Permission.findAll({ transaction });
    const permissionIds = allPermissions.map(p => p.id);

    // Get manager permissions (all except settings and role management)
    const managerPermissions = allPermissions
      .filter(p => !(p.resource === 'setting' && p.action === 'manage') && 
                  !(p.resource === 'role' && p.action === 'manage'))
      .map(p => p.id);

    // Get user permissions (only view own data and dashboard)
    const userPermissions = allPermissions
      .filter(p => (p.resource === 'dashboard' && p.action === 'view') ||
                  (p.resource === 'user' && p.action === 'read') ||
                  (p.resource === 'notification' && p.action === 'read') ||
                  (p.resource === 'session' && p.action === 'read') ||
                  (p.resource === 'transaction' && p.action === 'read'))
      .map(p => p.id);

    // Assign permissions to roles
    // Admin gets all permissions
    await RolePermission.destroy({
      where: { role_id: 1 },
      transaction
    });
    
    await RolePermission.bulkCreate(
      permissionIds.map(permissionId => ({
        role_id: 1,
        permission_id: permissionId
      })),
      { transaction }
    );

    // Manager gets most permissions
    await RolePermission.destroy({
      where: { role_id: 2 },
      transaction
    });
    
    await RolePermission.bulkCreate(
      managerPermissions.map(permissionId => ({
        role_id: 2,
        permission_id: permissionId
      })),
      { transaction }
    );

    // User gets limited permissions
    await RolePermission.destroy({
      where: { role_id: 3 },
      transaction
    });
    
    await RolePermission.bulkCreate(
      userPermissions.map(permissionId => ({
        role_id: 3,
        permission_id: permissionId
      })),
      { transaction }
    );

    await transaction.commit();

    res.status(200).json({
      success: true,
      message: 'Roles and permissions initialized successfully',
      data: {
        roles: await Role.count(),
        permissions: await Permission.count()
      }
    });
  } catch (error) {
    await transaction.rollback();
    next(createError(500, 'Error initializing roles and permissions', error));
  }
};

module.exports = {
  getAllRoles,
  getRoleById,
  createRole,
  updateRole,
  deleteRole,
  getRolePermissions,
  getAllPermissions,
  initializeRolesAndPermissions
};