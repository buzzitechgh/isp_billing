const { User, Transaction, Session, Notification, Plan } = require('../models');
const { validationResult } = require('express-validator');
const { createError, formatValidationErrors } = require('../utils/errorUtils');
const { Op } = require('sequelize');

/**
 * Get all users with pagination
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getAllUsers = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const search = req.query.search || '';
    const status = req.query.status;
    
    // Build query conditions
    const whereConditions = {};
    
    if (search) {
      whereConditions[Op.or] = [
        { username: { [Op.like]: `%${search}%` } },
        { email: { [Op.like]: `%${search}%` } },
        { full_name: { [Op.like]: `%${search}%` } },
        { phone: { [Op.like]: `%${search}%` } }
      ];
    }
    
    if (status === 'active') {
      whereConditions.is_active = true;
    } else if (status === 'inactive') {
      whereConditions.is_active = false;
    }
    
    // Get users with pagination
    const { count, rows: users } = await User.findAndCountAll({
      where: whereConditions,
      limit,
      offset,
      order: [['created_at', 'DESC']],
      attributes: { exclude: ['password'] },
      include: [{ model: Plan, as: 'activePlan' }]
    });
    
    // Calculate pagination info
    const totalPages = Math.ceil(count / limit);
    
    res.status(200).json({
      success: true,
      data: {
        users,
        pagination: {
          total: count,
          page,
          limit,
          totalPages
        }
      }
    });
  } catch (error) {
    next(createError(500, 'Error retrieving users', error));
  }
};

/**
 * Get user by ID
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getUserById = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // Check if the user is authorized to view this user
    if (req.user.role !== 'admin' && req.user.role !== 'manager' && req.user.id !== parseInt(id)) {
      return next(createError(403, 'You are not authorized to view this user'));
    }
    
    const user = await User.findByPk(id, {
      attributes: { exclude: ['password'] },
      include: [{ model: Plan, as: 'activePlan' }]
    });
    
    if (!user) {
      return next(createError(404, 'User not found'));
    }
    
    res.status(200).json({
      success: true,
      data: user
    });
  } catch (error) {
    next(createError(500, 'Error retrieving user', error));
  }
};

/**
 * Create a new user
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const createUser = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const { username, email, password, full_name, role_id, phone, address } = req.body;
    
    // Check if username or email already exists
    const existingUser = await User.findOne({
      where: {
        [Op.or]: [
          { username },
          { email }
        ]
      }
    });
    
    if (existingUser) {
      return next(createError(400, 'Username or email already exists'));
    }
    
    // Create the user
    const user = await User.create({
      username,
      email,
      password, // Will be hashed by the model hook
      full_name,
      role_id,
      phone,
      address,
      created_by: req.user.id
    });
    
    // Create welcome notification
    await Notification.create({
      user_id: user.id,
      title: 'Welcome to ISP Billing System',
      message: `Welcome ${full_name}! Your account has been created successfully.`,
      type: 'info',
      priority: 'medium',
      icon: 'user-plus'
    });
    
    res.status(201).json({
      success: true,
      message: 'User created successfully',
      data: {
        id: user.id,
        username: user.username,
        email: user.email,
        full_name: user.full_name,
        role_id: user.role_id,
        is_active: user.is_active,
        created_at: user.created_at
      }
    });
  } catch (error) {
    next(createError(500, 'Error creating user', error));
  }
};

/**
 * Update user
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const updateUser = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const { id } = req.params;
    const { full_name, email, phone, address } = req.body;
    
    // Check if the user is authorized to update this user
    if (req.user.role !== 'admin' && req.user.id !== parseInt(id)) {
      return next(createError(403, 'You are not authorized to update this user'));
    }
    
    // Find the user
    const user = await User.findByPk(id);
    
    if (!user) {
      return next(createError(404, 'User not found'));
    }
    
    // Check if email is being changed and if it already exists
    if (email && email !== user.email) {
      const existingUser = await User.findOne({
        where: { email }
      });
      
      if (existingUser) {
        return next(createError(400, 'Email already in use'));
      }
    }
    
    // Update the user
    await user.update({
      full_name: full_name || user.full_name,
      email: email || user.email,
      phone: phone || user.phone,
      address: address || user.address,
      updated_by: req.user.id
    });
    
    res.status(200).json({
      success: true,
      message: 'User updated successfully',
      data: {
        id: user.id,
        username: user.username,
        email: user.email,
        full_name: user.full_name,
        phone: user.phone,
        address: user.address,
        is_active: user.is_active,
        updated_at: user.updated_at
      }
    });
  } catch (error) {
    next(createError(500, 'Error updating user', error));
  }
};

/**
 * Update user status (activate/deactivate)
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const updateUserStatus = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const { id } = req.params;
    const { is_active } = req.body;
    
    // Find the user
    const user = await User.findByPk(id);
    
    if (!user) {
      return next(createError(404, 'User not found'));
    }
    
    // Update the user status
    await user.update({
      is_active,
      updated_by: req.user.id
    });
    
    // Create notification for the user
    await Notification.create({
      user_id: user.id,
      title: is_active ? 'Account Activated' : 'Account Deactivated',
      message: is_active 
        ? 'Your account has been activated. You can now access all features.'
        : 'Your account has been deactivated. Please contact support for assistance.',
      type: is_active ? 'success' : 'warning',
      priority: 'high',
      icon: is_active ? 'user-check' : 'user-x',
      send_sms: true
    });
    
    res.status(200).json({
      success: true,
      message: `User ${is_active ? 'activated' : 'deactivated'} successfully`,
      data: {
        id: user.id,
        username: user.username,
        is_active: user.is_active,
        updated_at: user.updated_at
      }
    });
  } catch (error) {
    next(createError(500, 'Error updating user status', error));
  }
};

/**
 * Delete user
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const deleteUser = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // Find the user
    const user = await User.findByPk(id);
    
    if (!user) {
      return next(createError(404, 'User not found'));
    }
    
    // Check if user has active sessions
    const activeSessions = await Session.count({
      where: {
        user_id: id,
        status: 'active'
      }
    });
    
    if (activeSessions > 0) {
      return next(createError(400, 'Cannot delete user with active sessions'));
    }
    
    // Delete the user
    await user.destroy();
    
    res.status(200).json({
      success: true,
      message: 'User deleted successfully'
    });
  } catch (error) {
    next(createError(500, 'Error deleting user', error));
  }
};

/**
 * Get user transactions
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getUserTransactions = async (req, res, next) => {
  try {
    const { id } = req.params;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    
    // Check if the user is authorized to view this user's transactions
    if (req.user.role !== 'admin' && req.user.role !== 'manager' && req.user.id !== parseInt(id)) {
      return next(createError(403, 'You are not authorized to view these transactions'));
    }
    
    // Find the user
    const user = await User.findByPk(id);
    
    if (!user) {
      return next(createError(404, 'User not found'));
    }
    
    // Get user transactions with pagination
    const { count, rows: transactions } = await Transaction.findAndCountAll({
      where: { user_id: id },
      limit,
      offset,
      order: [['created_at', 'DESC']],
      include: [{ model: Plan }]
    });
    
    // Calculate pagination info
    const totalPages = Math.ceil(count / limit);
    
    res.status(200).json({
      success: true,
      data: {
        transactions,
        pagination: {
          total: count,
          page,
          limit,
          totalPages
        }
      }
    });
  } catch (error) {
    next(createError(500, 'Error retrieving user transactions', error));
  }
};

/**
 * Get user sessions
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getUserSessions = async (req, res, next) => {
  try {
    const { id } = req.params;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const status = req.query.status;
    
    // Check if the user is authorized to view this user's sessions
    if (req.user.role !== 'admin' && req.user.role !== 'manager' && req.user.id !== parseInt(id)) {
      return next(createError(403, 'You are not authorized to view these sessions'));
    }
    
    // Find the user
    const user = await User.findByPk(id);
    
    if (!user) {
      return next(createError(404, 'User not found'));
    }
    
    // Build query conditions
    const whereConditions = { user_id: id };
    
    if (status === 'active') {
      whereConditions.status = 'active';
    } else if (status === 'ended') {
      whereConditions.status = 'ended';
    }
    
    // Get user sessions with pagination
    const { count, rows: sessions } = await Session.findAndCountAll({
      where: whereConditions,
      limit,
      offset,
      order: [['start_time', 'DESC']],
      include: [{ model: User, attributes: ['id', 'username', 'full_name'] }]
    });
    
    // Calculate pagination info
    const totalPages = Math.ceil(count / limit);
    
    res.status(200).json({
      success: true,
      data: {
        sessions,
        pagination: {
          total: count,
          page,
          limit,
          totalPages
        }
      }
    });
  } catch (error) {
    next(createError(500, 'Error retrieving user sessions', error));
  }
};

/**
 * Get user notifications
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getUserNotifications = async (req, res, next) => {
  try {
    const { id } = req.params;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const unreadOnly = req.query.unread === 'true';
    
    // Check if the user is authorized to view this user's notifications
    if (req.user.id !== parseInt(id)) {
      return next(createError(403, 'You are not authorized to view these notifications'));
    }
    
    // Build query conditions
    const whereConditions = { user_id: id };
    
    if (unreadOnly) {
      whereConditions.is_read = false;
    }
    
    // Get user notifications with pagination
    const { count, rows: notifications } = await Notification.findAndCountAll({
      where: whereConditions,
      limit,
      offset,
      order: [['created_at', 'DESC']]
    });
    
    // Calculate pagination info
    const totalPages = Math.ceil(count / limit);
    
    // Get unread count
    const unreadCount = await Notification.count({
      where: {
        user_id: id,
        is_read: false
      }
    });
    
    res.status(200).json({
      success: true,
      data: {
        notifications,
        unreadCount,
        pagination: {
          total: count,
          page,
          limit,
          totalPages
        }
      }
    });
  } catch (error) {
    next(createError(500, 'Error retrieving user notifications', error));
  }
};

/**
 * Mark notification as read
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const markNotificationAsRead = async (req, res, next) => {
  try {
    const { id, notificationId } = req.params;
    
    // Check if the user is authorized
    if (req.user.id !== parseInt(id)) {
      return next(createError(403, 'You are not authorized to update this notification'));
    }
    
    // Find the notification
    const notification = await Notification.findOne({
      where: {
        id: notificationId,
        user_id: id
      }
    });
    
    if (!notification) {
      return next(createError(404, 'Notification not found'));
    }
    
    // Mark as read
    await notification.update({ is_read: true });
    
    res.status(200).json({
      success: true,
      message: 'Notification marked as read',
      data: notification
    });
  } catch (error) {
    next(createError(500, 'Error updating notification', error));
  }
};

/**
 * Get user's active plan
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getUserActivePlan = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // Check if the user is authorized
    if (req.user.role !== 'admin' && req.user.role !== 'manager' && req.user.id !== parseInt(id)) {
      return next(createError(403, 'You are not authorized to view this information'));
    }
    
    // Find the user with active plan
    const user = await User.findByPk(id, {
      include: [{ model: Plan, as: 'activePlan' }]
    });
    
    if (!user) {
      return next(createError(404, 'User not found'));
    }
    
    if (!user.activePlan) {
      return res.status(200).json({
        success: true,
        message: 'User has no active plan',
        data: null
      });
    }
    
    // Calculate remaining time and data
    const now = new Date();
    const expiryDate = new Date(user.plan_expiry);
    const remainingDays = Math.max(0, Math.ceil((expiryDate - now) / (1000 * 60 * 60 * 24)));
    
    // Calculate data usage percentage if plan has data limit
    let dataUsagePercentage = null;
    if (user.activePlan.data_limit > 0) {
      dataUsagePercentage = Math.min(100, Math.round((user.data_used / user.activePlan.data_limit) * 100));
    }
    
    res.status(200).json({
      success: true,
      data: {
        plan: user.activePlan,
        activation_date: user.plan_activation,
        expiry_date: user.plan_expiry,
        remaining_days: remainingDays,
        data_used: user.data_used,
        data_limit: user.activePlan.data_limit,
        data_usage_percentage: dataUsagePercentage
      }
    });
  } catch (error) {
    next(createError(500, 'Error retrieving user active plan', error));
  }
};

module.exports = {
  getAllUsers,
  getUserById,
  createUser,
  updateUser,
  updateUserStatus,
  deleteUser,
  getUserTransactions,
  getUserSessions,
  getUserNotifications,
  markNotificationAsRead,
  getUserActivePlan
};