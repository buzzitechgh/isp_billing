const { Notification, User } = require('../models');
const { validationResult } = require('express-validator');
const { createError, formatValidationErrors } = require('../utils/errorUtils');
const { Op } = require('sequelize');
const EmailService = require('../services/EmailService');
const TwilioService = require('../services/TwilioService');

/**
 * Get all notifications with pagination (admin only)
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getAllNotifications = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const search = req.query.search || '';
    const type = req.query.type;
    
    // Build query conditions
    const whereConditions = {};
    
    if (search) {
      whereConditions[Op.or] = [
        { title: { [Op.like]: `%${search}%` } },
        { message: { [Op.like]: `%${search}%` } },
        { '$User.username$': { [Op.like]: `%${search}%` } },
        { '$User.email$': { [Op.like]: `%${search}%` } },
        { '$User.full_name$': { [Op.like]: `%${search}%` } }
      ];
    }
    
    if (type) {
      whereConditions.type = type;
    }
    
    // Get notifications with pagination
    const { count, rows: notifications } = await Notification.findAndCountAll({
      where: whereConditions,
      limit,
      offset,
      order: [['created_at', 'DESC']],
      include: [{ model: User, attributes: ['id', 'username', 'email', 'full_name'] }]
    });
    
    // Calculate pagination info
    const totalPages = Math.ceil(count / limit);
    
    res.status(200).json({
      success: true,
      data: {
        notifications,
        pagination: {
          total: count,
          page,
          limit,
          totalPages
        }
      }
    });
  } catch (error) {
    next(createError(500, 'Error retrieving notifications', error));
  }
};

/**
 * Get user notifications
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getUserNotifications = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const unreadOnly = req.query.unread === 'true';
    
    // Check if user exists
    const user = await User.findByPk(userId);
    if (!user) {
      return next(createError(404, 'User not found'));
    }
    
    // Check if user is authorized to view these notifications
    if (req.user.role_id !== 1 && req.user.role_id !== 2 && req.user.id !== parseInt(userId)) {
      return next(createError(403, 'You are not authorized to view these notifications'));
    }
    
    // Build query conditions
    const whereConditions = {
      user_id: userId
    };
    
    if (unreadOnly) {
      whereConditions.is_read = false;
    }
    
    // Get notifications with pagination
    const { count, rows: notifications } = await Notification.findAndCountAll({
      where: whereConditions,
      limit,
      offset,
      order: [['created_at', 'DESC']]
    });
    
    // Get unread count
    const unreadCount = await Notification.count({
      where: {
        user_id: userId,
        is_read: false
      }
    });
    
    // Calculate pagination info
    const totalPages = Math.ceil(count / limit);
    
    res.status(200).json({
      success: true,
      data: {
        notifications,
        unread_count: unreadCount,
        pagination: {
          total: count,
          page,
          limit,
          totalPages
        }
      }
    });
  } catch (error) {
    next(createError(500, 'Error retrieving user notifications', error));
  }
};

/**
 * Get notification by ID
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getNotificationById = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    const notification = await Notification.findByPk(id, {
      include: [{ model: User, attributes: ['id', 'username', 'email', 'full_name'] }]
    });
    
    if (!notification) {
      return next(createError(404, 'Notification not found'));
    }
    
    // Check if user is authorized to view this notification
    if (req.user.role_id !== 1 && req.user.role_id !== 2 && req.user.id !== notification.user_id) {
      return next(createError(403, 'You are not authorized to view this notification'));
    }
    
    res.status(200).json({
      success: true,
      data: notification
    });
  } catch (error) {
    next(createError(500, 'Error retrieving notification', error));
  }
};

/**
 * Create a notification
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const createNotification = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const { user_id, title, message, type, send_email, send_sms } = req.body;
    
    // Check if user exists
    const user = await User.findByPk(user_id);
    if (!user) {
      return next(createError(404, 'User not found'));
    }
    
    // Create the notification
    const notification = await Notification.create({
      user_id,
      title,
      message,
      type: type || 'info',
      is_read: false,
      created_by: req.user.id
    });
    
    // Send email notification if requested
    if (send_email && user.email) {
      try {
        const emailService = new EmailService();
        await emailService.sendEmail({
          to: user.email,
          subject: title,
          text: message,
          html: `<div><h2>${title}</h2><p>${message}</p></div>`
        });
      } catch (emailError) {
        console.error('Failed to send email notification:', emailError);
      }
    }
    
    // Send SMS notification if requested
    if (send_sms && user.phone) {
      try {
        const twilioService = new TwilioService();
        await twilioService.sendSMS(user.phone, message);
      } catch (smsError) {
        console.error('Failed to send SMS notification:', smsError);
      }
    }
    
    res.status(201).json({
      success: true,
      message: 'Notification created successfully',
      data: notification
    });
  } catch (error) {
    next(createError(500, 'Error creating notification', error));
  }
};

/**
 * Create bulk notifications
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const createBulkNotifications = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const { user_ids, title, message, type, send_email, send_sms } = req.body;
    
    if (!Array.isArray(user_ids) || user_ids.length === 0) {
      return next(createError(400, 'User IDs must be a non-empty array'));
    }
    
    // Check if users exist
    const users = await User.findAll({
      where: {
        id: { [Op.in]: user_ids }
      }
    });
    
    if (users.length === 0) {
      return next(createError(404, 'No valid users found'));
    }
    
    const foundUserIds = users.map(user => user.id);
    
    // Create notifications for each user
    const notificationData = foundUserIds.map(userId => ({
      user_id: userId,
      title,
      message,
      type: type || 'info',
      is_read: false,
      created_by: req.user.id
    }));
    
    const notifications = await Notification.bulkCreate(notificationData);
    
    // Send email notifications if requested
    if (send_email) {
      const emailService = new EmailService();
      
      for (const user of users) {
        if (user.email) {
          try {
            await emailService.sendEmail({
              to: user.email,
              subject: title,
              text: message,
              html: `<div><h2>${title}</h2><p>${message}</p></div>`
            });
          } catch (emailError) {
            console.error(`Failed to send email notification to ${user.email}:`, emailError);
          }
        }
      }
    }
    
    // Send SMS notifications if requested
    if (send_sms) {
      const twilioService = new TwilioService();
      
      const phoneNumbers = users
        .filter(user => user.phone)
        .map(user => user.phone);
      
      if (phoneNumbers.length > 0) {
        try {
          await twilioService.sendBulkSMS(phoneNumbers, message);
        } catch (smsError) {
          console.error('Failed to send bulk SMS notifications:', smsError);
        }
      }
    }
    
    res.status(201).json({
      success: true,
      message: `${notifications.length} notifications created successfully`,
      data: {
        count: notifications.length,
        notifications: notifications.map(n => ({ id: n.id, user_id: n.user_id }))
      }
    });
  } catch (error) {
    next(createError(500, 'Error creating bulk notifications', error));
  }
};

/**
 * Create system notification (for all users)
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const createSystemNotification = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const { title, message, type, role_id, send_email, send_sms } = req.body;
    
    // Build query conditions for users
    const whereConditions = {
      is_active: true
    };
    
    if (role_id) {
      whereConditions.role_id = role_id;
    }
    
    // Get all active users
    const users = await User.findAll({
      where: whereConditions
    });
    
    if (users.length === 0) {
      return next(createError(404, 'No active users found'));
    }
    
    // Create notifications for each user
    const notificationData = users.map(user => ({
      user_id: user.id,
      title,
      message,
      type: type || 'system',
      is_read: false,
      created_by: req.user.id
    }));
    
    const notifications = await Notification.bulkCreate(notificationData);
    
    // Send email notifications if requested
    if (send_email) {
      const emailService = new EmailService();
      
      for (const user of users) {
        if (user.email) {
          try {
            await emailService.sendEmail({
              to: user.email,
              subject: title,
              text: message,
              html: `<div><h2>${title}</h2><p>${message}</p></div>`
            });
          } catch (emailError) {
            console.error(`Failed to send email notification to ${user.email}:`, emailError);
          }
        }
      }
    }
    
    // Send SMS notifications if requested
    if (send_sms) {
      const twilioService = new TwilioService();
      
      const phoneNumbers = users
        .filter(user => user.phone)
        .map(user => user.phone);
      
      if (phoneNumbers.length > 0) {
        try {
          await twilioService.sendBulkSMS(phoneNumbers, message);
        } catch (smsError) {
          console.error('Failed to send bulk SMS notifications:', smsError);
        }
      }
    }
    
    res.status(201).json({
      success: true,
      message: `System notification sent to ${users.length} users`,
      data: {
        count: notifications.length,
        user_count: users.length,
        role_id: role_id || 'all'
      }
    });
  } catch (error) {
    next(createError(500, 'Error creating system notification', error));
  }
};

/**
 * Mark notification as read
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const markNotificationAsRead = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    const notification = await Notification.findByPk(id);
    
    if (!notification) {
      return next(createError(404, 'Notification not found'));
    }
    
    // Check if user is authorized to mark this notification as read
    if (req.user.role_id !== 1 && req.user.role_id !== 2 && req.user.id !== notification.user_id) {
      return next(createError(403, 'You are not authorized to update this notification'));
    }
    
    // Mark as read
    await notification.update({
      is_read: true
    });
    
    res.status(200).json({
      success: true,
      message: 'Notification marked as read',
      data: notification
    });
  } catch (error) {
    next(createError(500, 'Error marking notification as read', error));
  }
};

/**
 * Mark all notifications as read
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const markAllNotificationsAsRead = async (req, res, next) => {
  try {
    const { userId } = req.params;
    
    // Check if user exists
    const user = await User.findByPk(userId);
    if (!user) {
      return next(createError(404, 'User not found'));
    }
    
    // Check if user is authorized to mark these notifications as read
    if (req.user.role_id !== 1 && req.user.role_id !== 2 && req.user.id !== parseInt(userId)) {
      return next(createError(403, 'You are not authorized to update these notifications'));
    }
    
    // Count unread notifications
    const unreadCount = await Notification.count({
      where: {
        user_id: userId,
        is_read: false
      }
    });
    
    if (unreadCount === 0) {
      return res.status(200).json({
        success: true,
        message: 'No unread notifications found',
        data: { count: 0 }
      });
    }
    
    // Mark all as read
    await Notification.update(
      { is_read: true },
      {
        where: {
          user_id: userId,
          is_read: false
        }
      }
    );
    
    res.status(200).json({
      success: true,
      message: `${unreadCount} notifications marked as read`,
      data: { count: unreadCount }
    });
  } catch (error) {
    next(createError(500, 'Error marking notifications as read', error));
  }
};

/**
 * Delete notification
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const deleteNotification = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    const notification = await Notification.findByPk(id);
    
    if (!notification) {
      return next(createError(404, 'Notification not found'));
    }
    
    // Check if user is authorized to delete this notification
    if (req.user.role_id !== 1 && req.user.role_id !== 2 && req.user.id !== notification.user_id) {
      return next(createError(403, 'You are not authorized to delete this notification'));
    }
    
    // Delete the notification
    await notification.destroy();
    
    res.status(200).json({
      success: true,
      message: 'Notification deleted successfully'
    });
  } catch (error) {
    next(createError(500, 'Error deleting notification', error));
  }
};

/**
 * Delete all notifications for a user
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const deleteAllNotifications = async (req, res, next) => {
  try {
    const { userId } = req.params;
    
    // Check if user exists
    const user = await User.findByPk(userId);
    if (!user) {
      return next(createError(404, 'User not found'));
    }
    
    // Check if user is authorized to delete these notifications
    if (req.user.role_id !== 1 && req.user.role_id !== 2 && req.user.id !== parseInt(userId)) {
      return next(createError(403, 'You are not authorized to delete these notifications'));
    }
    
    // Count notifications
    const count = await Notification.count({
      where: { user_id: userId }
    });
    
    if (count === 0) {
      return res.status(200).json({
        success: true,
        message: 'No notifications found',
        data: { count: 0 }
      });
    }
    
    // Delete all notifications
    await Notification.destroy({
      where: { user_id: userId }
    });
    
    res.status(200).json({
      success: true,
      message: `${count} notifications deleted successfully`,
      data: { count }
    });
  } catch (error) {
    next(createError(500, 'Error deleting notifications', error));
  }
};

module.exports = {
  getAllNotifications,
  getUserNotifications,
  getNotificationById,
  createNotification,
  createBulkNotifications,
  createSystemNotification,
  markNotificationAsRead,
  markAllNotificationsAsRead,
  deleteNotification,
  deleteAllNotifications
};