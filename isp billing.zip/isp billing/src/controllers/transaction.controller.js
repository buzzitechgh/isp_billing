const { Transaction, User, Plan } = require('../models');
const { validationResult } = require('express-validator');
const { createError, formatValidationErrors } = require('../utils/errorUtils');
const { Op } = require('sequelize');
const PaystackService = require('../services/PaystackService');
const EmailService = require('../services/EmailService');
const TwilioService = require('../services/TwilioService');
const sequelize = require('sequelize');
const moment = require('moment');

/**
 * Get all transactions with pagination
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getAllTransactions = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const search = req.query.search || '';
    const status = req.query.status;
    const paymentMethod = req.query.payment_method;
    const startDate = req.query.start_date;
    const endDate = req.query.end_date;
    
    // Build query conditions
    const whereConditions = {};
    
    if (search) {
      whereConditions[Op.or] = [
        { reference: { [Op.like]: `%${search}%` } },
        { notes: { [Op.like]: `%${search}%` } },
        { '$User.username$': { [Op.like]: `%${search}%` } },
        { '$User.email$': { [Op.like]: `%${search}%` } },
        { '$User.full_name$': { [Op.like]: `%${search}%` } }
      ];
    }
    
    if (status) {
      whereConditions.status = status;
    }
    
    if (paymentMethod) {
      whereConditions.payment_method = paymentMethod;
    }
    
    if (startDate && endDate) {
      whereConditions.created_at = {
        [Op.between]: [new Date(startDate), new Date(endDate)]
      };
    } else if (startDate) {
      whereConditions.created_at = {
        [Op.gte]: new Date(startDate)
      };
    } else if (endDate) {
      whereConditions.created_at = {
        [Op.lte]: new Date(endDate)
      };
    }
    
    // Get transactions with pagination
    const { count, rows: transactions } = await Transaction.findAndCountAll({
      where: whereConditions,
      limit,
      offset,
      order: [['created_at', 'DESC']],
      include: [
        { model: User, attributes: ['id', 'username', 'email', 'full_name'] },
        { model: Plan, attributes: ['id', 'name', 'type', 'duration'] }
      ]
    });
    
    // Calculate pagination info
    const totalPages = Math.ceil(count / limit);
    
    res.status(200).json({
      success: true,
      data: {
        transactions,
        pagination: {
          total: count,
          page,
          limit,
          totalPages
        }
      }
    });
  } catch (error) {
    next(createError(500, 'Error retrieving transactions', error));
  }
};

/**
 * Get transaction by ID
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getTransactionById = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    const transaction = await Transaction.findByPk(id, {
      include: [
        { model: User, attributes: ['id', 'username', 'email', 'full_name', 'phone'] },
        { model: Plan, attributes: ['id', 'name', 'type', 'duration', 'price', 'download_speed', 'upload_speed'] }
      ]
    });
    
    if (!transaction) {
      return next(createError(404, 'Transaction not found'));
    }
    
    // Check if user is authorized to view this transaction
    if (req.user.role_id !== 1 && req.user.role_id !== 2 && req.user.id !== transaction.user_id) {
      return next(createError(403, 'You are not authorized to view this transaction'));
    }
    
    res.status(200).json({
      success: true,
      data: transaction
    });
  } catch (error) {
    next(createError(500, 'Error retrieving transaction', error));
  }
};

/**
 * Create a new transaction (manual entry)
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const createTransaction = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const { user_id, plan_id, amount, payment_method, status, reference, notes } = req.body;
    
    // Verify user exists
    const user = await User.findByPk(user_id);
    if (!user) {
      return next(createError(404, 'User not found'));
    }
    
    // Verify plan exists if provided
    if (plan_id) {
      const plan = await Plan.findByPk(plan_id);
      if (!plan) {
        return next(createError(404, 'Plan not found'));
      }
    }
    
    // Generate reference if not provided
    const transactionReference = reference || `MANUAL-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    
    // Create the transaction
    const transaction = await Transaction.create({
      user_id,
      plan_id: plan_id || null,
      amount,
      payment_method: payment_method || 'cash',
      status: status || 'completed',
      reference: transactionReference,
      notes: notes || 'Manual transaction entry',
      created_by: req.user.id
    });
    
    // Send notification if transaction is completed
    if (transaction.status === 'completed') {
      // Send email receipt
      try {
        const emailService = new EmailService();
        await emailService.sendPaymentReceipt(user.email, {
          name: user.full_name,
          amount: transaction.amount,
          reference: transaction.reference,
          date: transaction.created_at,
          paymentMethod: transaction.payment_method,
          planName: transaction.plan_id ? (await Plan.findByPk(transaction.plan_id)).name : 'N/A'
        });
      } catch (emailError) {
        console.error('Failed to send email receipt:', emailError);
      }
      
      // Send SMS notification if phone number is available
      if (user.phone) {
        try {
          const twilioService = new TwilioService();
          await twilioService.sendPaymentConfirmation(user.phone, {
            amount: transaction.amount,
            reference: transaction.reference
          });
        } catch (smsError) {
          console.error('Failed to send SMS notification:', smsError);
        }
      }
    }
    
    res.status(201).json({
      success: true,
      message: 'Transaction created successfully',
      data: transaction
    });
  } catch (error) {
    next(createError(500, 'Error creating transaction', error));
  }
};

/**
 * Initialize a Paystack transaction
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const initializePaystackTransaction = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const { user_id, plan_id, email, amount, callback_url } = req.body;
    
    // Verify user exists
    const user = await User.findByPk(user_id);
    if (!user) {
      return next(createError(404, 'User not found'));
    }
    
    // Verify plan exists
    const plan = await Plan.findByPk(plan_id);
    if (!plan) {
      return next(createError(404, 'Plan not found'));
    }
    
    // Generate reference
    const reference = `PAYSTACK-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    
    // Initialize Paystack transaction
    const paystackService = new PaystackService();
    const response = await paystackService.initializeTransaction({
      email: email || user.email,
      amount: amount || plan.price * 100, // Paystack amount is in kobo (x100)
      reference,
      callback_url: callback_url || process.env.PAYSTACK_CALLBACK_URL,
      metadata: {
        user_id,
        plan_id,
        custom_fields: [
          {
            display_name: 'Plan Name',
            variable_name: 'plan_name',
            value: plan.name
          },
          {
            display_name: 'Username',
            variable_name: 'username',
            value: user.username
          }
        ]
      }
    });
    
    // Create a pending transaction in our database
    await Transaction.create({
      user_id,
      plan_id,
      amount: (amount || plan.price) / 100, // Convert back to naira for our records
      payment_method: 'paystack',
      status: 'pending',
      reference,
      notes: `Paystack payment for ${plan.name} plan`
    });
    
    res.status(200).json({
      success: true,
      message: 'Paystack transaction initialized',
      data: response
    });
  } catch (error) {
    next(createError(500, 'Error initializing Paystack transaction', error));
  }
};

/**
 * Verify a Paystack transaction
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const verifyPaystackTransaction = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const { reference } = req.body;
    
    // Find the transaction in our database
    const transaction = await Transaction.findOne({
      where: { reference },
      include: [
        { model: User },
        { model: Plan }
      ]
    });
    
    if (!transaction) {
      return next(createError(404, 'Transaction not found'));
    }
    
    // Verify with Paystack
    const paystackService = new PaystackService();
    const response = await paystackService.verifyTransaction(reference);
    
    if (response.status === 'success') {
      // Update transaction status
      await transaction.update({
        status: 'completed',
        payment_details: JSON.stringify(response)
      });
      
      // Send notifications
      try {
        // Email receipt
        const emailService = new EmailService();
        await emailService.sendPaymentReceipt(transaction.User.email, {
          name: transaction.User.full_name,
          amount: transaction.amount,
          reference: transaction.reference,
          date: transaction.created_at,
          paymentMethod: 'Paystack',
          planName: transaction.Plan ? transaction.Plan.name : 'N/A'
        });
        
        // SMS notification
        if (transaction.User.phone) {
          const twilioService = new TwilioService();
          await twilioService.sendPaymentConfirmation(transaction.User.phone, {
            amount: transaction.amount,
            reference: transaction.reference
          });
        }
      } catch (notificationError) {
        console.error('Error sending notification:', notificationError);
      }
      
      res.status(200).json({
        success: true,
        message: 'Payment verified successfully',
        data: {
          transaction_id: transaction.id,
          status: 'completed',
          plan: transaction.Plan ? {
            id: transaction.Plan.id,
            name: transaction.Plan.name,
            duration: transaction.Plan.duration,
            type: transaction.Plan.type
          } : null
        }
      });
    } else {
      // Update transaction status to failed
      await transaction.update({
        status: 'failed',
        payment_details: JSON.stringify(response)
      });
      
      res.status(200).json({
        success: false,
        message: 'Payment verification failed',
        data: {
          transaction_id: transaction.id,
          status: 'failed',
          paystack_response: response
        }
      });
    }
  } catch (error) {
    next(createError(500, 'Error verifying Paystack transaction', error));
  }
};

/**
 * Update transaction status
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const updateTransactionStatus = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const { id } = req.params;
    const { status, notes } = req.body;
    
    // Find the transaction
    const transaction = await Transaction.findByPk(id, {
      include: [
        { model: User },
        { model: Plan }
      ]
    });
    
    if (!transaction) {
      return next(createError(404, 'Transaction not found'));
    }
    
    // Update the transaction
    await transaction.update({
      status,
      notes: notes ? `${transaction.notes}\n${notes}` : transaction.notes,
      updated_by: req.user.id
    });
    
    // If status changed to completed, send notifications
    if (status === 'completed' && transaction.status !== 'completed') {
      try {
        // Email receipt
        const emailService = new EmailService();
        await emailService.sendPaymentReceipt(transaction.User.email, {
          name: transaction.User.full_name,
          amount: transaction.amount,
          reference: transaction.reference,
          date: transaction.created_at,
          paymentMethod: transaction.payment_method,
          planName: transaction.Plan ? transaction.Plan.name : 'N/A'
        });
        
        // SMS notification
        if (transaction.User.phone) {
          const twilioService = new TwilioService();
          await twilioService.sendPaymentConfirmation(transaction.User.phone, {
            amount: transaction.amount,
            reference: transaction.reference
          });
        }
      } catch (notificationError) {
        console.error('Error sending notification:', notificationError);
      }
    }
    
    res.status(200).json({
      success: true,
      message: 'Transaction status updated successfully',
      data: transaction
    });
  } catch (error) {
    next(createError(500, 'Error updating transaction status', error));
  }
};

/**
 * Generate transaction receipt
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const generateReceipt = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // Find the transaction
    const transaction = await Transaction.findByPk(id, {
      include: [
        { model: User, attributes: ['id', 'username', 'email', 'full_name', 'phone'] },
        { model: Plan, attributes: ['id', 'name', 'type', 'duration', 'price'] }
      ]
    });
    
    if (!transaction) {
      return next(createError(404, 'Transaction not found'));
    }
    
    // Check if user is authorized to view this transaction
    if (req.user.role_id !== 1 && req.user.role_id !== 2 && req.user.id !== transaction.user_id) {
      return next(createError(403, 'You are not authorized to view this receipt'));
    }
    
    // Generate receipt PDF
    const emailService = new EmailService();
    const pdfBuffer = await emailService.generateReceiptPDF({
      name: transaction.User.full_name,
      email: transaction.User.email,
      phone: transaction.User.phone,
      amount: transaction.amount,
      reference: transaction.reference,
      date: transaction.created_at,
      paymentMethod: transaction.payment_method,
      planName: transaction.Plan ? transaction.Plan.name : 'N/A',
      planDuration: transaction.Plan ? `${transaction.Plan.duration} ${transaction.Plan.type}` : 'N/A',
      planPrice: transaction.Plan ? transaction.Plan.price : 'N/A',
      status: transaction.status
    });
    
    // Set response headers
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=receipt-${transaction.reference}.pdf`);
    
    // Send the PDF
    res.send(pdfBuffer);
  } catch (error) {
    next(createError(500, 'Error generating receipt', error));
  }
};

/**
 * Get daily transaction statistics
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getDailyTransactionStats = async (req, res, next) => {
  try {
    const days = parseInt(req.query.days) || 7;
    
    // Get start and end dates
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    
    // Query for daily transactions
    const dailyStats = await Transaction.findAll({
      attributes: [
        [sequelize.fn('DATE', sequelize.col('created_at')), 'date'],
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
        [sequelize.fn('SUM', sequelize.col('amount')), 'total']
      ],
      where: {
        created_at: { [Op.between]: [startDate, endDate] },
        status: 'completed'
      },
      group: [sequelize.fn('DATE', sequelize.col('created_at'))],
      order: [[sequelize.fn('DATE', sequelize.col('created_at')), 'ASC']]
    });
    
    // Format the results
    const formattedStats = dailyStats.map(stat => ({
      date: stat.dataValues.date,
      count: parseInt(stat.dataValues.count),
      total: parseFloat(stat.dataValues.total) || 0
    }));
    
    // Fill in missing dates with zero values
    const result = [];
    for (let i = 0; i < days; i++) {
      const date = new Date(endDate);
      date.setDate(date.getDate() - i);
      const dateString = moment(date).format('YYYY-MM-DD');
      
      const existingStat = formattedStats.find(stat => moment(stat.date).format('YYYY-MM-DD') === dateString);
      
      if (existingStat) {
        result.unshift(existingStat);
      } else {
        result.unshift({
          date: dateString,
          count: 0,
          total: 0
        });
      }
    }
    
    res.status(200).json({
      success: true,
      data: result
    });
  } catch (error) {
    next(createError(500, 'Error retrieving daily transaction statistics', error));
  }
};

/**
 * Get monthly transaction statistics
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getMonthlyTransactionStats = async (req, res, next) => {
  try {
    const months = parseInt(req.query.months) || 6;
    
    // Get start and end dates
    const endDate = new Date();
    const startDate = new Date();
    startDate.setMonth(startDate.getMonth() - months);
    
    // Query for monthly transactions
    const monthlyStats = await Transaction.findAll({
      attributes: [
        [sequelize.fn('DATE_FORMAT', sequelize.col('created_at'), '%Y-%m'), 'month'],
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
        [sequelize.fn('SUM', sequelize.col('amount')), 'total']
      ],
      where: {
        created_at: { [Op.between]: [startDate, endDate] },
        status: 'completed'
      },
      group: [sequelize.fn('DATE_FORMAT', sequelize.col('created_at'), '%Y-%m')],
      order: [[sequelize.fn('DATE_FORMAT', sequelize.col('created_at'), '%Y-%m'), 'ASC']]
    });
    
    // Format the results
    const formattedStats = monthlyStats.map(stat => ({
      month: stat.dataValues.month,
      count: parseInt(stat.dataValues.count),
      total: parseFloat(stat.dataValues.total) || 0
    }));
    
    // Fill in missing months with zero values
    const result = [];
    for (let i = 0; i < months; i++) {
      const date = new Date(endDate);
      date.setMonth(date.getMonth() - i);
      const monthString = moment(date).format('YYYY-MM');
      
      const existingStat = formattedStats.find(stat => stat.month === monthString);
      
      if (existingStat) {
        result.unshift(existingStat);
      } else {
        result.unshift({
          month: monthString,
          count: 0,
          total: 0
        });
      }
    }
    
    res.status(200).json({
      success: true,
      data: result
    });
  } catch (error) {
    next(createError(500, 'Error retrieving monthly transaction statistics', error));
  }
};

/**
 * Get transaction statistics by payment method
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getTransactionStatsByPaymentMethod = async (req, res, next) => {
  try {
    const period = req.query.period || 'month'; // 'day', 'week', 'month', 'year', 'all'
    
    // Determine date range based on period
    const endDate = new Date();
    let startDate = new Date();
    
    switch (period) {
      case 'day':
        startDate.setDate(startDate.getDate() - 1);
        break;
      case 'week':
        startDate.setDate(startDate.getDate() - 7);
        break;
      case 'month':
        startDate.setMonth(startDate.getMonth() - 1);
        break;
      case 'year':
        startDate.setFullYear(startDate.getFullYear() - 1);
        break;
      case 'all':
        startDate = new Date(0); // Beginning of time
        break;
      default:
        startDate.setMonth(startDate.getMonth() - 1);
    }
    
    // Query for transactions by payment method
    const paymentMethodStats = await Transaction.findAll({
      attributes: [
        'payment_method',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
        [sequelize.fn('SUM', sequelize.col('amount')), 'total']
      ],
      where: {
        created_at: { [Op.between]: [startDate, endDate] },
        status: 'completed'
      },
      group: ['payment_method'],
      order: [[sequelize.fn('SUM', sequelize.col('amount')), 'DESC']]
    });
    
    // Format the results
    const result = paymentMethodStats.map(stat => ({
      payment_method: stat.payment_method,
      count: parseInt(stat.dataValues.count),
      total: parseFloat(stat.dataValues.total) || 0
    }));
    
    res.status(200).json({
      success: true,
      data: {
        period,
        start_date: startDate,
        end_date: endDate,
        stats: result
      }
    });
  } catch (error) {
    next(createError(500, 'Error retrieving transaction statistics by payment method', error));
  }
};

module.exports = {
  getAllTransactions,
  getTransactionById,
  createTransaction,
  initializePaystackTransaction,
  verifyPaystackTransaction,
  updateTransactionStatus,
  generateReceipt,
  getDailyTransactionStats,
  getMonthlyTransactionStats,
  getTransactionStatsByPaymentMethod
};