const { Setting } = require('../models');
const { validationResult } = require('express-validator');
const { createError, formatValidationErrors } = require('../utils/errorUtils');
const { Op } = require('sequelize');

/**
 * Get all settings
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getAllSettings = async (req, res, next) => {
  try {
    const settings = await Setting.findAll({
      order: [['category', 'ASC'], ['key', 'ASC']]
    });

    // Group settings by category
    const groupedSettings = settings.reduce((acc, setting) => {
      if (!acc[setting.category]) {
        acc[setting.category] = [];
      }
      acc[setting.category].push(setting);
      return acc;
    }, {});

    res.status(200).json({
      success: true,
      data: groupedSettings
    });
  } catch (error) {
    next(createError(500, 'Error retrieving settings', error));
  }
};

/**
 * Get settings by category
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getSettingsByCategory = async (req, res, next) => {
  try {
    const { category } = req.params;

    const settings = await Setting.findAll({
      where: { category },
      order: [['key', 'ASC']]
    });

    if (settings.length === 0) {
      return next(createError(404, `No settings found for category: ${category}`));
    }

    res.status(200).json({
      success: true,
      data: settings
    });
  } catch (error) {
    next(createError(500, 'Error retrieving settings by category', error));
  }
};

/**
 * Get setting by key
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getSettingByKey = async (req, res, next) => {
  try {
    const { key } = req.params;

    const setting = await Setting.findOne({
      where: { key }
    });

    if (!setting) {
      return next(createError(404, `Setting not found with key: ${key}`));
    }

    res.status(200).json({
      success: true,
      data: setting
    });
  } catch (error) {
    next(createError(500, 'Error retrieving setting', error));
  }
};

/**
 * Create setting
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const createSetting = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        errors: formatValidationErrors(errors.array())
      });
    }

    const { key, value, category, description, type } = req.body;

    // Check if setting with the same key already exists
    const existingSetting = await Setting.findOne({
      where: { key }
    });

    if (existingSetting) {
      return next(createError(400, `Setting with key '${key}' already exists`));
    }

    // Create the setting
    const setting = await Setting.create({
      key,
      value,
      category: category || 'general',
      description: description || '',
      type: type || 'string'
    });

    res.status(201).json({
      success: true,
      message: 'Setting created successfully',
      data: setting
    });
  } catch (error) {
    next(createError(500, 'Error creating setting', error));
  }
};

/**
 * Update setting
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const updateSetting = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        errors: formatValidationErrors(errors.array())
      });
    }

    const { key } = req.params;
    const { value, description, category, type } = req.body;

    // Find the setting
    const setting = await Setting.findOne({
      where: { key }
    });

    if (!setting) {
      return next(createError(404, `Setting not found with key: ${key}`));
    }

    // Update the setting
    const updateData = {};
    if (value !== undefined) updateData.value = value;
    if (description !== undefined) updateData.description = description;
    if (category !== undefined) updateData.category = category;
    if (type !== undefined) updateData.type = type;

    await setting.update(updateData);

    res.status(200).json({
      success: true,
      message: 'Setting updated successfully',
      data: setting
    });
  } catch (error) {
    next(createError(500, 'Error updating setting', error));
  }
};

/**
 * Update multiple settings
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const updateMultipleSettings = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        errors: formatValidationErrors(errors.array())
      });
    }

    const { settings } = req.body;

    if (!Array.isArray(settings) || settings.length === 0) {
      return next(createError(400, 'Settings must be a non-empty array'));
    }

    const results = [];
    const errors = [];

    // Update each setting
    for (const settingData of settings) {
      const { key, value } = settingData;

      if (!key) {
        errors.push({ key, error: 'Key is required' });
        continue;
      }

      try {
        // Find the setting
        const setting = await Setting.findOne({
          where: { key }
        });

        if (!setting) {
          errors.push({ key, error: `Setting not found with key: ${key}` });
          continue;
        }

        // Update the setting
        await setting.update({ value });
        results.push({ key, success: true });
      } catch (error) {
        errors.push({ key, error: error.message });
      }
    }

    res.status(200).json({
      success: true,
      message: `${results.length} settings updated successfully`,
      data: {
        updated: results,
        errors: errors.length > 0 ? errors : undefined
      }
    });
  } catch (error) {
    next(createError(500, 'Error updating settings', error));
  }
};

/**
 * Delete setting
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const deleteSetting = async (req, res, next) => {
  try {
    const { key } = req.params;

    // Find the setting
    const setting = await Setting.findOne({
      where: { key }
    });

    if (!setting) {
      return next(createError(404, `Setting not found with key: ${key}`));
    }

    // Delete the setting
    await setting.destroy();

    res.status(200).json({
      success: true,
      message: 'Setting deleted successfully'
    });
  } catch (error) {
    next(createError(500, 'Error deleting setting', error));
  }
};

/**
 * Get public settings
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getPublicSettings = async (req, res, next) => {
  try {
    // Get settings marked as public
    const settings = await Setting.findAll({
      where: {
        is_public: true
      },
      attributes: ['key', 'value', 'category', 'type'],
      order: [['category', 'ASC'], ['key', 'ASC']]
    });

    // Group settings by category
    const groupedSettings = settings.reduce((acc, setting) => {
      if (!acc[setting.category]) {
        acc[setting.category] = {};
      }
      acc[setting.category][setting.key] = setting.value;
      return acc;
    }, {});

    res.status(200).json({
      success: true,
      data: groupedSettings
    });
  } catch (error) {
    next(createError(500, 'Error retrieving public settings', error));
  }
};

/**
 * Initialize default settings
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const initializeDefaultSettings = async (req, res, next) => {
  try {
    // Define default settings
    const defaultSettings = [
      // General settings
      {
        key: 'site_name',
        value: 'ISP Billing System',
        category: 'general',
        description: 'Name of the site',
        type: 'string',
        is_public: true
      },
      {
        key: 'site_description',
        value: 'ISP Billing and Management System',
        category: 'general',
        description: 'Description of the site',
        type: 'string',
        is_public: true
      },
      {
        key: 'company_name',
        value: 'Your ISP Company',
        category: 'general',
        description: 'Company name',
        type: 'string',
        is_public: true
      },
      {
        key: 'company_address',
        value: '123 ISP Street, Internet City',
        category: 'general',
        description: 'Company address',
        type: 'string',
        is_public: true
      },
      {
        key: 'company_phone',
        value: '+1234567890',
        category: 'general',
        description: 'Company phone number',
        type: 'string',
        is_public: true
      },
      {
        key: 'company_email',
        value: 'support@yourisp.com',
        category: 'general',
        description: 'Company email address',
        type: 'string',
        is_public: true
      },
      {
        key: 'currency',
        value: 'USD',
        category: 'general',
        description: 'Default currency',
        type: 'string',
        is_public: true
      },
      {
        key: 'currency_symbol',
        value: '$',
        category: 'general',
        description: 'Currency symbol',
        type: 'string',
        is_public: true
      },
      {
        key: 'date_format',
        value: 'YYYY-MM-DD',
        category: 'general',
        description: 'Date format',
        type: 'string',
        is_public: true
      },
      {
        key: 'time_format',
        value: 'HH:mm:ss',
        category: 'general',
        description: 'Time format',
        type: 'string',
        is_public: true
      },
      {
        key: 'timezone',
        value: 'UTC',
        category: 'general',
        description: 'Default timezone',
        type: 'string',
        is_public: true
      },
      
      // Email settings
      {
        key: 'email_from_address',
        value: 'noreply@yourisp.com',
        category: 'email',
        description: 'Email from address',
        type: 'string',
        is_public: false
      },
      {
        key: 'email_from_name',
        value: 'ISP Billing System',
        category: 'email',
        description: 'Email from name',
        type: 'string',
        is_public: false
      },
      {
        key: 'smtp_host',
        value: 'smtp.yourisp.com',
        category: 'email',
        description: 'SMTP host',
        type: 'string',
        is_public: false
      },
      {
        key: 'smtp_port',
        value: '587',
        category: 'email',
        description: 'SMTP port',
        type: 'string',
        is_public: false
      },
      {
        key: 'smtp_secure',
        value: 'false',
        category: 'email',
        description: 'SMTP secure (true/false)',
        type: 'boolean',
        is_public: false
      },
      {
        key: 'smtp_username',
        value: '',
        category: 'email',
        description: 'SMTP username',
        type: 'string',
        is_public: false
      },
      {
        key: 'smtp_password',
        value: '',
        category: 'email',
        description: 'SMTP password',
        type: 'password',
        is_public: false
      },
      
      // SMS settings
      {
        key: 'sms_enabled',
        value: 'false',
        category: 'sms',
        description: 'Enable SMS notifications',
        type: 'boolean',
        is_public: false
      },
      {
        key: 'sms_provider',
        value: 'twilio',
        category: 'sms',
        description: 'SMS provider (twilio, etc.)',
        type: 'string',
        is_public: false
      },
      {
        key: 'twilio_account_sid',
        value: '',
        category: 'sms',
        description: 'Twilio Account SID',
        type: 'string',
        is_public: false
      },
      {
        key: 'twilio_auth_token',
        value: '',
        category: 'sms',
        description: 'Twilio Auth Token',
        type: 'password',
        is_public: false
      },
      {
        key: 'twilio_phone_number',
        value: '',
        category: 'sms',
        description: 'Twilio Phone Number',
        type: 'string',
        is_public: false
      },
      
      // Payment settings
      {
        key: 'payment_methods',
        value: JSON.stringify(['cash', 'bank_transfer', 'paystack']),
        category: 'payment',
        description: 'Available payment methods',
        type: 'json',
        is_public: true
      },
      {
        key: 'paystack_enabled',
        value: 'false',
        category: 'payment',
        description: 'Enable Paystack payments',
        type: 'boolean',
        is_public: false
      },
      {
        key: 'paystack_public_key',
        value: '',
        category: 'payment',
        description: 'Paystack Public Key',
        type: 'string',
        is_public: true
      },
      {
        key: 'paystack_secret_key',
        value: '',
        category: 'payment',
        description: 'Paystack Secret Key',
        type: 'password',
        is_public: false
      },
      {
        key: 'paystack_webhook_secret',
        value: '',
        category: 'payment',
        description: 'Paystack Webhook Secret',
        type: 'password',
        is_public: false
      },
      
      // Hotspot settings
      {
        key: 'hotspot_name',
        value: 'ISP Hotspot',
        category: 'hotspot',
        description: 'Hotspot name',
        type: 'string',
        is_public: true
      },
      {
        key: 'hotspot_logo',
        value: '/assets/images/logo.png',
        category: 'hotspot',
        description: 'Hotspot logo URL',
        type: 'string',
        is_public: true
      },
      {
        key: 'hotspot_background',
        value: '/assets/images/background.jpg',
        category: 'hotspot',
        description: 'Hotspot background image URL',
        type: 'string',
        is_public: true
      },
      {
        key: 'hotspot_primary_color',
        value: '#3498db',
        category: 'hotspot',
        description: 'Hotspot primary color',
        type: 'string',
        is_public: true
      },
      {
        key: 'hotspot_secondary_color',
        value: '#2c3e50',
        category: 'hotspot',
        description: 'Hotspot secondary color',
        type: 'string',
        is_public: true
      },
      {
        key: 'hotspot_terms_url',
        value: '/terms',
        category: 'hotspot',
        description: 'Hotspot terms and conditions URL',
        type: 'string',
        is_public: true
      },
      {
        key: 'hotspot_help_url',
        value: '/help',
        category: 'hotspot',
        description: 'Hotspot help URL',
        type: 'string',
        is_public: true
      },
      
      // System settings
      {
        key: 'session_sync_interval',
        value: '5',
        category: 'system',
        description: 'Session sync interval (minutes)',
        type: 'number',
        is_public: false
      },
      {
        key: 'auto_disconnect_expired',
        value: 'true',
        category: 'system',
        description: 'Auto disconnect expired users',
        type: 'boolean',
        is_public: false
      },
      {
        key: 'maintenance_mode',
        value: 'false',
        category: 'system',
        description: 'Maintenance mode',
        type: 'boolean',
        is_public: true
      },
      {
        key: 'maintenance_message',
        value: 'System is under maintenance. Please try again later.',
        category: 'system',
        description: 'Maintenance mode message',
        type: 'text',
        is_public: true
      },
      {
        key: 'debug_mode',
        value: 'false',
        category: 'system',
        description: 'Debug mode',
        type: 'boolean',
        is_public: false
      }
    ];

    // Count existing settings
    const existingCount = await Setting.count();

    // Create settings if they don't exist
    for (const settingData of defaultSettings) {
      const [setting, created] = await Setting.findOrCreate({
        where: { key: settingData.key },
        defaults: settingData
      });

      // If setting exists but some fields are missing, update them
      if (!created) {
        const updateData = {};
        if (!setting.category) updateData.category = settingData.category;
        if (!setting.description) updateData.description = settingData.description;
        if (!setting.type) updateData.type = settingData.type;
        if (setting.is_public === null || setting.is_public === undefined) {
          updateData.is_public = settingData.is_public;
        }

        if (Object.keys(updateData).length > 0) {
          await setting.update(updateData);
        }
      }
    }

    // Count settings after initialization
    const newCount = await Setting.count();
    const createdCount = newCount - existingCount;

    res.status(200).json({
      success: true,
      message: `Settings initialized successfully. ${createdCount} new settings created.`,
      data: {
        total: newCount,
        created: createdCount
      }
    });
  } catch (error) {
    next(createError(500, 'Error initializing default settings', error));
  }
};

module.exports = {
  getAllSettings,
  getSettingsByCategory,
  getSettingByKey,
  createSetting,
  updateSetting,
  updateMultipleSettings,
  deleteSetting,
  getPublicSettings,
  initializeDefaultSettings
};