const { Router, Plan, Session } = require('../models');
const { validationResult } = require('express-validator');
const { createError, formatValidationErrors } = require('../utils/errorUtils');
const { Op } = require('sequelize');
const MikroTikService = require('../services/MikroTikService');

/**
 * Get all routers
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getAllRouters = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const search = req.query.search || '';
    const status = req.query.status;
    
    // Build query conditions
    const whereConditions = {};
    
    if (search) {
      whereConditions[Op.or] = [
        { name: { [Op.like]: `%${search}%` } },
        { ip_address: { [Op.like]: `%${search}%` } },
        { location: { [Op.like]: `%${search}%` } }
      ];
    }
    
    if (status) {
      whereConditions.is_active = status === 'active';
    }
    
    // Get routers with pagination
    const { count, rows: routers } = await Router.findAndCountAll({
      where: whereConditions,
      limit,
      offset,
      order: [['created_at', 'DESC']]
    });
    
    // Calculate pagination info
    const totalPages = Math.ceil(count / limit);
    
    res.status(200).json({
      success: true,
      data: {
        routers,
        pagination: {
          total: count,
          page,
          limit,
          totalPages
        }
      }
    });
  } catch (error) {
    next(createError(500, 'Error retrieving routers', error));
  }
};

/**
 * Get router by ID
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getRouterById = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    const router = await Router.findByPk(id);
    
    if (!router) {
      return next(createError(404, 'Router not found'));
    }
    
    // Remove sensitive information
    const routerData = router.toJSON();
    delete routerData.password;
    
    res.status(200).json({
      success: true,
      data: routerData
    });
  } catch (error) {
    next(createError(500, 'Error retrieving router', error));
  }
};

/**
 * Create a new router
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const createRouter = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const { name, ip_address, username, password, port, location, api_key, is_active } = req.body;
    
    // Check if router with same IP already exists
    const existingRouter = await Router.findOne({
      where: { ip_address }
    });
    
    if (existingRouter) {
      return next(createError(400, 'Router with this IP address already exists'));
    }
    
    // Test connection to router
    try {
      const mikroTikService = new MikroTikService();
      await mikroTikService.connect({
        host: ip_address,
        username,
        password,
        port: port || 8728
      });
      
      await mikroTikService.disconnect();
    } catch (connectionError) {
      return next(createError(400, 'Failed to connect to router. Please check credentials.', connectionError));
    }
    
    // Create the router
    const router = await Router.create({
      name,
      ip_address,
      username,
      password,
      port: port || 8728,
      location,
      api_key: api_key || Router.generateApiKey(),
      is_active: is_active !== undefined ? is_active : true,
      created_by: req.user.id
    });
    
    // Remove sensitive information from response
    const routerData = router.toJSON();
    delete routerData.password;
    
    res.status(201).json({
      success: true,
      message: 'Router created successfully',
      data: routerData
    });
  } catch (error) {
    next(createError(500, 'Error creating router', error));
  }
};

/**
 * Update a router
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const updateRouter = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const { id } = req.params;
    const { name, ip_address, username, password, port, location, api_key, is_active } = req.body;
    
    // Find the router
    const router = await Router.findByPk(id);
    
    if (!router) {
      return next(createError(404, 'Router not found'));
    }
    
    // Check if IP address is being changed and if it's already in use
    if (ip_address && ip_address !== router.ip_address) {
      const existingRouter = await Router.findOne({
        where: {
          ip_address,
          id: { [Op.ne]: id }
        }
      });
      
      if (existingRouter) {
        return next(createError(400, 'Router with this IP address already exists'));
      }
    }
    
    // If credentials are being updated, test connection
    if ((ip_address && ip_address !== router.ip_address) ||
        (username && username !== router.username) ||
        (password && password !== router.password) ||
        (port && port !== router.port)) {
      try {
        const mikroTikService = new MikroTikService();
        await mikroTikService.connect({
          host: ip_address || router.ip_address,
          username: username || router.username,
          password: password || router.password,
          port: port || router.port
        });
        
        await mikroTikService.disconnect();
      } catch (connectionError) {
        return next(createError(400, 'Failed to connect to router with new credentials', connectionError));
      }
    }
    
    // Update the router
    await router.update({
      name: name || router.name,
      ip_address: ip_address || router.ip_address,
      username: username || router.username,
      password: password || router.password,
      port: port || router.port,
      location: location || router.location,
      api_key: api_key || router.api_key,
      is_active: is_active !== undefined ? is_active : router.is_active,
      updated_by: req.user.id
    });
    
    // Remove sensitive information from response
    const routerData = router.toJSON();
    delete routerData.password;
    
    res.status(200).json({
      success: true,
      message: 'Router updated successfully',
      data: routerData
    });
  } catch (error) {
    next(createError(500, 'Error updating router', error));
  }
};

/**
 * Delete a router
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const deleteRouter = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // Find the router
    const router = await Router.findByPk(id);
    
    if (!router) {
      return next(createError(404, 'Router not found'));
    }
    
    // Check if router has active sessions
    const activeSessions = await Session.count({
      where: {
        router_id: id,
        status: 'active'
      }
    });
    
    if (activeSessions > 0) {
      return next(createError(400, `Cannot delete router with ${activeSessions} active sessions`));
    }
    
    // Delete the router
    await router.destroy();
    
    res.status(200).json({
      success: true,
      message: 'Router deleted successfully'
    });
  } catch (error) {
    next(createError(500, 'Error deleting router', error));
  }
};

/**
 * Test connection to a router
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const testRouterConnection = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const { id } = req.params;
    
    // Find the router
    const router = await Router.findByPk(id);
    
    if (!router) {
      return next(createError(404, 'Router not found'));
    }
    
    // Test connection
    try {
      const mikroTikService = new MikroTikService();
      await mikroTikService.connect({
        host: router.ip_address,
        username: router.username,
        password: router.password,
        port: router.port
      });
      
      // Get system resource info
      const systemResource = await mikroTikService.getSystemResource();
      
      await mikroTikService.disconnect();
      
      res.status(200).json({
        success: true,
        message: 'Connection successful',
        data: {
          connected: true,
          system_info: systemResource
        }
      });
    } catch (connectionError) {
      res.status(200).json({
        success: false,
        message: 'Connection failed',
        data: {
          connected: false,
          error: connectionError.message
        }
      });
    }
  } catch (error) {
    next(createError(500, 'Error testing router connection', error));
  }
};

/**
 * Get router status
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getRouterStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // Find the router
    const router = await Router.findByPk(id);
    
    if (!router) {
      return next(createError(404, 'Router not found'));
    }
    
    // Get router status
    try {
      const mikroTikService = new MikroTikService();
      await mikroTikService.connect({
        host: router.ip_address,
        username: router.username,
        password: router.password,
        port: router.port
      });
      
      // Get system resource info
      const systemResource = await mikroTikService.getSystemResource();
      
      // Get active sessions count
      const activeSessions = await mikroTikService.getActiveSessions();
      
      // Get health info
      const health = await mikroTikService.getHealthInfo();
      
      await mikroTikService.disconnect();
      
      res.status(200).json({
        success: true,
        data: {
          system_info: systemResource,
          active_sessions: activeSessions.length,
          health
        }
      });
    } catch (connectionError) {
      res.status(200).json({
        success: false,
        message: 'Failed to get router status',
        data: {
          error: connectionError.message
        }
      });
    }
  } catch (error) {
    next(createError(500, 'Error getting router status', error));
  }
};

/**
 * Get router interfaces
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getRouterInterfaces = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // Find the router
    const router = await Router.findByPk(id);
    
    if (!router) {
      return next(createError(404, 'Router not found'));
    }
    
    // Get router interfaces
    try {
      const mikroTikService = new MikroTikService();
      await mikroTikService.connect({
        host: router.ip_address,
        username: router.username,
        password: router.password,
        port: router.port
      });
      
      // Get interfaces
      const interfaces = await mikroTikService.getInterfaces();
      
      await mikroTikService.disconnect();
      
      res.status(200).json({
        success: true,
        data: interfaces
      });
    } catch (connectionError) {
      res.status(200).json({
        success: false,
        message: 'Failed to get router interfaces',
        data: {
          error: connectionError.message
        }
      });
    }
  } catch (error) {
    next(createError(500, 'Error getting router interfaces', error));
  }
};

/**
 * Get router hotspot users
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getRouterHotspotUsers = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // Find the router
    const router = await Router.findByPk(id);
    
    if (!router) {
      return next(createError(404, 'Router not found'));
    }
    
    // Get hotspot users
    try {
      const mikroTikService = new MikroTikService();
      await mikroTikService.connect({
        host: router.ip_address,
        username: router.username,
        password: router.password,
        port: router.port
      });
      
      // Get hotspot users
      const hotspotUsers = await mikroTikService.getHotspotUsers();
      
      await mikroTikService.disconnect();
      
      res.status(200).json({
        success: true,
        data: hotspotUsers
      });
    } catch (connectionError) {
      res.status(200).json({
        success: false,
        message: 'Failed to get hotspot users',
        data: {
          error: connectionError.message
        }
      });
    }
  } catch (error) {
    next(createError(500, 'Error getting hotspot users', error));
  }
};

/**
 * Get router hotspot user profiles
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const getRouterHotspotProfiles = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // Find the router
    const router = await Router.findByPk(id);
    
    if (!router) {
      return next(createError(404, 'Router not found'));
    }
    
    // Get hotspot profiles
    try {
      const mikroTikService = new MikroTikService();
      await mikroTikService.connect({
        host: router.ip_address,
        username: router.username,
        password: router.password,
        port: router.port
      });
      
      // Get hotspot user profiles
      const hotspotProfiles = await mikroTikService.getHotspotUserProfiles();
      
      await mikroTikService.disconnect();
      
      res.status(200).json({
        success: true,
        data: hotspotProfiles
      });
    } catch (connectionError) {
      res.status(200).json({
        success: false,
        message: 'Failed to get hotspot profiles',
        data: {
          error: connectionError.message
        }
      });
    }
  } catch (error) {
    next(createError(500, 'Error getting hotspot profiles', error));
  }
};

/**
 * Sync plans with router
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const syncPlansWithRouter = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // Find the router
    const router = await Router.findByPk(id);
    
    if (!router) {
      return next(createError(404, 'Router not found'));
    }
    
    // Get all active plans
    const plans = await Plan.findAll({
      where: { is_active: true }
    });
    
    if (plans.length === 0) {
      return res.status(200).json({
        success: true,
        message: 'No active plans to sync',
        data: { synced: 0 }
      });
    }
    
    // Connect to router
    try {
      const mikroTikService = new MikroTikService();
      await mikroTikService.connect({
        host: router.ip_address,
        username: router.username,
        password: router.password,
        port: router.port
      });
      
      // Get existing profiles
      const existingProfiles = await mikroTikService.getHotspotUserProfiles();
      const existingProfileNames = existingProfiles.map(profile => profile.name);
      
      let created = 0;
      let updated = 0;
      
      // Sync each plan
      for (const plan of plans) {
        const profileName = `PLAN-${plan.id}`;
        const profileExists = existingProfileNames.includes(profileName);
        
        // Prepare profile data
        const profileData = {
          name: profileName,
          rate_limit: `${plan.upload_speed}k/${plan.download_speed}k`,
          shared_users: plan.shared_users || 1
        };
        
        // Add session timeout for time-based plans
        if (plan.type === 'hours' || plan.type === 'days' || plan.type === 'weeks' || plan.type === 'months') {
          let sessionTimeout = '';
          
          switch (plan.type) {
            case 'hours':
              sessionTimeout = `${plan.duration}:00:00`;
              break;
            case 'days':
              sessionTimeout = `${plan.duration}d`;
              break;
            case 'weeks':
              sessionTimeout = `${plan.duration * 7}d`;
              break;
            case 'months':
              sessionTimeout = `${plan.duration * 30}d`;
              break;
          }
          
          profileData.session_timeout = sessionTimeout;
        }
        
        // Add data limit for data-based plans
        if (plan.type === 'data' && plan.data_limit) {
          profileData.data_limit = `${plan.data_limit}M`;
        }
        
        if (profileExists) {
          // Update existing profile
          await mikroTikService.updateHotspotUserProfile(profileName, profileData);
          updated++;
        } else {
          // Create new profile
          await mikroTikService.createHotspotUserProfile(profileData);
          created++;
        }
      }
      
      await mikroTikService.disconnect();
      
      res.status(200).json({
        success: true,
        message: `Plans synced successfully: ${created} created, ${updated} updated`,
        data: {
          created,
          updated,
          total: plans.length
        }
      });
    } catch (connectionError) {
      res.status(200).json({
        success: false,
        message: 'Failed to sync plans with router',
        data: {
          error: connectionError.message
        }
      });
    }
  } catch (error) {
    next(createError(500, 'Error syncing plans with router', error));
  }
};

/**
 * Generate custom login page
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const generateLoginPage = async (req, res, next) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        ...formatValidationErrors(errors.array())
      });
    }
    
    const { id } = req.params;
    const { title, logo_url, background_color, text_color, button_color, company_name, terms_url } = req.body;
    
    // Find the router
    const router = await Router.findByPk(id);
    
    if (!router) {
      return next(createError(404, 'Router not found'));
    }
    
    // Get public plans
    const publicPlans = await Plan.findAll({
      where: {
        is_active: true,
        is_public: true
      },
      order: [['price', 'ASC']]
    });
    
    // Generate login page HTML
    try {
      const mikroTikService = new MikroTikService();
      await mikroTikService.connect({
        host: router.ip_address,
        username: router.username,
        password: router.password,
        port: router.port
      });
      
      // Generate login page HTML
      const loginPageHtml = mikroTikService.generateLoginPageHtml({
        title: title || 'Hotspot Login',
        logoUrl: logo_url || '',
        backgroundColor: background_color || '#ffffff',
        textColor: text_color || '#333333',
        buttonColor: button_color || '#4CAF50',
        companyName: company_name || 'ISP Billing',
        termsUrl: terms_url || '',
        plans: publicPlans.map(plan => ({
          id: plan.id,
          name: plan.name,
          price: plan.price,
          duration: plan.duration,
          type: plan.type,
          download_speed: plan.download_speed,
          upload_speed: plan.upload_speed,
          data_limit: plan.data_limit
        }))
      });
      
      // Upload login page to router
      await mikroTikService.uploadLoginPage(loginPageHtml);
      
      await mikroTikService.disconnect();
      
      res.status(200).json({
        success: true,
        message: 'Login page generated and uploaded successfully',
        data: {
          html_preview: loginPageHtml.substring(0, 500) + '...'
        }
      });
    } catch (connectionError) {
      res.status(200).json({
        success: false,
        message: 'Failed to generate and upload login page',
        data: {
          error: connectionError.message
        }
      });
    }
  } catch (error) {
    next(createError(500, 'Error generating login page', error));
  }
};

module.exports = {
  getAllRouters,
  getRouterById,
  createRouter,
  updateRouter,
  deleteRouter,
  testRouterConnection,
  getRouterStatus,
  getRouterInterfaces,
  getRouterHotspotUsers,
  getRouterHotspotProfiles,
  syncPlansWithRouter,
  generateLoginPage
};