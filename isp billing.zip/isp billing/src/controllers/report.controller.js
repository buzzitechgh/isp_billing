const { Transaction, User, Plan, Session, Router, Voucher } = require('../models');
const { createError } = require('../utils/errorUtils');
const { Op, Sequelize } = require('sequelize');
const moment = require('moment');
const PDFDocument = require('pdfkit');
const ExcelJS = require('exceljs');
const fs = require('fs');
const path = require('path');

/**
 * Generate revenue report
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const generateRevenueReport = async (req, res, next) => {
  try {
    const { start_date, end_date, payment_method, format } = req.query;
    
    // Validate dates
    const startDate = start_date ? moment(start_date).startOf('day') : moment().subtract(30, 'days').startOf('day');
    const endDate = end_date ? moment(end_date).endOf('day') : moment().endOf('day');
    
    if (!startDate.isValid() || !endDate.isValid()) {
      return next(createError(400, 'Invalid date format'));
    }
    
    if (endDate.isBefore(startDate)) {
      return next(createError(400, 'End date cannot be before start date'));
    }
    
    // Build query conditions
    const whereConditions = {
      status: 'completed',
      created_at: {
        [Op.between]: [startDate.toDate(), endDate.toDate()]
      }
    };
    
    if (payment_method) {
      whereConditions.payment_method = payment_method;
    }
    
    // Get transactions
    const transactions = await Transaction.findAll({
      where: whereConditions,
      include: [
        { model: User, attributes: ['id', 'username', 'email', 'full_name'] },
        { model: Plan, attributes: ['id', 'name', 'price', 'type', 'duration'] }
      ],
      order: [['created_at', 'DESC']]
    });
    
    // Calculate summary statistics
    const totalRevenue = transactions.reduce((sum, t) => sum + parseFloat(t.amount), 0);
    const paymentMethodStats = transactions.reduce((acc, t) => {
      const method = t.payment_method;
      if (!acc[method]) {
        acc[method] = { count: 0, amount: 0 };
      }
      acc[method].count += 1;
      acc[method].amount += parseFloat(t.amount);
      return acc;
    }, {});
    
    // Group by date
    const dailyRevenue = transactions.reduce((acc, t) => {
      const date = moment(t.created_at).format('YYYY-MM-DD');
      if (!acc[date]) {
        acc[date] = 0;
      }
      acc[date] += parseFloat(t.amount);
      return acc;
    }, {});
    
    // Group by plan
    const planRevenue = transactions.reduce((acc, t) => {
      if (!t.Plan) return acc;
      
      const planId = t.Plan.id;
      const planName = t.Plan.name;
      
      if (!acc[planId]) {
        acc[planId] = { name: planName, count: 0, amount: 0 };
      }
      acc[planId].count += 1;
      acc[planId].amount += parseFloat(t.amount);
      return acc;
    }, {});
    
    // Prepare report data
    const reportData = {
      period: {
        start_date: startDate.format('YYYY-MM-DD'),
        end_date: endDate.format('YYYY-MM-DD'),
        days: endDate.diff(startDate, 'days') + 1
      },
      summary: {
        total_revenue: totalRevenue.toFixed(2),
        transaction_count: transactions.length,
        average_transaction: transactions.length > 0 ? (totalRevenue / transactions.length).toFixed(2) : '0.00'
      },
      payment_methods: paymentMethodStats,
      daily_revenue: dailyRevenue,
      plan_revenue: planRevenue,
      transactions: transactions.map(t => ({
        id: t.id,
        reference: t.reference,
        amount: parseFloat(t.amount).toFixed(2),
        payment_method: t.payment_method,
        user: t.User ? `${t.User.full_name || t.User.username}` : 'Unknown',
        plan: t.Plan ? t.Plan.name : 'Unknown',
        date: moment(t.created_at).format('YYYY-MM-DD HH:mm:ss')
      }))
    };
    
    // Generate report in requested format
    if (format === 'pdf') {
      return generatePDFReport(res, 'Revenue Report', reportData);
    } else if (format === 'excel') {
      return generateExcelReport(res, 'Revenue Report', reportData);
    } else {
      // Default to JSON
      res.status(200).json({
        success: true,
        data: reportData
      });
    }
  } catch (error) {
    next(createError(500, 'Error generating revenue report', error));
  }
};

/**
 * Generate user report
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const generateUserReport = async (req, res, next) => {
  try {
    const { start_date, end_date, status, format } = req.query;
    
    // Validate dates
    const startDate = start_date ? moment(start_date).startOf('day') : moment().subtract(30, 'days').startOf('day');
    const endDate = end_date ? moment(end_date).endOf('day') : moment().endOf('day');
    
    if (!startDate.isValid() || !endDate.isValid()) {
      return next(createError(400, 'Invalid date format'));
    }
    
    if (endDate.isBefore(startDate)) {
      return next(createError(400, 'End date cannot be before start date'));
    }
    
    // Build query conditions
    const whereConditions = {
      created_at: {
        [Op.between]: [startDate.toDate(), endDate.toDate()]
      }
    };
    
    if (status) {
      whereConditions.is_active = status === 'active';
    }
    
    // Get users
    const users = await User.findAll({
      where: whereConditions,
      include: [
        { model: Transaction, as: 'Transactions', required: false },
        { model: Session, as: 'Sessions', required: false }
      ],
      order: [['created_at', 'DESC']]
    });
    
    // Calculate summary statistics
    const totalUsers = users.length;
    const activeUsers = users.filter(u => u.is_active).length;
    const inactiveUsers = totalUsers - activeUsers;
    
    // Group by date
    const dailySignups = users.reduce((acc, u) => {
      const date = moment(u.created_at).format('YYYY-MM-DD');
      if (!acc[date]) {
        acc[date] = 0;
      }
      acc[date] += 1;
      return acc;
    }, {});
    
    // Group by role
    const roleStats = users.reduce((acc, u) => {
      const roleId = u.role_id;
      if (!acc[roleId]) {
        acc[roleId] = 0;
      }
      acc[roleId] += 1;
      return acc;
    }, {});
    
    // Prepare report data
    const reportData = {
      period: {
        start_date: startDate.format('YYYY-MM-DD'),
        end_date: endDate.format('YYYY-MM-DD'),
        days: endDate.diff(startDate, 'days') + 1
      },
      summary: {
        total_users: totalUsers,
        active_users: activeUsers,
        inactive_users: inactiveUsers,
        signup_rate: totalUsers > 0 ? (totalUsers / (endDate.diff(startDate, 'days') + 1)).toFixed(2) : '0.00'
      },
      daily_signups: dailySignups,
      role_stats: roleStats,
      users: users.map(u => ({
        id: u.id,
        username: u.username,
        email: u.email,
        full_name: u.full_name,
        phone: u.phone,
        status: u.is_active ? 'Active' : 'Inactive',
        role_id: u.role_id,
        transactions: u.Transactions ? u.Transactions.length : 0,
        sessions: u.Sessions ? u.Sessions.length : 0,
        created_at: moment(u.created_at).format('YYYY-MM-DD HH:mm:ss')
      }))
    };
    
    // Generate report in requested format
    if (format === 'pdf') {
      return generatePDFReport(res, 'User Report', reportData);
    } else if (format === 'excel') {
      return generateExcelReport(res, 'User Report', reportData);
    } else {
      // Default to JSON
      res.status(200).json({
        success: true,
        data: reportData
      });
    }
  } catch (error) {
    next(createError(500, 'Error generating user report', error));
  }
};

/**
 * Generate session report
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const generateSessionReport = async (req, res, next) => {
  try {
    const { start_date, end_date, router_id, status, format } = req.query;
    
    // Validate dates
    const startDate = start_date ? moment(start_date).startOf('day') : moment().subtract(7, 'days').startOf('day');
    const endDate = end_date ? moment(end_date).endOf('day') : moment().endOf('day');
    
    if (!startDate.isValid() || !endDate.isValid()) {
      return next(createError(400, 'Invalid date format'));
    }
    
    if (endDate.isBefore(startDate)) {
      return next(createError(400, 'End date cannot be before start date'));
    }
    
    // Build query conditions
    const whereConditions = {
      start_time: {
        [Op.between]: [startDate.toDate(), endDate.toDate()]
      }
    };
    
    if (router_id) {
      whereConditions.router_id = router_id;
    }
    
    if (status) {
      whereConditions.status = status;
    }
    
    // Get sessions
    const sessions = await Session.findAll({
      where: whereConditions,
      include: [
        { model: User, attributes: ['id', 'username', 'email', 'full_name'] },
        { model: Router, attributes: ['id', 'name', 'ip_address'] }
      ],
      order: [['start_time', 'DESC']]
    });
    
    // Calculate summary statistics
    const totalSessions = sessions.length;
    const activeSessions = sessions.filter(s => s.status === 'active').length;
    const endedSessions = sessions.filter(s => s.status === 'ended').length;
    
    // Calculate total data usage
    const totalDownload = sessions.reduce((sum, s) => sum + (parseFloat(s.bytes_down) || 0), 0);
    const totalUpload = sessions.reduce((sum, s) => sum + (parseFloat(s.bytes_up) || 0), 0);
    const totalData = totalDownload + totalUpload;
    
    // Group by date
    const dailySessions = sessions.reduce((acc, s) => {
      const date = moment(s.start_time).format('YYYY-MM-DD');
      if (!acc[date]) {
        acc[date] = { count: 0, data: 0 };
      }
      acc[date].count += 1;
      acc[date].data += (parseFloat(s.bytes_down) || 0) + (parseFloat(s.bytes_up) || 0);
      return acc;
    }, {});
    
    // Group by router
    const routerStats = sessions.reduce((acc, s) => {
      if (!s.Router) return acc;
      
      const routerId = s.Router.id;
      const routerName = s.Router.name;
      
      if (!acc[routerId]) {
        acc[routerId] = { name: routerName, count: 0, data: 0 };
      }
      acc[routerId].count += 1;
      acc[routerId].data += (parseFloat(s.bytes_down) || 0) + (parseFloat(s.bytes_up) || 0);
      return acc;
    }, {});
    
    // Format data size
    const formatBytes = (bytes) => {
      if (bytes === 0) return '0 Bytes';
      const k = 1024;
      const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };
    
    // Prepare report data
    const reportData = {
      period: {
        start_date: startDate.format('YYYY-MM-DD'),
        end_date: endDate.format('YYYY-MM-DD'),
        days: endDate.diff(startDate, 'days') + 1
      },
      summary: {
        total_sessions: totalSessions,
        active_sessions: activeSessions,
        ended_sessions: endedSessions,
        total_download: formatBytes(totalDownload),
        total_upload: formatBytes(totalUpload),
        total_data: formatBytes(totalData),
        average_session_data: totalSessions > 0 ? formatBytes(totalData / totalSessions) : '0 Bytes'
      },
      daily_sessions: dailySessions,
      router_stats: routerStats,
      sessions: sessions.map(s => ({
        id: s.id,
        user: s.User ? `${s.User.full_name || s.User.username}` : 'Unknown',
        router: s.Router ? s.Router.name : 'Unknown',
        ip_address: s.ip_address,
        mac_address: s.mac_address,
        status: s.status,
        start_time: moment(s.start_time).format('YYYY-MM-DD HH:mm:ss'),
        end_time: s.end_time ? moment(s.end_time).format('YYYY-MM-DD HH:mm:ss') : '-',
        duration: s.duration ? `${s.duration} minutes` : '-',
        download: formatBytes(parseFloat(s.bytes_down) || 0),
        upload: formatBytes(parseFloat(s.bytes_up) || 0),
        total_data: formatBytes((parseFloat(s.bytes_down) || 0) + (parseFloat(s.bytes_up) || 0))
      }))
    };
    
    // Generate report in requested format
    if (format === 'pdf') {
      return generatePDFReport(res, 'Session Report', reportData);
    } else if (format === 'excel') {
      return generateExcelReport(res, 'Session Report', reportData);
    } else {
      // Default to JSON
      res.status(200).json({
        success: true,
        data: reportData
      });
    }
  } catch (error) {
    next(createError(500, 'Error generating session report', error));
  }
};

/**
 * Generate voucher report
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const generateVoucherReport = async (req, res, next) => {
  try {
    const { start_date, end_date, status, batch_name, format } = req.query;
    
    // Validate dates
    const startDate = start_date ? moment(start_date).startOf('day') : moment().subtract(30, 'days').startOf('day');
    const endDate = end_date ? moment(end_date).endOf('day') : moment().endOf('day');
    
    if (!startDate.isValid() || !endDate.isValid()) {
      return next(createError(400, 'Invalid date format'));
    }
    
    if (endDate.isBefore(startDate)) {
      return next(createError(400, 'End date cannot be before start date'));
    }
    
    // Build query conditions
    const whereConditions = {
      created_at: {
        [Op.between]: [startDate.toDate(), endDate.toDate()]
      }
    };
    
    if (status) {
      whereConditions.status = status;
    }
    
    if (batch_name) {
      whereConditions.batch_name = batch_name;
    }
    
    // Get vouchers
    const vouchers = await Voucher.findAll({
      where: whereConditions,
      include: [
        { model: Plan, attributes: ['id', 'name', 'price', 'type', 'duration'] },
        { model: User, as: 'RedeemedBy', attributes: ['id', 'username', 'email', 'full_name'], required: false }
      ],
      order: [['created_at', 'DESC']]
    });
    
    // Calculate summary statistics
    const totalVouchers = vouchers.length;
    const usedVouchers = vouchers.filter(v => v.status === 'used').length;
    const unusedVouchers = vouchers.filter(v => v.status === 'unused').length;
    const expiredVouchers = vouchers.filter(v => v.status === 'expired').length;
    
    // Group by batch
    const batchStats = vouchers.reduce((acc, v) => {
      const batchName = v.batch_name || 'No Batch';
      if (!acc[batchName]) {
        acc[batchName] = { total: 0, used: 0, unused: 0, expired: 0 };
      }
      acc[batchName].total += 1;
      if (v.status === 'used') acc[batchName].used += 1;
      if (v.status === 'unused') acc[batchName].unused += 1;
      if (v.status === 'expired') acc[batchName].expired += 1;
      return acc;
    }, {});
    
    // Group by plan
    const planStats = vouchers.reduce((acc, v) => {
      if (!v.Plan) return acc;
      
      const planId = v.Plan.id;
      const planName = v.Plan.name;
      
      if (!acc[planId]) {
        acc[planId] = { name: planName, total: 0, used: 0, unused: 0, expired: 0 };
      }
      acc[planId].total += 1;
      if (v.status === 'used') acc[planId].used += 1;
      if (v.status === 'unused') acc[planId].unused += 1;
      if (v.status === 'expired') acc[planId].expired += 1;
      return acc;
    }, {});
    
    // Prepare report data
    const reportData = {
      period: {
        start_date: startDate.format('YYYY-MM-DD'),
        end_date: endDate.format('YYYY-MM-DD'),
        days: endDate.diff(startDate, 'days') + 1
      },
      summary: {
        total_vouchers: totalVouchers,
        used_vouchers: usedVouchers,
        unused_vouchers: unusedVouchers,
        expired_vouchers: expiredVouchers,
        usage_rate: totalVouchers > 0 ? ((usedVouchers / totalVouchers) * 100).toFixed(2) + '%' : '0%'
      },
      batch_stats: batchStats,
      plan_stats: planStats,
      vouchers: vouchers.map(v => ({
        id: v.id,
        code: v.code,
        plan: v.Plan ? v.Plan.name : 'Unknown',
        batch_name: v.batch_name || 'No Batch',
        status: v.status,
        redeemed_by: v.RedeemedBy ? `${v.RedeemedBy.full_name || v.RedeemedBy.username}` : '-',
        redeemed_at: v.redeemed_at ? moment(v.redeemed_at).format('YYYY-MM-DD HH:mm:ss') : '-',
        expires_at: v.expires_at ? moment(v.expires_at).format('YYYY-MM-DD HH:mm:ss') : '-',
        created_at: moment(v.created_at).format('YYYY-MM-DD HH:mm:ss')
      }))
    };
    
    // Generate report in requested format
    if (format === 'pdf') {
      return generatePDFReport(res, 'Voucher Report', reportData);
    } else if (format === 'excel') {
      return generateExcelReport(res, 'Voucher Report', reportData);
    } else {
      // Default to JSON
      res.status(200).json({
        success: true,
        data: reportData
      });
    }
  } catch (error) {
    next(createError(500, 'Error generating voucher report', error));
  }
};

/**
 * Generate PDF report
 * @param {Object} res - Express response object
 * @param {string} title - Report title
 * @param {Object} data - Report data
 */
const generatePDFReport = (res, title, data) => {
  // Create a new PDF document
  const doc = new PDFDocument({ margin: 50 });
  
  // Set response headers
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="${title.replace(/ /g, '_')}_${moment().format('YYYY-MM-DD')}.pdf"`);
  
  // Pipe the PDF document to the response
  doc.pipe(res);
  
  // Add title
  doc.fontSize(20).text(title, { align: 'center' });
  doc.moveDown();
  
  // Add period
  doc.fontSize(12).text(`Period: ${data.period.start_date} to ${data.period.end_date} (${data.period.days} days)`, { align: 'center' });
  doc.moveDown(2);
  
  // Add summary section
  doc.fontSize(16).text('Summary', { underline: true });
  doc.moveDown();
  
  Object.entries(data.summary).forEach(([key, value]) => {
    doc.fontSize(12).text(`${key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}: ${value}`);
  });
  
  doc.moveDown(2);
  
  // Add detailed data based on report type
  if (title === 'Revenue Report') {
    // Add payment methods section
    doc.fontSize(16).text('Payment Methods', { underline: true });
    doc.moveDown();
    
    Object.entries(data.payment_methods).forEach(([method, stats]) => {
      doc.fontSize(12).text(`${method.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}: ${stats.count} transactions, ${parseFloat(stats.amount).toFixed(2)}`);
    });
    
    doc.moveDown(2);
    
    // Add transactions table
    doc.fontSize(16).text('Transactions', { underline: true });
    doc.moveDown();
    
    // Table headers
    const tableTop = doc.y;
    const tableHeaders = ['ID', 'Reference', 'Amount', 'Payment Method', 'User', 'Plan', 'Date'];
    const tableColumnWidths = [30, 80, 60, 80, 80, 80, 100];
    
    let currentY = tableTop;
    
    // Draw headers
    doc.fontSize(10).font('Helvetica-Bold');
    tableHeaders.forEach((header, i) => {
      const x = 50 + tableColumnWidths.slice(0, i).reduce((sum, width) => sum + width, 0);
      doc.text(header, x, currentY, { width: tableColumnWidths[i], align: 'left' });
    });
    
    currentY += 20;
    doc.moveTo(50, currentY).lineTo(550, currentY).stroke();
    currentY += 10;
    
    // Draw rows
    doc.fontSize(9).font('Helvetica');
    data.transactions.slice(0, 20).forEach((transaction) => {
      // Check if we need a new page
      if (currentY > 700) {
        doc.addPage();
        currentY = 50;
      }
      
      const row = [
        transaction.id,
        transaction.reference,
        transaction.amount,
        transaction.payment_method,
        transaction.user,
        transaction.plan,
        transaction.date
      ];
      
      row.forEach((cell, i) => {
        const x = 50 + tableColumnWidths.slice(0, i).reduce((sum, width) => sum + width, 0);
        doc.text(cell.toString(), x, currentY, { width: tableColumnWidths[i], align: 'left' });
      });
      
      currentY += 20;
    });
    
    // Add note if there are more transactions
    if (data.transactions.length > 20) {
      doc.fontSize(10).font('Helvetica-Oblique').text(`Note: Showing 20 of ${data.transactions.length} transactions.`, 50, currentY + 10);
    }
  } else if (title === 'User Report') {
    // Add daily signups section
    doc.fontSize(16).text('Daily Signups', { underline: true });
    doc.moveDown();
    
    Object.entries(data.daily_signups).slice(0, 10).forEach(([date, count]) => {
      doc.fontSize(12).text(`${date}: ${count} users`);
    });
    
    doc.moveDown(2);
    
    // Add users table
    doc.fontSize(16).text('Users', { underline: true });
    doc.moveDown();
    
    // Table headers
    const tableTop = doc.y;
    const tableHeaders = ['ID', 'Username', 'Email', 'Name', 'Status', 'Created At'];
    const tableColumnWidths = [30, 80, 120, 100, 60, 100];
    
    let currentY = tableTop;
    
    // Draw headers
    doc.fontSize(10).font('Helvetica-Bold');
    tableHeaders.forEach((header, i) => {
      const x = 50 + tableColumnWidths.slice(0, i).reduce((sum, width) => sum + width, 0);
      doc.text(header, x, currentY, { width: tableColumnWidths[i], align: 'left' });
    });
    
    currentY += 20;
    doc.moveTo(50, currentY).lineTo(550, currentY).stroke();
    currentY += 10;
    
    // Draw rows
    doc.fontSize(9).font('Helvetica');
    data.users.slice(0, 20).forEach((user) => {
      // Check if we need a new page
      if (currentY > 700) {
        doc.addPage();
        currentY = 50;
      }
      
      const row = [
        user.id,
        user.username,
        user.email,
        user.full_name,
        user.status,
        user.created_at
      ];
      
      row.forEach((cell, i) => {
        const x = 50 + tableColumnWidths.slice(0, i).reduce((sum, width) => sum + width, 0);
        doc.text(cell.toString(), x, currentY, { width: tableColumnWidths[i], align: 'left' });
      });
      
      currentY += 20;
    });
    
    // Add note if there are more users
    if (data.users.length > 20) {
      doc.fontSize(10).font('Helvetica-Oblique').text(`Note: Showing 20 of ${data.users.length} users.`, 50, currentY + 10);
    }
  } else if (title === 'Session Report') {
    // Add router stats section
    doc.fontSize(16).text('Router Statistics', { underline: true });
    doc.moveDown();
    
    Object.entries(data.router_stats).slice(0, 10).forEach(([routerId, stats]) => {
      doc.fontSize(12).text(`${stats.name}: ${stats.count} sessions, ${stats.data} data`);
    });
    
    doc.moveDown(2);
    
    // Add sessions table
    doc.fontSize(16).text('Sessions', { underline: true });
    doc.moveDown();
    
    // Table headers
    const tableTop = doc.y;
    const tableHeaders = ['ID', 'User', 'Router', 'Status', 'Start Time', 'Duration', 'Data'];
    const tableColumnWidths = [30, 100, 80, 60, 100, 60, 60];
    
    let currentY = tableTop;
    
    // Draw headers
    doc.fontSize(10).font('Helvetica-Bold');
    tableHeaders.forEach((header, i) => {
      const x = 50 + tableColumnWidths.slice(0, i).reduce((sum, width) => sum + width, 0);
      doc.text(header, x, currentY, { width: tableColumnWidths[i], align: 'left' });
    });
    
    currentY += 20;
    doc.moveTo(50, currentY).lineTo(550, currentY).stroke();
    currentY += 10;
    
    // Draw rows
    doc.fontSize(9).font('Helvetica');
    data.sessions.slice(0, 20).forEach((session) => {
      // Check if we need a new page
      if (currentY > 700) {
        doc.addPage();
        currentY = 50;
      }
      
      const row = [
        session.id,
        session.user,
        session.router,
        session.status,
        session.start_time,
        session.duration,
        session.total_data
      ];
      
      row.forEach((cell, i) => {
        const x = 50 + tableColumnWidths.slice(0, i).reduce((sum, width) => sum + width, 0);
        doc.text(cell.toString(), x, currentY, { width: tableColumnWidths[i], align: 'left' });
      });
      
      currentY += 20;
    });
    
    // Add note if there are more sessions
    if (data.sessions.length > 20) {
      doc.fontSize(10).font('Helvetica-Oblique').text(`Note: Showing 20 of ${data.sessions.length} sessions.`, 50, currentY + 10);
    }
  } else if (title === 'Voucher Report') {
    // Add batch stats section
    doc.fontSize(16).text('Batch Statistics', { underline: true });
    doc.moveDown();
    
    Object.entries(data.batch_stats).slice(0, 10).forEach(([batchName, stats]) => {
      doc.fontSize(12).text(`${batchName}: ${stats.total} vouchers (${stats.used} used, ${stats.unused} unused, ${stats.expired} expired)`);
    });
    
    doc.moveDown(2);
    
    // Add vouchers table
    doc.fontSize(16).text('Vouchers', { underline: true });
    doc.moveDown();
    
    // Table headers
    const tableTop = doc.y;
    const tableHeaders = ['ID', 'Code', 'Plan', 'Batch', 'Status', 'Redeemed By', 'Expires At'];
    const tableColumnWidths = [30, 80, 80, 80, 60, 100, 100];
    
    let currentY = tableTop;
    
    // Draw headers
    doc.fontSize(10).font('Helvetica-Bold');
    tableHeaders.forEach((header, i) => {
      const x = 50 + tableColumnWidths.slice(0, i).reduce((sum, width) => sum + width, 0);
      doc.text(header, x, currentY, { width: tableColumnWidths[i], align: 'left' });
    });
    
    currentY += 20;
    doc.moveTo(50, currentY).lineTo(550, currentY).stroke();
    currentY += 10;
    
    // Draw rows
    doc.fontSize(9).font('Helvetica');
    data.vouchers.slice(0, 20).forEach((voucher) => {
      // Check if we need a new page
      if (currentY > 700) {
        doc.addPage();
        currentY = 50;
      }
      
      const row = [
        voucher.id,
        voucher.code,
        voucher.plan,
        voucher.batch_name,
        voucher.status,
        voucher.redeemed_by,
        voucher.expires_at
      ];
      
      row.forEach((cell, i) => {
        const x = 50 + tableColumnWidths.slice(0, i).reduce((sum, width) => sum + width, 0);
        doc.text(cell.toString(), x, currentY, { width: tableColumnWidths[i], align: 'left' });
      });
      
      currentY += 20;
    });
    
    // Add note if there are more vouchers
    if (data.vouchers.length > 20) {
      doc.fontSize(10).font('Helvetica-Oblique').text(`Note: Showing 20 of ${data.vouchers.length} vouchers.`, 50, currentY + 10);
    }
  }
  
  // Add footer
  doc.fontSize(10).text(`Generated on ${moment().format('YYYY-MM-DD HH:mm:ss')}`, 50, 750, { align: 'center' });
  
  // Finalize the PDF and end the stream
  doc.end();
};

/**
 * Generate Excel report
 * @param {Object} res - Express response object
 * @param {string} title - Report title
 * @param {Object} data - Report data
 */
const generateExcelReport = async (res, title, data) => {
  // Create a new workbook
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'ISP Billing System';
  workbook.created = new Date();
  
  // Add summary worksheet
  const summarySheet = workbook.addWorksheet('Summary');
  
  // Add title
  summarySheet.mergeCells('A1:G1');
  summarySheet.getCell('A1').value = title;
  summarySheet.getCell('A1').font = { size: 16, bold: true };
  summarySheet.getCell('A1').alignment = { horizontal: 'center' };
  
  // Add period
  summarySheet.mergeCells('A2:G2');
  summarySheet.getCell('A2').value = `Period: ${data.period.start_date} to ${data.period.end_date} (${data.period.days} days)`;
  summarySheet.getCell('A2').font = { size: 12 };
  summarySheet.getCell('A2').alignment = { horizontal: 'center' };
  
  // Add summary section
  summarySheet.getCell('A4').value = 'Summary';
  summarySheet.getCell('A4').font = { size: 14, bold: true };
  
  let row = 5;
  Object.entries(data.summary).forEach(([key, value]) => {
    summarySheet.getCell(`A${row}`).value = key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    summarySheet.getCell(`B${row}`).value = value;
    row++;
  });
  
  // Add data worksheet based on report type
  if (title === 'Revenue Report') {
    // Add payment methods section
    row += 2;
    summarySheet.getCell(`A${row}`).value = 'Payment Methods';
    summarySheet.getCell(`A${row}`).font = { size: 14, bold: true };
    row++;
    
    summarySheet.getCell(`A${row}`).value = 'Method';
    summarySheet.getCell(`B${row}`).value = 'Transactions';
    summarySheet.getCell(`C${row}`).value = 'Amount';
    summarySheet.getRow(row).font = { bold: true };
    row++;
    
    Object.entries(data.payment_methods).forEach(([method, stats]) => {
      summarySheet.getCell(`A${row}`).value = method.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
      summarySheet.getCell(`B${row}`).value = stats.count;
      summarySheet.getCell(`C${row}`).value = parseFloat(stats.amount);
      summarySheet.getCell(`C${row}`).numFmt = '#,##0.00';
      row++;
    });
    
    // Add transactions worksheet
    const transactionsSheet = workbook.addWorksheet('Transactions');
    
    // Add headers
    transactionsSheet.columns = [
      { header: 'ID', key: 'id', width: 10 },
      { header: 'Reference', key: 'reference', width: 20 },
      { header: 'Amount', key: 'amount', width: 15 },
      { header: 'Payment Method', key: 'payment_method', width: 20 },
      { header: 'User', key: 'user', width: 25 },
      { header: 'Plan', key: 'plan', width: 20 },
      { header: 'Date', key: 'date', width: 25 }
    ];
    
    // Add rows
    transactionsSheet.addRows(data.transactions);
    
    // Format amount column
    transactionsSheet.getColumn('amount').numFmt = '#,##0.00';
    
    // Style header row
    transactionsSheet.getRow(1).font = { bold: true };
    transactionsSheet.getRow(1).alignment = { horizontal: 'center' };
  } else if (title === 'User Report') {
    // Add daily signups section
    row += 2;
    summarySheet.getCell(`A${row}`).value = 'Daily Signups';
    summarySheet.getCell(`A${row}`).font = { size: 14, bold: true };
    row++;
    
    summarySheet.getCell(`A${row}`).value = 'Date';
    summarySheet.getCell(`B${row}`).value = 'Users';
    summarySheet.getRow(row).font = { bold: true };
    row++;
    
    Object.entries(data.daily_signups).forEach(([date, count]) => {
      summarySheet.getCell(`A${row}`).value = date;
      summarySheet.getCell(`B${row}`).value = count;
      row++;
    });
    
    // Add users worksheet
    const usersSheet = workbook.addWorksheet('Users');
    
    // Add headers
    usersSheet.columns = [
      { header: 'ID', key: 'id', width: 10 },
      { header: 'Username', key: 'username', width: 20 },
      { header: 'Email', key: 'email', width: 30 },
      { header: 'Full Name', key: 'full_name', width: 25 },
      { header: 'Phone', key: 'phone', width: 20 },
      { header: 'Status', key: 'status', width: 15 },
      { header: 'Role ID', key: 'role_id', width: 10 },
      { header: 'Transactions', key: 'transactions', width: 15 },
      { header: 'Sessions', key: 'sessions', width: 15 },
      { header: 'Created At', key: 'created_at', width: 25 }
    ];
    
    // Add rows
    usersSheet.addRows(data.users);
    
    // Style header row
    usersSheet.getRow(1).font = { bold: true };
    usersSheet.getRow(1).alignment = { horizontal: 'center' };
  } else if (title === 'Session Report') {
    // Add router stats section
    row += 2;
    summarySheet.getCell(`A${row}`).value = 'Router Statistics';
    summarySheet.getCell(`A${row}`).font = { size: 14, bold: true };
    row++;
    
    summarySheet.getCell(`A${row}`).value = 'Router';
    summarySheet.getCell(`B${row}`).value = 'Sessions';
    summarySheet.getCell(`C${row}`).value = 'Data';
    summarySheet.getRow(row).font = { bold: true };
    row++;
    
    Object.entries(data.router_stats).forEach(([routerId, stats]) => {
      summarySheet.getCell(`A${row}`).value = stats.name;
      summarySheet.getCell(`B${row}`).value = stats.count;
      summarySheet.getCell(`C${row}`).value = stats.data;
      row++;
    });
    
    // Add sessions worksheet
    const sessionsSheet = workbook.addWorksheet('Sessions');
    
    // Add headers
    sessionsSheet.columns = [
      { header: 'ID', key: 'id', width: 10 },
      { header: 'User', key: 'user', width: 25 },
      { header: 'Router', key: 'router', width: 20 },
      { header: 'IP Address', key: 'ip_address', width: 15 },
      { header: 'MAC Address', key: 'mac_address', width: 20 },
      { header: 'Status', key: 'status', width: 15 },
      { header: 'Start Time', key: 'start_time', width: 25 },
      { header: 'End Time', key: 'end_time', width: 25 },
      { header: 'Duration', key: 'duration', width: 15 },
      { header: 'Download', key: 'download', width: 15 },
      { header: 'Upload', key: 'upload', width: 15 },
      { header: 'Total Data', key: 'total_data', width: 15 }
    ];
    
    // Add rows
    sessionsSheet.addRows(data.sessions);
    
    // Style header row
    sessionsSheet.getRow(1).font = { bold: true };
    sessionsSheet.getRow(1).alignment = { horizontal: 'center' };
  } else if (title === 'Voucher Report') {
    // Add batch stats section
    row += 2;
    summarySheet.getCell(`A${row}`).value = 'Batch Statistics';
    summarySheet.getCell(`A${row}`).font = { size: 14, bold: true };
    row++;
    
    summarySheet.getCell(`A${row}`).value = 'Batch';
    summarySheet.getCell(`B${row}`).value = 'Total';
    summarySheet.getCell(`C${row}`).value = 'Used';
    summarySheet.getCell(`D${row}`).value = 'Unused';
    summarySheet.getCell(`E${row}`).value = 'Expired';
    summarySheet.getRow(row).font = { bold: true };
    row++;
    
    Object.entries(data.batch_stats).forEach(([batchName, stats]) => {
      summarySheet.getCell(`A${row}`).value = batchName;
      summarySheet.getCell(`B${row}`).value = stats.total;
      summarySheet.getCell(`C${row}`).value = stats.used;
      summarySheet.getCell(`D${row}`).value = stats.unused;
      summarySheet.getCell(`E${row}`).value = stats.expired;
      row++;
    });
    
    // Add vouchers worksheet
    const vouchersSheet = workbook.addWorksheet('Vouchers');
    
    // Add headers
    vouchersSheet.columns = [
      { header: 'ID', key: 'id', width: 10 },
      { header: 'Code', key: 'code', width: 20 },
      { header: 'Plan', key: 'plan', width: 20 },
      { header: 'Batch Name', key: 'batch_name', width: 20 },
      { header: 'Status', key: 'status', width: 15 },
      { header: 'Redeemed By', key: 'redeemed_by', width: 25 },
      { header: 'Redeemed At', key: 'redeemed_at', width: 25 },
      { header: 'Expires At', key: 'expires_at', width: 25 },
      { header: 'Created At', key: 'created_at', width: 25 }
    ];
    
    // Add rows
    vouchersSheet.addRows(data.vouchers);
    
    // Style header row
    vouchersSheet.getRow(1).font = { bold: true };
    vouchersSheet.getRow(1).alignment = { horizontal: 'center' };
  }
  
  // Set response headers
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="${title.replace(/ /g, '_')}_${moment().format('YYYY-MM-DD')}.xlsx"`);
  
  // Write to response
  await workbook.xlsx.write(res);
  res.end();
};

module.exports = {
  generateRevenueReport,
  generateUserReport,
  generateSessionReport,
  generateVoucherReport
};