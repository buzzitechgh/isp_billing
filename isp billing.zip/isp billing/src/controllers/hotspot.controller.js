/**
 * Hotspot Controller
 * Handles MikroTik hotspot API endpoints
 */

const MikroTikService = require('../services/MikroTikService');
const Router = require('../models/Router');
const Voucher = require('../models/Voucher');
const Session = require('../models/Session');
const User = require('../models/User');
const Plan = require('../models/Plan');
const Transaction = require('../models/Transaction');
const PaystackService = require('../services/PaystackService');
const EmailService = require('../services/EmailService');
const TwilioService = require('../services/TwilioService');
const { v4: uuidv4 } = require('uuid');

/**
 * Check for active sessions by MAC and IP address
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
exports.checkSession = async (req, res, next) => {
  try {
    const { mac, ip } = req.body;
    
    // Get all active routers
    const routers = await Router.findAll({ where: { is_active: true } });
    
    if (!routers || routers.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No active routers found'
      });
    }
    
    // Check for active sessions on all routers
    let activeSession = null;
    
    for (const router of routers) {
      try {
        const conn = await MikroTikService.connect({
          host: router.ip_address,
          port: router.port,
          username: router.username,
          password: router.decryptPassword()
        });
        
        // Check for active sessions by MAC address
        const sessions = await conn.write('/ip/hotspot/active/print', [
          '=.proplist=.id,user,address,mac-address,uptime,bytes-in,bytes-out',
          `?mac-address=${mac}`
        ]);
        
        conn.close();
        
        if (sessions && sessions.length > 0) {
          const session = sessions[0];
          activeSession = {
            router: router.name,
            user: session.user,
            ip: session.address,
            mac: session['mac-address'],
            uptime: session.uptime,
            bytes_in: parseInt(session['bytes-in'] || '0'),
            bytes_out: parseInt(session['bytes-out'] || '0'),
            total_bytes: parseInt(session['bytes-in'] || '0') + parseInt(session['bytes-out'] || '0')
          };

/**
 * Verify a Paystack transaction for plan purchase from hotspot page
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
exports.verifyPaystackTransaction = async (req, res, next) => {
  try {
    const { reference } = req.query;
    
    if (!reference) {
      return res.status(400).json({
        success: false,
        message: 'Transaction reference is required'
      });
    }
    
    // Find the transaction in our database
    const transaction = await Transaction.findOne({
      where: { reference },
      include: [{ model: Plan }]
    });
    
    if (!transaction) {
      return res.status(404).json({
        success: false,
        message: 'Transaction not found'
      });
    }
    
    // Verify with Paystack
    const paystackService = new PaystackService();
    const verification = await paystackService.verifyTransaction(reference);
    
    if (verification.status !== 'success') {
      // Update transaction status to failed
      await transaction.update({
        status: 'failed',
        payment_details: JSON.stringify({
          ...JSON.parse(transaction.payment_details),
          verification_response: verification
        })
      });
      
      return res.status(400).json({
        success: false,
        message: 'Payment verification failed',
        data: verification
      });
    }
    
    // Verify amount matches plan price
    const paidAmount = verification.amount / 100; // Convert from kobo to naira
    if (paidAmount < transaction.amount) {
      await transaction.update({
        status: 'failed',
        payment_details: JSON.stringify({
          ...JSON.parse(transaction.payment_details),
          verification_response: verification,
          failure_reason: 'Amount mismatch'
        })
      });
      
      return res.status(400).json({
        success: false,
        message: `Payment amount (${paidAmount}) is less than plan price (${transaction.amount})`
      });
    }
    
    // Update transaction status to completed
    await transaction.update({
      status: 'completed',
      payment_details: JSON.stringify({
        ...JSON.parse(transaction.payment_details),
        verification_response: verification
      })
    });
    
    // Extract customer details from payment_details
    const paymentDetails = JSON.parse(transaction.payment_details);
    const { email, phone, mac_address } = paymentDetails;
    
    // Create a voucher for the purchased plan
    const voucherCode = Voucher.generateCode();
    const voucher = await Voucher.create({
      code: voucherCode,
      plan_id: transaction.plan_id,
      status: 'active',
      expiry_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days from now
    });
    
    // Update transaction with voucher ID
    await transaction.update({
      payment_details: JSON.stringify({
        ...paymentDetails,
        voucher_id: voucher.id
      })
    });
    
    // Send voucher details via email if provided
    if (email) {
      try {
        await EmailService.sendEmail({
          to: email,
          subject: 'Your WiFi Voucher',
          text: `
            Thank you for your purchase!
            
            Your WiFi voucher details:
            Code: ${voucherCode}
            Plan: ${transaction.Plan.name}
            Duration: ${transaction.Plan.duration} hours
            Speed: ${transaction.Plan.download_speed / 1024} Mbps download / ${transaction.Plan.upload_speed / 1024} Mbps upload
            
            To use your voucher, simply enter the code on the WiFi login page.
            
            Thank you for choosing our service!
          `,
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2 style="color: #4CAF50;">Your WiFi Voucher</h2>
              
              <p>Thank you for your purchase!</p>
              
              <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin: 20px 0;">
                <h3 style="margin-top: 0;">Voucher Details:</h3>
                <p><strong>Code:</strong> ${voucherCode}</p>
                <p><strong>Plan:</strong> ${transaction.Plan.name}</p>
                <p><strong>Duration:</strong> ${transaction.Plan.duration} hours</p>
                <p><strong>Speed:</strong> ${transaction.Plan.download_speed / 1024} Mbps download / ${transaction.Plan.upload_speed / 1024} Mbps upload</p>
              </div>
              
              <p>To use your voucher, simply enter the code on the WiFi login page.</p>
              
              <p>Thank you for choosing our service!</p>
            </div>
          `
        });
      } catch (emailError) {
        console.error('Failed to send voucher email:', emailError);
      }
    }
    
    // Send voucher details via SMS if phone provided
    if (phone) {
      try {
        await TwilioService.sendSMS(phone, `
          Your WiFi voucher: ${voucherCode}
          Plan: ${transaction.Plan.name}
          Duration: ${transaction.Plan.duration} hours
          Thank you for your purchase!
        `);
      } catch (smsError) {
        console.error('Failed to send voucher SMS:', smsError);
      }
    }
    
    // Redirect to success page with voucher details
    return res.redirect(`/hotspot/payment/success?voucher=${voucherCode}&plan=${transaction.Plan.name}`);
  } catch (error) {
    next(error);
  }
};

/**
 * Initialize a Paystack transaction for plan purchase from hotspot page
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
exports.initializePaystackTransaction = async (req, res, next) => {
  try {
    const { plan_id, email, phone, mac_address } = req.body;
    
    // Validate required fields
    if (!plan_id || !email || !mac_address) {
      return res.status(400).json({
        success: false,
        message: 'Plan ID, email, and MAC address are required'
      });
    }
    
    // Find the plan
    const plan = await Plan.findByPk(plan_id);
    
    if (!plan) {
      return res.status(404).json({
        success: false,
        message: 'Plan not found'
      });
    }
    
    // Generate a unique reference
    const reference = `HOTSPOT-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    
    // Initialize Paystack transaction
    const paystackService = new PaystackService();
    const paystackResponse = await paystackService.initializeTransaction({
      email,
      amount: plan.price * 100, // Convert to kobo
      reference,
      callback_url: `${req.protocol}://${req.get('host')}/hotspot/payment/verify`,
      metadata: {
        plan_name: plan.name,
        plan_id: plan.id,
        mac_address,
        phone: phone || '',
        source: 'hotspot_page'
      }
    });
    
    // Create a pending transaction in our database
    await Transaction.create({
      user_id: null, // Anonymous user
      plan_id: plan.id,
      amount: plan.price,
      payment_method: 'paystack',
      status: 'pending',
      reference,
      notes: `Hotspot page purchase for ${plan.name} plan`,
      payment_details: JSON.stringify({
        email,
        phone: phone || '',
        mac_address,
        paystack_reference: paystackResponse.data.reference
      })
    });
    
    return res.status(200).json({
      success: true,
      message: 'Transaction initialized',
      data: paystackResponse.data
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Purchase a plan directly from hotspot page
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
exports.purchasePlan = async (req, res, next) => {
  try {
    const { plan_id, email, phone, payment_method, payment_reference, mac_address } = req.body;
    
    // Find the plan
    const plan = await Plan.findByPk(plan_id);
    
    if (!plan) {
      return res.status(404).json({
        success: false,
        message: 'Plan not found'
      });
    }
    
    // Verify payment if using Paystack
    if (payment_method === 'paystack') {
      try {
        const paystackService = new PaystackService();
        const verification = await paystackService.verifyTransaction(payment_reference);
        
        if (verification.status !== 'success') {
          return res.status(400).json({
            success: false,
            message: 'Payment verification failed',
            data: verification
          });
        }
        
        // Verify amount matches plan price
        const paidAmount = verification.amount / 100; // Convert from kobo to naira
        if (paidAmount < plan.price) {
          return res.status(400).json({
            success: false,
            message: `Payment amount (${paidAmount}) is less than plan price (${plan.price})`
          });
        }
      } catch (paymentError) {
        return res.status(400).json({
          success: false,
          message: 'Payment verification failed',
          error: paymentError.message
        });
      }
    }
    
    // Create a voucher for the purchased plan
    const voucherCode = Voucher.generateCode();
    const voucher = await Voucher.create({
      code: voucherCode,
      plan_id: plan.id,
      status: 'active',
      expiry_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days from now
    });
    
    // Create a transaction record
    const transaction = await Transaction.create({
      user_id: null, // Anonymous user
      plan_id: plan.id,
      amount: plan.price,
      payment_method,
      status: 'completed',
      reference: payment_reference || `DIRECT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      notes: `Direct purchase from hotspot page for ${plan.name} plan`,
      receipt_number: `R-${Date.now().toString().substring(7)}`,
      payment_details: JSON.stringify({
        email,
        phone,
        mac_address,
        voucher_id: voucher.id
      })
    });
    
    // Send voucher details via email if provided
    if (email) {
      try {
        await EmailService.sendEmail({
          to: email,
          subject: 'Your WiFi Voucher',
          text: `
            Thank you for your purchase!
            
            Your WiFi voucher details:
            Code: ${voucherCode}
            Plan: ${plan.name}
            Duration: ${plan.duration} hours
            Speed: ${plan.download_speed / 1024} Mbps download / ${plan.upload_speed / 1024} Mbps upload
            
            To use your voucher, simply enter the code on the WiFi login page.
            
            Thank you for choosing our service!
          `,
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2 style="color: #4CAF50;">Your WiFi Voucher</h2>
              
              <p>Thank you for your purchase!</p>
              
              <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin: 20px 0;">
                <h3 style="margin-top: 0;">Voucher Details:</h3>
                <p><strong>Code:</strong> ${voucherCode}</p>
                <p><strong>Plan:</strong> ${plan.name}</p>
                <p><strong>Duration:</strong> ${plan.duration} hours</p>
                <p><strong>Speed:</strong> ${plan.download_speed / 1024} Mbps download / ${plan.upload_speed / 1024} Mbps upload</p>
              </div>
              
              <p>To use your voucher, simply enter the code on the WiFi login page.</p>
              
              <p>Thank you for choosing our service!</p>
            </div>
          `
        });
      } catch (emailError) {
        console.error('Failed to send voucher email:', emailError);
      }
    }
    
    // Send voucher details via SMS if phone provided
    if (phone) {
      try {
        await TwilioService.sendSMS(phone, `
          Your WiFi voucher: ${voucherCode}
          Plan: ${plan.name}
          Duration: ${plan.duration} hours
          Thank you for your purchase!
        `);
      } catch (smsError) {
        console.error('Failed to send voucher SMS:', smsError);
      }
    }
    
    return res.status(200).json({
      success: true,
      message: 'Plan purchased successfully',
      data: {
        voucher: {
          code: voucherCode,
          expires_at: voucher.expiry_date
        },
        plan: {
          id: plan.id,
          name: plan.name,
          duration: plan.duration,
          download_speed: plan.download_speed,
          upload_speed: plan.upload_speed
        },
        transaction: {
          id: transaction.id,
          reference: transaction.reference,
          receipt_number: transaction.receipt_number
        }
      }
    });
  } catch (error) {
    next(error);
  }
};
          
          // Get user details if available
          if (session.user) {
            const userDetails = await conn.write('/ip/hotspot/user/print', [
              '=.proplist=profile,limit-uptime,uptime',
              `?name=${session.user}`
            ]);
            
            if (userDetails && userDetails.length > 0) {
              activeSession.profile = userDetails[0].profile;
              activeSession.limit_uptime = userDetails[0]['limit-uptime'];
              activeSession.used_uptime = userDetails[0].uptime;
            }
          }
          
          break;
        }
      } catch (routerError) {
        console.error(`Error checking sessions on router ${router.name}:`, routerError);
        // Continue to next router
      }
    }
    
    return res.status(200).json({
      success: true,
      active_session: activeSession,
      message: activeSession ? 'Active session found' : 'No active session found'
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Verify a voucher code
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
exports.verifyVoucher = async (req, res, next) => {
  try {
    const { code } = req.body;
    
    // Find voucher by code
    const voucher = await Voucher.findOne({
      where: { code },
      include: [{ model: Plan, as: 'plan' }]
    });
    
    if (!voucher) {
      return res.status(404).json({
        success: false,
        message: 'Voucher not found'
      });
    }
    
    // Check if voucher is already used
    if (voucher.status === 'used') {
      return res.status(400).json({
        success: false,
        message: 'Voucher has already been used'
      });
    }
    
    // Check if voucher is expired
    if (voucher.expiry_date && new Date(voucher.expiry_date) < new Date()) {
      return res.status(400).json({
        success: false,
        message: 'Voucher has expired'
      });
    }
    
    return res.status(200).json({
      success: true,
      voucher: {
        id: voucher.id,
        code: voucher.code,
        plan: voucher.plan ? {
          id: voucher.plan.id,
          name: voucher.plan.name,
          duration: voucher.plan.duration,
          download_speed: voucher.plan.download_speed,
          upload_speed: voucher.plan.upload_speed,
          data_limit: voucher.plan.data_limit,
          price: voucher.plan.price
        } : null
      },
      message: 'Voucher is valid'
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Redeem a voucher code
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
exports.redeemVoucher = async (req, res, next) => {
  try {
    const { code, mac } = req.body;
    
    // Find voucher by code
    const voucher = await Voucher.findOne({
      where: { code },
      include: [{ model: Plan, as: 'plan' }]
    });
    
    if (!voucher) {
      return res.status(404).json({
        success: false,
        message: 'Voucher not found'
      });
    }
    
    // Check if voucher is already used
    if (voucher.status === 'used') {
      return res.status(400).json({
        success: false,
        message: 'Voucher has already been used'
      });
    }
    
    // Check if voucher is expired
    if (voucher.expiry_date && new Date(voucher.expiry_date) < new Date()) {
      return res.status(400).json({
        success: false,
        message: 'Voucher has expired'
      });
    }
    
    // Get all active routers
    const routers = await Router.findAll({ where: { is_active: true } });
    
    if (!routers || routers.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No active routers found'
      });
    }
    
    // Generate username and password
    const username = `voucher_${voucher.id.substring(0, 8)}`;
    const password = code;
    
    // Create hotspot user on all active routers
    const routerResults = [];
    
    for (const router of routers) {
      try {
        // Create hotspot user
        const userData = {
          username,
          password,
          profile: voucher.plan.mikrotik_profile,
          limit_uptime: `${voucher.plan.duration}h`,
          comment: `Voucher: ${code}, Plan: ${voucher.plan.name}`
        };
        
        const result = await MikroTikService.createHotspotUser(userData);
        routerResults.push({
          router: router.name,
          success: true,
          message: 'User created successfully'
        });
      } catch (routerError) {
        console.error(`Error creating user on router ${router.name}:`, routerError);
        routerResults.push({
          router: router.name,
          success: false,
          message: routerError.message
        });
      }
    }
    
    // Mark voucher as used
    await voucher.update({
      status: 'used',
      redeemed_at: new Date(),
      redeemed_by: mac
    });
    
    // Create session record
    await Session.create({
      user_id: null, // Anonymous user
      plan_id: voucher.plan.id,
      voucher_id: voucher.id,
      mac_address: mac,
      username,
      start_time: new Date(),
      end_time: new Date(Date.now() + voucher.plan.duration * 60 * 60 * 1000), // Convert hours to milliseconds
      status: 'active'
    });
    
    return res.status(200).json({
      success: true,
      username,
      password,
      plan: {
        id: voucher.plan.id,
        name: voucher.plan.name,
        duration: voucher.plan.duration,
        download_speed: voucher.plan.download_speed,
        upload_speed: voucher.plan.upload_speed
      },
      router_results: routerResults,
      message: 'Voucher redeemed successfully'
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Activate a free trial
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
exports.activateFreeTrial = async (req, res, next) => {
  try {
    const { mac, duration = 30, bandwidth = 1 } = req.body;
    
    // Check if this MAC address has already used a free trial
    const existingSession = await Session.findOne({
      where: {
        mac_address: mac,
        is_trial: true
      }
    });
    
    if (existingSession) {
      return res.status(400).json({
        success: false,
        message: 'This device has already used a free trial'
      });
    }
    
    // Get all active routers
    const routers = await Router.findAll({ where: { is_active: true } });
    
    if (!routers || routers.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No active routers found'
      });
    }
    
    // Generate username and password
    const username = `trial_${mac.replace(/:/g, '')}`;
    const password = `trial_${Math.random().toString(36).substring(2, 8)}`;
    
    // Create trial profile if it doesn't exist
    const profileName = 'free_trial';
    const downloadSpeed = `${bandwidth}M/${bandwidth}M`;
    const uploadSpeed = `${bandwidth}M/${bandwidth}M`;
    
    // Create hotspot user on all active routers
    const routerResults = [];
    
    for (const router of routers) {
      try {
        const conn = await MikroTikService.connect({
          host: router.ip_address,
          port: router.port,
          username: router.username,
          password: router.decryptPassword()
        });
        
        // Check if profile exists
        const profiles = await conn.write('/ip/hotspot/user/profile/print', [
          '=.proplist=name',
          `?name=${profileName}`
        ]);
        
        // Create profile if it doesn't exist
        if (profiles.length === 0) {
          await conn.write('/ip/hotspot/user/profile/add', [
            `=name=${profileName}`,
            `=rate-limit=${uploadSpeed}/${downloadSpeed}`,
            `=shared-users=1`,
            `=session-timeout=${duration}m`,
            `=keepalive-timeout=2m`,
            `=status-autorefresh=1m`
          ]);
        }
        
        // Create hotspot user
        const userData = {
          username,
          password,
          profile: profileName,
          limit_uptime: `${duration}m`,
          comment: `Free Trial, MAC: ${mac}`
        };
        
        await conn.write('/ip/hotspot/user/add', [
          `=name=${userData.username}`,
          `=password=${userData.password}`,
          `=profile=${userData.profile}`,
          `=limit-uptime=${userData.limit_uptime}`,
          `=comment=${userData.comment}`
        ]);
        
        conn.close();
        
        routerResults.push({
          router: router.name,
          success: true,
          message: 'Trial user created successfully'
        });
      } catch (routerError) {
        console.error(`Error creating trial user on router ${router.name}:`, routerError);
        routerResults.push({
          router: router.name,
          success: false,
          message: routerError.message
        });
      }
    }
    
    // Create session record
    await Session.create({
      user_id: null, // Anonymous user
      plan_id: null, // No plan for free trial
      voucher_id: null, // No voucher for free trial
      mac_address: mac,
      username,
      start_time: new Date(),
      end_time: new Date(Date.now() + duration * 60 * 1000), // Convert minutes to milliseconds
      status: 'active',
      is_trial: true
    });
    
    return res.status(200).json({
      success: true,
      username,
      password,
      duration,
      bandwidth,
      router_results: routerResults,
      message: 'Free trial activated successfully'
    });
  } catch (error) {
    next(error);
  }
};