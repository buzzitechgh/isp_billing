const express = require('express');
const router = express.Router();
const reportController = require('../controllers/report.controller');
const { authenticate } = require('../middleware/auth.middleware');
const { authorize } = require('../middleware/role.middleware');
const { validateQuery } = require('../middleware/validation.middleware');
const { check, query } = require('express-validator');

/**
 * @route   GET /api/reports/revenue
 * @desc    Generate revenue report
 * @access  Private (Admin, Manager)
 */
router.get(
  '/revenue',
  authenticate,
  authorize(['admin', 'manager']),
  [
    query('start_date').optional().isDate().withMessage('Start date must be a valid date'),
    query('end_date').optional().isDate().withMessage('End date must be a valid date'),
    query('payment_method').optional().isString().withMessage('Payment method must be a string'),
    query('format').optional().isIn(['json', 'pdf', 'excel']).withMessage('Format must be json, pdf, or excel')
  ],
  validateQuery,
  reportController.generateRevenueReport
);

/**
 * @route   GET /api/reports/users
 * @desc    Generate user report
 * @access  Private (Admin, Manager)
 */
router.get(
  '/users',
  authenticate,
  authorize(['admin', 'manager']),
  [
    query('start_date').optional().isDate().withMessage('Start date must be a valid date'),
    query('end_date').optional().isDate().withMessage('End date must be a valid date'),
    query('status').optional().isIn(['active', 'inactive']).withMessage('Status must be active or inactive'),
    query('format').optional().isIn(['json', 'pdf', 'excel']).withMessage('Format must be json, pdf, or excel')
  ],
  validateQuery,
  reportController.generateUserReport
);

/**
 * @route   GET /api/reports/sessions
 * @desc    Generate session report
 * @access  Private (Admin, Manager)
 */
router.get(
  '/sessions',
  authenticate,
  authorize(['admin', 'manager']),
  [
    query('start_date').optional().isDate().withMessage('Start date must be a valid date'),
    query('end_date').optional().isDate().withMessage('End date must be a valid date'),
    query('router_id').optional().isInt().withMessage('Router ID must be an integer'),
    query('status').optional().isIn(['active', 'ended']).withMessage('Status must be active or ended'),
    query('format').optional().isIn(['json', 'pdf', 'excel']).withMessage('Format must be json, pdf, or excel')
  ],
  validateQuery,
  reportController.generateSessionReport
);

/**
 * @route   GET /api/reports/vouchers
 * @desc    Generate voucher report
 * @access  Private (Admin, Manager)
 */
router.get(
  '/vouchers',
  authenticate,
  authorize(['admin', 'manager']),
  [
    query('start_date').optional().isDate().withMessage('Start date must be a valid date'),
    query('end_date').optional().isDate().withMessage('End date must be a valid date'),
    query('status').optional().isIn(['used', 'unused', 'expired']).withMessage('Status must be used, unused, or expired'),
    query('batch_name').optional().isString().withMessage('Batch name must be a string'),
    query('format').optional().isIn(['json', 'pdf', 'excel']).withMessage('Format must be json, pdf, or excel')
  ],
  validateQuery,
  reportController.generateVoucherReport
);

module.exports = router;