const express = require('express');
const router = express.Router();

// Import route modules
const authRoutes = require('./auth.routes');
const userRoutes = require('./user.routes');
const planRoutes = require('./plan.routes');
const voucherRoutes = require('./voucher.routes');
const transactionRoutes = require('./transaction.routes');
const sessionRoutes = require('./session.routes');
const routerRoutes = require('./router.routes');
const notificationRoutes = require('./notification.routes');
const dashboardRoutes = require('./dashboard.routes');
const webhookRoutes = require('./webhook.routes');
const hotspotRoutes = require('./hotspot.routes');

// API health check
router.get('/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'API is running',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV
  });
});

// Mount route modules
router.use('/auth', authRoutes);
router.use('/users', userRoutes);
router.use('/plans', planRoutes);
router.use('/vouchers', voucherRoutes);
router.use('/transactions', transactionRoutes);
router.use('/sessions', sessionRoutes);
router.use('/routers', routerRoutes);
router.use('/notifications', notificationRoutes);
router.use('/dashboard', dashboardRoutes);
router.use('/webhooks', webhookRoutes);
router.use('/hotspot', hotspotRoutes);

// 404 handler for API routes
router.use('*', (req, res) => {
  res.status(404).json({
    success: false,
    message: 'API endpoint not found'
  });
});

module.exports = router;