const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const userController = require('../controllers/user.controller');
const { authenticate, authorize } = require('../middleware/auth');

/**
 * @route GET /api/users
 * @desc Get all users (with pagination)
 * @access Private (Admin, Manager)
 */
router.get(
  '/',
  authenticate,
  authorize(['admin', 'manager']),
  userController.getAllUsers
);

/**
 * @route GET /api/users/:id
 * @desc Get user by ID
 * @access Private (Admin, Manager, Own User)
 */
router.get(
  '/:id',
  authenticate,
  userController.getUserById
);

/**
 * @route POST /api/users
 * @desc Create a new user (by admin)
 * @access Private (Admin)
 */
router.post(
  '/',
  authenticate,
  authorize(['admin']),
  [
    body('username')
      .isLength({ min: 3, max: 30 })
      .withMessage('Username must be between 3 and 30 characters')
      .isAlphanumeric()
      .withMessage('Username must contain only letters and numbers'),
    body('email')
      .isEmail()
      .withMessage('Please provide a valid email address'),
    body('password')
      .isLength({ min: 6 })
      .withMessage('Password must be at least 6 characters long'),
    body('full_name')
      .notEmpty()
      .withMessage('Full name is required'),
    body('role_id')
      .isInt()
      .withMessage('Role ID must be an integer'),
    body('phone')
      .optional()
      .isMobilePhone()
      .withMessage('Please provide a valid phone number')
  ],
  userController.createUser
);

/**
 * @route PUT /api/users/:id
 * @desc Update user
 * @access Private (Admin, Own User)
 */
router.put(
  '/:id',
  authenticate,
  [
    body('full_name')
      .optional()
      .notEmpty()
      .withMessage('Full name cannot be empty'),
    body('email')
      .optional()
      .isEmail()
      .withMessage('Please provide a valid email address'),
    body('phone')
      .optional()
      .isMobilePhone()
      .withMessage('Please provide a valid phone number'),
    body('address')
      .optional()
  ],
  userController.updateUser
);

/**
 * @route PATCH /api/users/:id/status
 * @desc Update user status (activate/deactivate)
 * @access Private (Admin)
 */
router.patch(
  '/:id/status',
  authenticate,
  authorize(['admin']),
  [
    body('is_active')
      .isBoolean()
      .withMessage('is_active must be a boolean value')
  ],
  userController.updateUserStatus
);

/**
 * @route DELETE /api/users/:id
 * @desc Delete user
 * @access Private (Admin)
 */
router.delete(
  '/:id',
  authenticate,
  authorize(['admin']),
  userController.deleteUser
);

/**
 * @route GET /api/users/:id/transactions
 * @desc Get user transactions
 * @access Private (Admin, Own User)
 */
router.get(
  '/:id/transactions',
  authenticate,
  userController.getUserTransactions
);

/**
 * @route GET /api/users/:id/sessions
 * @desc Get user sessions
 * @access Private (Admin, Own User)
 */
router.get(
  '/:id/sessions',
  authenticate,
  userController.getUserSessions
);

/**
 * @route GET /api/users/:id/notifications
 * @desc Get user notifications
 * @access Private (Own User)
 */
router.get(
  '/:id/notifications',
  authenticate,
  userController.getUserNotifications
);

/**
 * @route PATCH /api/users/:id/notifications/:notificationId/read
 * @desc Mark notification as read
 * @access Private (Own User)
 */
router.patch(
  '/:id/notifications/:notificationId/read',
  authenticate,
  userController.markNotificationAsRead
);

/**
 * @route GET /api/users/:id/active-plan
 * @desc Get user's active plan
 * @access Private (Admin, Own User)
 */
router.get(
  '/:id/active-plan',
  authenticate,
  userController.getUserActivePlan
);

module.exports = router;