/**
 * Hotspot Routes
 * API endpoints for MikroTik hotspot integration
 */

const express = require('express');
const router = express.Router();
const path = require('path');
const { body } = require('express-validator');
const hotspotController = require('../controllers/hotspot.controller');
const { validateRequest } = require('../middleware/errorHandler');

/**
 * @route POST /api/hotspot/sessions/check
 * @desc Check for active sessions by MAC address
 * @access Public
 */
router.post('/sessions/check',
    validateRequest(hotspotSchema.checkSession),
    hotspotController.checkSession
);

/**
 * @route POST /api/hotspot/vouchers/verify
 * @desc Verify a voucher code
 * @access Public
 */
router.post('/vouchers/verify',
    validateRequest(hotspotSchema.verifyVoucher),
    hotspotController.verifyVoucher
);

/**
 * @route POST /api/hotspot/vouchers/redeem
 * @desc Redeem a voucher code
 * @access Public
 */
router.post('/vouchers/redeem',
    validateRequest(hotspotSchema.redeemVoucher),
    hotspotController.redeemVoucher
);

/**
 * @route POST /api/hotspot/free-trial
 * @desc Activate a free trial
 * @access Public
 */
router.post('/free-trial',
    validateRequest(hotspotSchema.activateFreeTrial),
    hotspotController.activateFreeTrial
);

/**
 * @route POST /api/hotspot/plans/purchase
 * @desc Purchase a plan directly from hotspot page
 * @access Public
 */
router.post('/plans/purchase',
    [
        body('plan_id').notEmpty().withMessage('Plan ID is required'),
        body('mac_address').notEmpty().withMessage('MAC address is required'),
        body('payment_method').notEmpty().withMessage('Payment method is required'),
        body('email').optional().isEmail().withMessage('Valid email is required'),
        body('phone').optional().isMobilePhone().withMessage('Valid phone number is required'),
        body('payment_reference').optional().withMessage('Payment reference')
    ],
    validateRequest,
    hotspotController.purchasePlan
);

/**
 * @route POST /api/hotspot/payments/initialize
 * @desc Initialize a Paystack transaction for plan purchase
 * @access Public
 */
router.post('/payments/initialize',
    [
        body('plan_id').notEmpty().withMessage('Plan ID is required'),
        body('email').notEmpty().isEmail().withMessage('Valid email is required'),
        body('mac_address').notEmpty().withMessage('MAC address is required'),
        body('phone').optional().isMobilePhone().withMessage('Valid phone number is required')
    ],
    validateRequest,
    hotspotController.initializePaystackTransaction
);

/**
 * @route GET /api/hotspot/payments/verify
 * @desc Verify a Paystack transaction
 * @access Public
 */
router.get('/payments/verify',
    hotspotController.verifyPaystackTransaction
);

/**
 * @route GET /api/hotspot/payment/success
 * @desc Serve payment success page
 * @access Public
 */
router.get('/payment/success', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/hotspot/payment-success.html'));
});

/**
 * @route GET /api/hotspot/test-payment
 * @desc Serve test payment page for development
 * @access Public
 */
router.get('/test-payment', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/hotspot/test-payment.html'));
});

module.exports = router;