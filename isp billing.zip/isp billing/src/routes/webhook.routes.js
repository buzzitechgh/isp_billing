const express = require('express');
const router = express.Router();
const webhookController = require('../controllers/webhook.controller');
const { validatePaystackSignature } = require('../middleware/webhookValidation');

/**
 * @route POST /api/webhooks/paystack
 * @desc Handle Paystack webhook events
 * @access Public (secured by signature validation)
 */
router.post(
  '/paystack',
  validatePaystackSignature,
  webhookController.handlePaystackWebhook
);

/**
 * @route POST /api/webhooks/mikrotik
 * @desc Handle MikroTik webhook events (session start/end)
 * @access Public (secured by API key)
 */
router.post(
  '/mikrotik',
  webhookController.handleMikroTikWebhook
);

/**
 * @route POST /api/webhooks/twilio
 * @desc Handle Twilio webhook events (delivery status)
 * @access Public (secured by Twilio signature validation)
 */
router.post(
  '/twilio',
  webhookController.handleTwilioWebhook
);

module.exports = router;