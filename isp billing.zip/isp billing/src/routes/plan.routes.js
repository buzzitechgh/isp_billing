const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const planController = require('../controllers/plan.controller');
const { authenticate, authorize } = require('../middleware/auth');

/**
 * @route GET /api/plans
 * @desc Get all plans (with pagination)
 * @access Public
 */
router.get('/', planController.getAllPlans);

/**
 * @route GET /api/plans/public
 * @desc Get all public plans for hotspot page
 * @access Public
 */
router.get('/public', planController.getPublicPlans);

/**
 * @route GET /api/plans/:id
 * @desc Get plan by ID
 * @access Public
 */
router.get('/:id', planController.getPlanById);

/**
 * @route POST /api/plans
 * @desc Create a new plan
 * @access Private (Admin)
 */
router.post(
  '/',
  authenticate,
  authorize(['admin']),
  [
    body('name')
      .notEmpty()
      .withMessage('Plan name is required'),
    body('type')
      .isIn(['hourly', 'daily', 'weekly', 'monthly', 'yearly'])
      .withMessage('Invalid plan type'),
    body('price')
      .isFloat({ min: 0 })
      .withMessage('Price must be a positive number'),
    body('duration')
      .isInt({ min: 1 })
      .withMessage('Duration must be a positive integer'),
    body('download_speed')
      .isInt({ min: 1 })
      .withMessage('Download speed must be a positive integer'),
    body('upload_speed')
      .isInt({ min: 1 })
      .withMessage('Upload speed must be a positive integer'),
    body('simultaneous_use')
      .optional()
      .isInt({ min: 1 })
      .withMessage('Simultaneous use must be a positive integer'),
    body('data_limit')
      .optional()
      .isInt({ min: 0 })
      .withMessage('Data limit must be a non-negative integer'),
    body('shared_users')
      .optional()
      .isInt({ min: 1 })
      .withMessage('Shared users must be a positive integer'),
    body('priority')
      .optional()
      .isInt({ min: 1, max: 8 })
      .withMessage('Priority must be between 1 and 8'),
    body('is_public')
      .optional()
      .isBoolean()
      .withMessage('is_public must be a boolean value')
  ],
  planController.createPlan
);

/**
 * @route PUT /api/plans/:id
 * @desc Update plan
 * @access Private (Admin)
 */
router.put(
  '/:id',
  authenticate,
  authorize(['admin']),
  [
    body('name')
      .optional()
      .notEmpty()
      .withMessage('Plan name cannot be empty'),
    body('type')
      .optional()
      .isIn(['hourly', 'daily', 'weekly', 'monthly', 'yearly'])
      .withMessage('Invalid plan type'),
    body('price')
      .optional()
      .isFloat({ min: 0 })
      .withMessage('Price must be a positive number'),
    body('duration')
      .optional()
      .isInt({ min: 1 })
      .withMessage('Duration must be a positive integer'),
    body('download_speed')
      .optional()
      .isInt({ min: 1 })
      .withMessage('Download speed must be a positive integer'),
    body('upload_speed')
      .optional()
      .isInt({ min: 1 })
      .withMessage('Upload speed must be a positive integer'),
    body('simultaneous_use')
      .optional()
      .isInt({ min: 1 })
      .withMessage('Simultaneous use must be a positive integer'),
    body('data_limit')
      .optional()
      .isInt({ min: 0 })
      .withMessage('Data limit must be a non-negative integer'),
    body('shared_users')
      .optional()
      .isInt({ min: 1 })
      .withMessage('Shared users must be a positive integer'),
    body('priority')
      .optional()
      .isInt({ min: 1, max: 8 })
      .withMessage('Priority must be between 1 and 8'),
    body('is_public')
      .optional()
      .isBoolean()
      .withMessage('is_public must be a boolean value'),
    body('is_active')
      .optional()
      .isBoolean()
      .withMessage('is_active must be a boolean value')
  ],
  planController.updatePlan
);

/**
 * @route PATCH /api/plans/:id/status
 * @desc Update plan status (activate/deactivate)
 * @access Private (Admin)
 */
router.patch(
  '/:id/status',
  authenticate,
  authorize(['admin']),
  [
    body('is_active')
      .isBoolean()
      .withMessage('is_active must be a boolean value')
  ],
  planController.updatePlanStatus
);

/**
 * @route DELETE /api/plans/:id
 * @desc Delete plan
 * @access Private (Admin)
 */
router.delete(
  '/:id',
  authenticate,
  authorize(['admin']),
  planController.deletePlan
);

/**
 * @route POST /api/plans/:id/purchase
 * @desc Purchase a plan
 * @access Private
 */
router.post(
  '/:id/purchase',
  authenticate,
  [
    body('payment_method')
      .isIn(['paystack', 'cash', 'bank_transfer', 'voucher'])
      .withMessage('Invalid payment method')
  ],
  planController.purchasePlan
);

/**
 * @route GET /api/plans/:id/users
 * @desc Get users with this plan
 * @access Private (Admin)
 */
router.get(
  '/:id/users',
  authenticate,
  authorize(['admin']),
  planController.getPlanUsers
);

/**
 * @route POST /api/plans/:id/sync-mikrotik
 * @desc Sync plan with MikroTik router
 * @access Private (Admin)
 */
router.post(
  '/:id/sync-mikrotik',
  authenticate,
  authorize(['admin']),
  planController.syncPlanWithMikroTik
);

module.exports = router;