const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const routerController = require('../controllers/router.controller');
const { authenticate, authorize } = require('../middleware/auth');

/**
 * @route GET /api/routers
 * @desc Get all routers
 * @access Private (Admin)
 */
router.get(
  '/',
  authenticate,
  authorize(['admin']),
  routerController.getAllRouters
);

/**
 * @route GET /api/routers/:id
 * @desc Get router by ID
 * @access Private (Admin)
 */
router.get(
  '/:id',
  authenticate,
  authorize(['admin']),
  routerController.getRouterById
);

/**
 * @route POST /api/routers
 * @desc Create a new router
 * @access Private (Admin)
 */
router.post(
  '/',
  authenticate,
  authorize(['admin']),
  [
    body('name')
      .notEmpty()
      .withMessage('Router name is required'),
    body('ip_address')
      .isIP()
      .withMessage('Please provide a valid IP address'),
    body('port')
      .isInt({ min: 1, max: 65535 })
      .withMessage('Port must be between 1 and 65535'),
    body('username')
      .notEmpty()
      .withMessage('Username is required'),
    body('password')
      .notEmpty()
      .withMessage('Password is required'),
    body('description')
      .optional()
  ],
  routerController.createRouter
);

/**
 * @route PUT /api/routers/:id
 * @desc Update router
 * @access Private (Admin)
 */
router.put(
  '/:id',
  authenticate,
  authorize(['admin']),
  [
    body('name')
      .optional()
      .notEmpty()
      .withMessage('Router name cannot be empty'),
    body('ip_address')
      .optional()
      .isIP()
      .withMessage('Please provide a valid IP address'),
    body('port')
      .optional()
      .isInt({ min: 1, max: 65535 })
      .withMessage('Port must be between 1 and 65535'),
    body('username')
      .optional()
      .notEmpty()
      .withMessage('Username cannot be empty'),
    body('password')
      .optional()
      .notEmpty()
      .withMessage('Password cannot be empty'),
    body('description')
      .optional()
  ],
  routerController.updateRouter
);

/**
 * @route DELETE /api/routers/:id
 * @desc Delete router
 * @access Private (Admin)
 */
router.delete(
  '/:id',
  authenticate,
  authorize(['admin']),
  routerController.deleteRouter
);

/**
 * @route POST /api/routers/:id/test-connection
 * @desc Test router connection
 * @access Private (Admin)
 */
router.post(
  '/:id/test-connection',
  authenticate,
  authorize(['admin']),
  routerController.testRouterConnection
);

/**
 * @route GET /api/routers/:id/status
 * @desc Get router status
 * @access Private (Admin)
 */
router.get(
  '/:id/status',
  authenticate,
  authorize(['admin']),
  routerController.getRouterStatus
);

/**
 * @route GET /api/routers/:id/interfaces
 * @desc Get router interfaces
 * @access Private (Admin)
 */
router.get(
  '/:id/interfaces',
  authenticate,
  authorize(['admin']),
  routerController.getRouterInterfaces
);

/**
 * @route GET /api/routers/:id/hotspot-users
 * @desc Get router hotspot users
 * @access Private (Admin)
 */
router.get(
  '/:id/hotspot-users',
  authenticate,
  authorize(['admin']),
  routerController.getHotspotUsers
);

/**
 * @route GET /api/routers/:id/hotspot-profiles
 * @desc Get router hotspot profiles
 * @access Private (Admin)
 */
router.get(
  '/:id/hotspot-profiles',
  authenticate,
  authorize(['admin']),
  routerController.getHotspotProfiles
);

/**
 * @route POST /api/routers/:id/sync-plans
 * @desc Sync all plans with router
 * @access Private (Admin)
 */
router.post(
  '/:id/sync-plans',
  authenticate,
  authorize(['admin']),
  routerController.syncPlansWithRouter
);

/**
 * @route POST /api/routers/:id/generate-login-page
 * @desc Generate custom login page for hotspot
 * @access Private (Admin)
 */
router.post(
  '/:id/generate-login-page',
  authenticate,
  authorize(['admin']),
  [
    body('template')
      .optional()
      .isIn(['default', 'modern', 'simple'])
      .withMessage('Invalid template'),
    body('logo_url')
      .optional()
      .isURL()
      .withMessage('Logo URL must be a valid URL'),
    body('primary_color')
      .optional()
      .matches(/^#[0-9A-F]{6}$/i)
      .withMessage('Primary color must be a valid hex color'),
    body('company_name')
      .optional()
  ],
  routerController.generateLoginPage
);

module.exports = router;