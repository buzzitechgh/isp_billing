const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const transactionController = require('../controllers/transaction.controller');
const { authenticate, authorize } = require('../middleware/auth');

/**
 * @route GET /api/transactions
 * @desc Get all transactions (with pagination)
 * @access Private (Admin, Manager)
 */
router.get(
  '/',
  authenticate,
  authorize(['admin', 'manager']),
  transactionController.getAllTransactions
);

/**
 * @route GET /api/transactions/:id
 * @desc Get transaction by ID
 * @access Private (Admin, Manager, Own User)
 */
router.get(
  '/:id',
  authenticate,
  transactionController.getTransactionById
);

/**
 * @route POST /api/transactions
 * @desc Create a new transaction (manual entry by admin)
 * @access Private (Admin)
 */
router.post(
  '/',
  authenticate,
  authorize(['admin']),
  [
    body('user_id')
      .isInt()
      .withMessage('User ID must be an integer'),
    body('plan_id')
      .isInt()
      .withMessage('Plan ID must be an integer'),
    body('amount')
      .isFloat({ min: 0 })
      .withMessage('Amount must be a positive number'),
    body('payment_method')
      .isIn(['paystack', 'cash', 'bank_transfer', 'voucher'])
      .withMessage('Invalid payment method'),
    body('status')
      .isIn(['pending', 'completed', 'failed', 'refunded'])
      .withMessage('Invalid status'),
    body('reference')
      .optional()
      .isString()
      .withMessage('Reference must be a string'),
    body('notes')
      .optional()
      .isString()
      .withMessage('Notes must be a string')
  ],
  transactionController.createTransaction
);

/**
 * @route POST /api/transactions/initialize
 * @desc Initialize a Paystack transaction
 * @access Private
 */
router.post(
  '/initialize',
  authenticate,
  [
    body('plan_id')
      .isInt()
      .withMessage('Plan ID must be an integer'),
    body('email')
      .isEmail()
      .withMessage('Please provide a valid email address'),
    body('callback_url')
      .optional()
      .isURL()
      .withMessage('Callback URL must be a valid URL')
  ],
  transactionController.initializeTransaction
);

/**
 * @route GET /api/transactions/verify/:reference
 * @desc Verify a Paystack transaction
 * @access Private
 */
router.get(
  '/verify/:reference',
  authenticate,
  transactionController.verifyTransaction
);

/**
 * @route PATCH /api/transactions/:id/status
 * @desc Update transaction status
 * @access Private (Admin)
 */
router.patch(
  '/:id/status',
  authenticate,
  authorize(['admin']),
  [
    body('status')
      .isIn(['pending', 'completed', 'failed', 'refunded'])
      .withMessage('Invalid status'),
    body('notes')
      .optional()
      .isString()
      .withMessage('Notes must be a string')
  ],
  transactionController.updateTransactionStatus
);

/**
 * @route GET /api/transactions/:id/receipt
 * @desc Generate transaction receipt
 * @access Private (Admin, Own User)
 */
router.get(
  '/:id/receipt',
  authenticate,
  transactionController.generateReceipt
);

/**
 * @route GET /api/transactions/stats/daily
 * @desc Get daily transaction statistics
 * @access Private (Admin)
 */
router.get(
  '/stats/daily',
  authenticate,
  authorize(['admin']),
  transactionController.getDailyStats
);

/**
 * @route GET /api/transactions/stats/monthly
 * @desc Get monthly transaction statistics
 * @access Private (Admin)
 */
router.get(
  '/stats/monthly',
  authenticate,
  authorize(['admin']),
  transactionController.getMonthlyStats
);

/**
 * @route GET /api/transactions/stats/payment-methods
 * @desc Get transaction statistics by payment method
 * @access Private (Admin)
 */
router.get(
  '/stats/payment-methods',
  authenticate,
  authorize(['admin']),
  transactionController.getPaymentMethodStats
);

module.exports = router;