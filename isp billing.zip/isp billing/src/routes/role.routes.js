const express = require('express');
const router = express.Router();
const { body, param } = require('express-validator');
const roleController = require('../controllers/role.controller');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/authorize');

/**
 * @route GET /api/roles
 * @desc Get all roles
 * @access Private (Admin only)
 */
router.get(
  '/',
  authenticate,
  authorize([1]), // Admin role only
  roleController.getAllRoles
);

/**
 * @route GET /api/roles/permissions
 * @desc Get all permissions
 * @access Private (Admin only)
 */
router.get(
  '/permissions',
  authenticate,
  authorize([1]), // Admin role only
  roleController.getAllPermissions
);

/**
 * @route GET /api/roles/:id
 * @desc Get role by ID
 * @access Private (Admin only)
 */
router.get(
  '/:id',
  authenticate,
  authorize([1]), // Admin role only
  param('id').isInt().withMessage('Role ID must be an integer'),
  roleController.getRoleById
);

/**
 * @route GET /api/roles/:id/permissions
 * @desc Get role permissions
 * @access Private (Admin only)
 */
router.get(
  '/:id/permissions',
  authenticate,
  authorize([1]), // Admin role only
  param('id').isInt().withMessage('Role ID must be an integer'),
  roleController.getRolePermissions
);

/**
 * @route POST /api/roles
 * @desc Create a new role
 * @access Private (Admin only)
 */
router.post(
  '/',
  authenticate,
  authorize([1]), // Admin role only
  [
    body('name').notEmpty().withMessage('Name is required')
      .isLength({ min: 3, max: 50 }).withMessage('Name must be between 3 and 50 characters'),
    body('description').optional().isString().withMessage('Description must be a string'),
    body('permissions').optional().isArray().withMessage('Permissions must be an array'),
    body('permissions.*').optional().isInt().withMessage('Each permission ID must be an integer')
  ],
  roleController.createRole
);

/**
 * @route PUT /api/roles/:id
 * @desc Update a role
 * @access Private (Admin only)
 */
router.put(
  '/:id',
  authenticate,
  authorize([1]), // Admin role only
  [
    param('id').isInt().withMessage('Role ID must be an integer'),
    body('name').optional().isLength({ min: 3, max: 50 }).withMessage('Name must be between 3 and 50 characters'),
    body('description').optional().isString().withMessage('Description must be a string'),
    body('permissions').optional().isArray().withMessage('Permissions must be an array'),
    body('permissions.*').optional().isInt().withMessage('Each permission ID must be an integer')
  ],
  roleController.updateRole
);

/**
 * @route DELETE /api/roles/:id
 * @desc Delete a role
 * @access Private (Admin only)
 */
router.delete(
  '/:id',
  authenticate,
  authorize([1]), // Admin role only
  param('id').isInt().withMessage('Role ID must be an integer'),
  roleController.deleteRole
);

/**
 * @route POST /api/roles/initialize
 * @desc Initialize default roles and permissions
 * @access Private (Admin only)
 */
router.post(
  '/initialize',
  authenticate,
  authorize([1]), // Admin role only
  roleController.initializeRolesAndPermissions
);

module.exports = router;