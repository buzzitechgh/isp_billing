const express = require('express');
const router = express.Router();
const dashboardController = require('../controllers/dashboard.controller');
const { authenticate, authorize } = require('../middleware/auth');

/**
 * @route GET /api/dashboard/stats
 * @desc Get dashboard statistics
 * @access Private (Admin, Manager)
 */
router.get(
  '/stats',
  authenticate,
  authorize(['admin', 'manager']),
  dashboardController.getDashboardStats
);

/**
 * @route GET /api/dashboard/revenue
 * @desc Get revenue statistics
 * @access Private (Admin)
 */
router.get(
  '/revenue',
  authenticate,
  authorize(['admin']),
  dashboardController.getRevenueStats
);

/**
 * @route GET /api/dashboard/users
 * @desc Get user statistics
 * @access Private (Admin, Manager)
 */
router.get(
  '/users',
  authenticate,
  authorize(['admin', 'manager']),
  dashboardController.getUserStats
);

/**
 * @route GET /api/dashboard/plans
 * @desc Get plan statistics
 * @access Private (Admin, Manager)
 */
router.get(
  '/plans',
  authenticate,
  authorize(['admin', 'manager']),
  dashboardController.getPlanStats
);

/**
 * @route GET /api/dashboard/sessions
 * @desc Get session statistics
 * @access Private (Admin, Manager)
 */
router.get(
  '/sessions',
  authenticate,
  authorize(['admin', 'manager']),
  dashboardController.getSessionStats
);

/**
 * @route GET /api/dashboard/data-usage
 * @desc Get data usage statistics
 * @access Private (Admin, Manager)
 */
router.get(
  '/data-usage',
  authenticate,
  authorize(['admin', 'manager']),
  dashboardController.getDataUsageStats
);

/**
 * @route GET /api/dashboard/routers
 * @desc Get router statistics
 * @access Private (Admin)
 */
router.get(
  '/routers',
  authenticate,
  authorize(['admin']),
  dashboardController.getRouterStats
);

/**
 * @route GET /api/dashboard/transactions
 * @desc Get transaction statistics
 * @access Private (Admin)
 */
router.get(
  '/transactions',
  authenticate,
  authorize(['admin']),
  dashboardController.getTransactionStats
);

/**
 * @route GET /api/dashboard/vouchers
 * @desc Get voucher statistics
 * @access Private (Admin, Manager)
 */
router.get(
  '/vouchers',
  authenticate,
  authorize(['admin', 'manager']),
  dashboardController.getVoucherStats
);

/**
 * @route GET /api/dashboard/user-activity
 * @desc Get user activity timeline
 * @access Private (Admin)
 */
router.get(
  '/user-activity',
  authenticate,
  authorize(['admin']),
  dashboardController.getUserActivityTimeline
);

/**
 * @route GET /api/dashboard/recent-transactions
 * @desc Get recent transactions
 * @access Private (Admin, Manager)
 */
router.get(
  '/recent-transactions',
  authenticate,
  authorize(['admin', 'manager']),
  dashboardController.getRecentTransactions
);

/**
 * @route GET /api/dashboard/recent-sessions
 * @desc Get recent sessions
 * @access Private (Admin, Manager)
 */
router.get(
  '/recent-sessions',
  authenticate,
  authorize(['admin', 'manager']),
  dashboardController.getRecentSessions
);

/**
 * @route GET /api/dashboard/active-users
 * @desc Get active users
 * @access Private (Admin, Manager)
 */
router.get(
  '/active-users',
  authenticate,
  authorize(['admin', 'manager']),
  dashboardController.getActiveUsers
);

module.exports = router;