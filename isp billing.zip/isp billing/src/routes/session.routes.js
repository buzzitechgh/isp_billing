const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const sessionController = require('../controllers/session.controller');
const { authenticate, authorize } = require('../middleware/auth');

/**
 * @route GET /api/sessions
 * @desc Get all sessions (with pagination)
 * @access Private (Admin, Manager)
 */
router.get(
  '/',
  authenticate,
  authorize(['admin', 'manager']),
  sessionController.getAllSessions
);

/**
 * @route GET /api/sessions/active
 * @desc Get all active sessions
 * @access Private (Admin, Manager)
 */
router.get(
  '/active',
  authenticate,
  authorize(['admin', 'manager']),
  sessionController.getActiveSessions
);

/**
 * @route GET /api/sessions/:id
 * @desc Get session by ID
 * @access Private (Admin, Manager, Own User)
 */
router.get(
  '/:id',
  authenticate,
  sessionController.getSessionById
);

/**
 * @route POST /api/sessions/sync
 * @desc Sync sessions from MikroTik router
 * @access Private (Admin)
 */
router.post(
  '/sync',
  authenticate,
  authorize(['admin']),
  [
    body('router_id')
      .isInt()
      .withMessage('Router ID must be an integer')
  ],
  sessionController.syncSessionsFromMikroTik
);

/**
 * @route POST /api/sessions/disconnect/:id
 * @desc Disconnect a session
 * @access Private (Admin, Own User)
 */
router.post(
  '/disconnect/:id',
  authenticate,
  sessionController.disconnectSession
);

/**
 * @route POST /api/sessions/disconnect-all
 * @desc Disconnect all sessions for a user
 * @access Private (Admin, Own User)
 */
router.post(
  '/disconnect-all',
  authenticate,
  [
    body('user_id')
      .isInt()
      .withMessage('User ID must be an integer')
  ],
  sessionController.disconnectAllUserSessions
);

/**
 * @route GET /api/sessions/stats/daily
 * @desc Get daily session statistics
 * @access Private (Admin)
 */
router.get(
  '/stats/daily',
  authenticate,
  authorize(['admin']),
  sessionController.getDailySessionStats
);

/**
 * @route GET /api/sessions/stats/hourly
 * @desc Get hourly session statistics
 * @access Private (Admin)
 */
router.get(
  '/stats/hourly',
  authenticate,
  authorize(['admin']),
  sessionController.getHourlySessionStats
);

/**
 * @route GET /api/sessions/stats/usage
 * @desc Get data usage statistics
 * @access Private (Admin)
 */
router.get(
  '/stats/usage',
  authenticate,
  authorize(['admin']),
  sessionController.getDataUsageStats
);

/**
 * @route GET /api/sessions/user/:userId
 * @desc Get sessions for a specific user
 * @access Private (Admin, Own User)
 */
router.get(
  '/user/:userId',
  authenticate,
  sessionController.getUserSessions
);

/**
 * @route GET /api/sessions/router/:routerId
 * @desc Get sessions for a specific router
 * @access Private (Admin)
 */
router.get(
  '/router/:routerId',
  authenticate,
  authorize(['admin']),
  sessionController.getRouterSessions
);

module.exports = router;