const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const notificationController = require('../controllers/notification.controller');
const { authenticate, authorize } = require('../middleware/auth');

/**
 * @route GET /api/notifications
 * @desc Get all notifications (with pagination)
 * @access Private (Admin)
 */
router.get(
  '/',
  authenticate,
  authorize(['admin']),
  notificationController.getAllNotifications
);

/**
 * @route GET /api/notifications/user
 * @desc Get current user's notifications
 * @access Private
 */
router.get(
  '/user',
  authenticate,
  notificationController.getUserNotifications
);

/**
 * @route GET /api/notifications/:id
 * @desc Get notification by ID
 * @access Private
 */
router.get(
  '/:id',
  authenticate,
  notificationController.getNotificationById
);

/**
 * @route POST /api/notifications
 * @desc Create a new notification
 * @access Private (Admin)
 */
router.post(
  '/',
  authenticate,
  authorize(['admin']),
  [
    body('user_id')
      .optional()
      .isInt()
      .withMessage('User ID must be an integer'),
    body('title')
      .notEmpty()
      .withMessage('Title is required'),
    body('message')
      .notEmpty()
      .withMessage('Message is required'),
    body('type')
      .isIn(['info', 'success', 'warning', 'error'])
      .withMessage('Invalid notification type'),
    body('priority')
      .optional()
      .isIn(['low', 'medium', 'high'])
      .withMessage('Invalid priority'),
    body('action_url')
      .optional()
      .isURL()
      .withMessage('Action URL must be a valid URL'),
    body('icon')
      .optional(),
    body('send_sms')
      .optional()
      .isBoolean()
      .withMessage('send_sms must be a boolean value'),
    body('send_email')
      .optional()
      .isBoolean()
      .withMessage('send_email must be a boolean value')
  ],
  notificationController.createNotification
);

/**
 * @route POST /api/notifications/bulk
 * @desc Create bulk notifications
 * @access Private (Admin)
 */
router.post(
  '/bulk',
  authenticate,
  authorize(['admin']),
  [
    body('user_ids')
      .isArray()
      .withMessage('user_ids must be an array'),
    body('title')
      .notEmpty()
      .withMessage('Title is required'),
    body('message')
      .notEmpty()
      .withMessage('Message is required'),
    body('type')
      .isIn(['info', 'success', 'warning', 'error'])
      .withMessage('Invalid notification type'),
    body('priority')
      .optional()
      .isIn(['low', 'medium', 'high'])
      .withMessage('Invalid priority'),
    body('action_url')
      .optional()
      .isURL()
      .withMessage('Action URL must be a valid URL'),
    body('icon')
      .optional(),
    body('send_sms')
      .optional()
      .isBoolean()
      .withMessage('send_sms must be a boolean value'),
    body('send_email')
      .optional()
      .isBoolean()
      .withMessage('send_email must be a boolean value')
  ],
  notificationController.createBulkNotifications
);

/**
 * @route PATCH /api/notifications/:id/read
 * @desc Mark notification as read
 * @access Private
 */
router.patch(
  '/:id/read',
  authenticate,
  notificationController.markAsRead
);

/**
 * @route PATCH /api/notifications/read-all
 * @desc Mark all notifications as read for current user
 * @access Private
 */
router.patch(
  '/read-all',
  authenticate,
  notificationController.markAllAsRead
);

/**
 * @route DELETE /api/notifications/:id
 * @desc Delete notification
 * @access Private
 */
router.delete(
  '/:id',
  authenticate,
  notificationController.deleteNotification
);

/**
 * @route POST /api/notifications/system
 * @desc Create a system notification (for all users)
 * @access Private (Admin)
 */
router.post(
  '/system',
  authenticate,
  authorize(['admin']),
  [
    body('title')
      .notEmpty()
      .withMessage('Title is required'),
    body('message')
      .notEmpty()
      .withMessage('Message is required'),
    body('type')
      .isIn(['info', 'success', 'warning', 'error'])
      .withMessage('Invalid notification type'),
    body('priority')
      .optional()
      .isIn(['low', 'medium', 'high'])
      .withMessage('Invalid priority'),
    body('action_url')
      .optional()
      .isURL()
      .withMessage('Action URL must be a valid URL'),
    body('icon')
      .optional(),
    body('send_sms')
      .optional()
      .isBoolean()
      .withMessage('send_sms must be a boolean value'),
    body('send_email')
      .optional()
      .isBoolean()
      .withMessage('send_email must be a boolean value')
  ],
  notificationController.createSystemNotification
);

module.exports = router;