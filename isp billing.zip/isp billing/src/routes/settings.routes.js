const express = require('express');
const router = express.Router();
const { body, param } = require('express-validator');
const settingsController = require('../controllers/settings.controller');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/authorize');

/**
 * @route GET /api/settings
 * @desc Get all settings
 * @access Private (Admin only)
 */
router.get(
  '/',
  authenticate,
  authorize([1]), // Admin role only
  settingsController.getAllSettings
);

/**
 * @route GET /api/settings/public
 * @desc Get public settings
 * @access Public
 */
router.get(
  '/public',
  settingsController.getPublicSettings
);

/**
 * @route GET /api/settings/category/:category
 * @desc Get settings by category
 * @access Private (Admin only)
 */
router.get(
  '/category/:category',
  authenticate,
  authorize([1]), // Admin role only
  param('category').notEmpty().withMessage('Category is required'),
  settingsController.getSettingsByCategory
);

/**
 * @route GET /api/settings/:key
 * @desc Get setting by key
 * @access Private (Admin only)
 */
router.get(
  '/:key',
  authenticate,
  authorize([1]), // Admin role only
  param('key').notEmpty().withMessage('Key is required'),
  settingsController.getSettingByKey
);

/**
 * @route POST /api/settings
 * @desc Create a new setting
 * @access Private (Admin only)
 */
router.post(
  '/',
  authenticate,
  authorize([1]), // Admin role only
  [
    body('key').notEmpty().withMessage('Key is required')
      .matches(/^[a-zA-Z0-9_]+$/).withMessage('Key must contain only letters, numbers, and underscores'),
    body('value').notEmpty().withMessage('Value is required'),
    body('category').optional().isString().withMessage('Category must be a string'),
    body('description').optional().isString().withMessage('Description must be a string'),
    body('type').optional().isIn(['string', 'number', 'boolean', 'json', 'text', 'password'])
      .withMessage('Type must be one of: string, number, boolean, json, text, password'),
    body('is_public').optional().isBoolean().withMessage('is_public must be a boolean')
  ],
  settingsController.createSetting
);

/**
 * @route PUT /api/settings/:key
 * @desc Update a setting
 * @access Private (Admin only)
 */
router.put(
  '/:key',
  authenticate,
  authorize([1]), // Admin role only
  [
    param('key').notEmpty().withMessage('Key is required'),
    body('value').optional(),
    body('category').optional().isString().withMessage('Category must be a string'),
    body('description').optional().isString().withMessage('Description must be a string'),
    body('type').optional().isIn(['string', 'number', 'boolean', 'json', 'text', 'password'])
      .withMessage('Type must be one of: string, number, boolean, json, text, password'),
    body('is_public').optional().isBoolean().withMessage('is_public must be a boolean')
  ],
  settingsController.updateSetting
);

/**
 * @route PUT /api/settings
 * @desc Update multiple settings
 * @access Private (Admin only)
 */
router.put(
  '/',
  authenticate,
  authorize([1]), // Admin role only
  [
    body('settings').isArray().withMessage('Settings must be an array'),
    body('settings.*.key').notEmpty().withMessage('Key is required for each setting'),
    body('settings.*.value').notEmpty().withMessage('Value is required for each setting')
  ],
  settingsController.updateMultipleSettings
);

/**
 * @route DELETE /api/settings/:key
 * @desc Delete a setting
 * @access Private (Admin only)
 */
router.delete(
  '/:key',
  authenticate,
  authorize([1]), // Admin role only
  param('key').notEmpty().withMessage('Key is required'),
  settingsController.deleteSetting
);

/**
 * @route POST /api/settings/initialize
 * @desc Initialize default settings
 * @access Private (Admin only)
 */
router.post(
  '/initialize',
  authenticate,
  authorize([1]), // Admin role only
  settingsController.initializeDefaultSettings
);

module.exports = router;