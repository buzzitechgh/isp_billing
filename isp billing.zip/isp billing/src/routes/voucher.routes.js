const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const voucherController = require('../controllers/voucher.controller');
const { authenticate, authorize } = require('../middleware/auth');

/**
 * @route GET /api/vouchers
 * @desc Get all vouchers (with pagination)
 * @access Private (Admin, Manager)
 */
router.get(
  '/',
  authenticate,
  authorize(['admin', 'manager']),
  voucherController.getAllVouchers
);

/**
 * @route GET /api/vouchers/:id
 * @desc Get voucher by ID
 * @access Private (Admin, Manager)
 */
router.get(
  '/:id',
  authenticate,
  authorize(['admin', 'manager']),
  voucherController.getVoucherById
);

/**
 * @route POST /api/vouchers/batch
 * @desc Generate batch of vouchers
 * @access Private (Admin)
 */
router.post(
  '/batch',
  authenticate,
  authorize(['admin']),
  [
    body('plan_id')
      .isInt()
      .withMessage('Plan ID must be an integer'),
    body('quantity')
      .isInt({ min: 1, max: 1000 })
      .withMessage('Quantity must be between 1 and 1000'),
    body('prefix')
      .optional()
      .isLength({ max: 5 })
      .withMessage('Prefix must be 5 characters or less'),
    body('length')
      .optional()
      .isInt({ min: 6, max: 12 })
      .withMessage('Length must be between 6 and 12'),
    body('batch_name')
      .optional()
      .isLength({ max: 50 })
      .withMessage('Batch name must be 50 characters or less'),
    body('expiry_date')
      .optional()
      .isISO8601()
      .withMessage('Expiry date must be a valid date')
  ],
  voucherController.generateVoucherBatch
);

/**
 * @route POST /api/vouchers
 * @desc Create a single voucher
 * @access Private (Admin)
 */
router.post(
  '/',
  authenticate,
  authorize(['admin']),
  [
    body('plan_id')
      .isInt()
      .withMessage('Plan ID must be an integer'),
    body('code')
      .optional()
      .isLength({ min: 6, max: 12 })
      .withMessage('Code must be between 6 and 12 characters'),
    body('expiry_date')
      .optional()
      .isISO8601()
      .withMessage('Expiry date must be a valid date')
  ],
  voucherController.createVoucher
);

/**
 * @route POST /api/vouchers/validate
 * @desc Validate a voucher code
 * @access Public
 */
router.post(
  '/validate',
  [
    body('code')
      .notEmpty()
      .withMessage('Voucher code is required')
  ],
  voucherController.validateVoucher
);

/**
 * @route POST /api/vouchers/redeem
 * @desc Redeem a voucher
 * @access Public (for hotspot users) or Private (for registered users)
 */
router.post(
  '/redeem',
  [
    body('code')
      .notEmpty()
      .withMessage('Voucher code is required'),
    body('username')
      .optional()
      .isLength({ min: 3, max: 30 })
      .withMessage('Username must be between 3 and 30 characters'),
    body('phone')
      .optional()
      .isMobilePhone()
      .withMessage('Please provide a valid phone number')
  ],
  voucherController.redeemVoucher
);

/**
 * @route DELETE /api/vouchers/:id
 * @desc Delete voucher
 * @access Private (Admin)
 */
router.delete(
  '/:id',
  authenticate,
  authorize(['admin']),
  voucherController.deleteVoucher
);

/**
 * @route DELETE /api/vouchers/batch/:batchName
 * @desc Delete voucher batch
 * @access Private (Admin)
 */
router.delete(
  '/batch/:batchName',
  authenticate,
  authorize(['admin']),
  voucherController.deleteVoucherBatch
);

/**
 * @route GET /api/vouchers/export/batch/:batchName
 * @desc Export voucher batch (PDF, CSV)
 * @access Private (Admin)
 */
router.get(
  '/export/batch/:batchName',
  authenticate,
  authorize(['admin']),
  voucherController.exportVoucherBatch
);

/**
 * @route GET /api/vouchers/print/:id
 * @desc Print single voucher
 * @access Private (Admin)
 */
router.get(
  '/print/:id',
  authenticate,
  authorize(['admin']),
  voucherController.printVoucher
);

module.exports = router;