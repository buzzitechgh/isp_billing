/**
 * Hotspot API validation schemas
 */

const { body, param, query } = require('express-validator');

exports.checkSession = [
  body('mac')
    .notEmpty()
    .withMessage('MAC address is required')
    .matches(/^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/)
    .withMessage('Invalid MAC address format'),
  body('ip')
    .optional()
    .isIP()
    .withMessage('Invalid IP address format')
];

exports.verifyVoucher = [
  body('code')
    .notEmpty()
    .withMessage('Voucher code is required')
    .isString()
    .withMessage('Voucher code must be a string')
];

exports.redeemVoucher = [
  body('code')
    .notEmpty()
    .withMessage('Voucher code is required')
    .isString()
    .withMessage('Voucher code must be a string'),
  body('mac')
    .notEmpty()
    .withMessage('MAC address is required')
    .matches(/^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/)
    .withMessage('Invalid MAC address format')
];

exports.activateFreeTrial = [
  body('mac')
    .notEmpty()
    .withMessage('MAC address is required')
    .matches(/^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/)
    .withMessage('Invalid MAC address format'),
  body('duration')
    .optional()
    .isInt({ min: 1, max: 120 })
    .withMessage('Duration must be between 1 and 120 minutes'),
  body('bandwidth')
    .optional()
    .isFloat({ min: 0.1, max: 10 })
    .withMessage('Bandwidth must be between 0.1 and 10 Mbps')
];

exports.initializePayment = [
  body('plan_id')
    .notEmpty()
    .withMessage('Plan ID is required')
    .isUUID(4)
    .withMessage('Invalid plan ID format'),
  body('email')
    .notEmpty()
    .withMessage('Email is required')
    .isEmail()
    .withMessage('Invalid email format'),
  body('mac_address')
    .notEmpty()
    .withMessage('MAC address is required')
    .matches(/^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/)
    .withMessage('Invalid MAC address format'),
  body('phone')
    .optional()
    .isMobilePhone()
    .withMessage('Invalid phone number format')
];

exports.purchasePlan = [
  body('plan_id')
    .notEmpty()
    .withMessage('Plan ID is required')
    .isUUID(4)
    .withMessage('Invalid plan ID format'),
  body('mac_address')
    .notEmpty()
    .withMessage('MAC address is required')
    .matches(/^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/)
    .withMessage('Invalid MAC address format'),
  body('payment_method')
    .notEmpty()
    .withMessage('Payment method is required')
    .isIn(['paystack', 'cash', 'bank_transfer', 'other'])
    .withMessage('Invalid payment method'),
  body('payment_reference')
    .optional()
    .isString()
    .withMessage('Payment reference must be a string'),
  body('email')
    .optional()
    .isEmail()
    .withMessage('Invalid email format'),
  body('phone')
    .optional()
    .isMobilePhone()
    .withMessage('Invalid phone number format')
];

exports.verifyPayment = [
  query('reference')
    .notEmpty()
    .withMessage('Transaction reference is required')
    .isString()
    .withMessage('Transaction reference must be a string')
];