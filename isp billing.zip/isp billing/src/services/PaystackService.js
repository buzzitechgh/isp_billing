const https = require('https');

class PaystackService {
  /**
   * Initialize Paystack API with secret key
   * @returns {Object} - Configured Paystack instance
   */
  static initialize() {
    const secretKey = process.env.PAYSTACK_SECRET_KEY;
    
    if (!secretKey) {
      throw new Error('Paystack secret key is not configured');
    }
    
    return this;
  }
  
  /**
   * Make a request to Paystack API
   * @param {string} method - HTTP method (GET, POST, PUT, DELETE)
   * @param {string} path - API endpoint path
   * @param {Object} data - Request data (for POST and PUT requests)
   * @returns {Promise<Object>} - API response
   */
  static async makeRequest(method, path, data = null) {
    return new Promise((resolve, reject) => {
      const options = {
        hostname: 'api.paystack.co',
        port: 443,
        path,
        method,
        headers: {
          Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
          'Content-Type': 'application/json'
        }
      };
      
      const req = https.request(options, (res) => {
        let responseData = '';
        
        res.on('data', (chunk) => {
          responseData += chunk;
        });
        
        res.on('end', () => {
          try {
            const parsedData = JSON.parse(responseData);
            resolve(parsedData);
          } catch (error) {
            reject(new Error(`Failed to parse Paystack response: ${error.message}`));
          }
        });
      });
      
      req.on('error', (error) => {
        reject(new Error(`Paystack API request failed: ${error.message}`));
      });
      
      if (data) {
        req.write(JSON.stringify(data));
      }
      
      req.end();
    });
  }
  
  /**
   * Initialize a transaction
   * @param {Object} transactionData - Transaction data
   * @returns {Promise<Object>} - Transaction initialization response
   */
  static async initializeTransaction(transactionData) {
    try {
      this.initialize();
      
      const data = {
        email: transactionData.email,
        amount: Math.round(transactionData.amount * 100), // Convert to kobo/cents
        callback_url: transactionData.callback_url,
        reference: transactionData.reference,
        metadata: transactionData.metadata || {}
      };
      
      return await this.makeRequest('POST', '/transaction/initialize', data);
    } catch (error) {
      throw new Error(`Failed to initialize transaction: ${error.message}`);
    }
  }
  
  /**
   * Verify a transaction
   * @param {string} reference - Transaction reference
   * @returns {Promise<Object>} - Transaction verification response
   */
  static async verifyTransaction(reference) {
    try {
      this.initialize();
      
      return await this.makeRequest('GET', `/transaction/verify/${reference}`);
    } catch (error) {
      throw new Error(`Failed to verify transaction: ${error.message}`);
    }
  }
  
  /**
   * List transactions
   * @param {Object} params - Query parameters
   * @returns {Promise<Object>} - Transactions list response
   */
  static async listTransactions(params = {}) {
    try {
      this.initialize();
      
      // Build query string from params
      const queryString = Object.keys(params)
        .map(key => `${key}=${encodeURIComponent(params[key])}`)
        .join('&');
      
      const path = `/transaction?${queryString}`;
      
      return await this.makeRequest('GET', path);
    } catch (error) {
      throw new Error(`Failed to list transactions: ${error.message}`);
    }
  }
  
  /**
   * Create a customer
   * @param {Object} customerData - Customer data
   * @returns {Promise<Object>} - Customer creation response
   */
  static async createCustomer(customerData) {
    try {
      this.initialize();
      
      const data = {
        email: customerData.email,
        first_name: customerData.first_name,
        last_name: customerData.last_name,
        phone: customerData.phone
      };
      
      return await this.makeRequest('POST', '/customer', data);
    } catch (error) {
      throw new Error(`Failed to create customer: ${error.message}`);
    }
  }
  
  /**
   * Create a payment plan
   * @param {Object} planData - Plan data
   * @returns {Promise<Object>} - Plan creation response
   */
  static async createPlan(planData) {
    try {
      this.initialize();
      
      const data = {
        name: planData.name,
        amount: Math.round(planData.amount * 100), // Convert to kobo/cents
        interval: planData.interval
      };
      
      return await this.makeRequest('POST', '/plan', data);
    } catch (error) {
      throw new Error(`Failed to create plan: ${error.message}`);
    }
  }
  
  /**
   * Create a subscription
   * @param {Object} subscriptionData - Subscription data
   * @returns {Promise<Object>} - Subscription creation response
   */
  static async createSubscription(subscriptionData) {
    try {
      this.initialize();
      
      const data = {
        customer: subscriptionData.customer,
        plan: subscriptionData.plan
      };
      
      return await this.makeRequest('POST', '/subscription', data);
    } catch (error) {
      throw new Error(`Failed to create subscription: ${error.message}`);
    }
  }
  
  /**
   * Generate a unique transaction reference
   * @param {string} prefix - Reference prefix
   * @returns {string} - Unique transaction reference
   */
  static generateReference(prefix = 'TX') {
    const timestamp = Date.now().toString();
    const random = Math.floor(Math.random() * 1000000).toString().padStart(6, '0');
    return `${prefix}_${timestamp}_${random}`;
  }
  
  /**
   * Process a webhook event from Paystack
   * @param {Object} eventData - Webhook event data
   * @returns {Promise<Object>} - Processing result
   */
  static async processWebhookEvent(eventData) {
    try {
      const event = eventData.event;
      const data = eventData.data;
      
      switch (event) {
        case 'charge.success':
          return await this.handleSuccessfulCharge(data);
        
        case 'subscription.create':
          return await this.handleSubscriptionCreated(data);
        
        case 'subscription.disable':
          return await this.handleSubscriptionDisabled(data);
        
        default:
          return { success: true, message: `Unhandled event: ${event}` };
      }
    } catch (error) {
      throw new Error(`Failed to process webhook event: ${error.message}`);
    }
  }
  
  /**
   * Handle successful charge event
   * @param {Object} data - Charge data
   * @returns {Promise<Object>} - Processing result
   */
  static async handleSuccessfulCharge(data) {
    try {
      // Extract metadata from the transaction
      const metadata = data.metadata || {};
      const userId = metadata.user_id;
      const planId = metadata.plan_id;
      
      if (!userId || !planId) {
        return { success: false, message: 'Missing user_id or plan_id in metadata' };
      }
      
      // Create a transaction record
      const Transaction = require('../models/Transaction');
      const transaction = await Transaction.create({
        user_id: userId,
        plan_id: planId,
        amount: data.amount / 100, // Convert from kobo/cents
        payment_method: 'paystack',
        status: 'completed',
        reference: data.reference,
        payment_gateway_response: data
      });
      
      return { success: true, transaction };
    } catch (error) {
      throw new Error(`Failed to handle successful charge: ${error.message}`);
    }
  }
  
  /**
   * Handle subscription created event
   * @param {Object} data - Subscription data
   * @returns {Promise<Object>} - Processing result
   */
  static async handleSubscriptionCreated(data) {
    // Implement subscription creation handling
    return { success: true, message: 'Subscription created' };
  }
  
  /**
   * Handle subscription disabled event
   * @param {Object} data - Subscription data
   * @returns {Promise<Object>} - Processing result
   */
  static async handleSubscriptionDisabled(data) {
    // Implement subscription disabling handling
    return { success: true, message: 'Subscription disabled' };
  }
}

module.exports = PaystackService;