const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');
const PDFDocument = require('pdfkit');

class EmailService {
  /**
   * Get email transporter
   * @returns {Object} - Nodemailer transporter
   */
  static getTransporter() {
    return nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: process.env.SMTP_PORT,
      secure: process.env.SMTP_PORT === '465',
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASSWORD
      }
    });
  }
  
  /**
   * Send email
   * @param {Object} options - Email options
   * @returns {Promise<Object>} - Email sending result
   */
  static async sendEmail(options) {
    try {
      const transporter = this.getTransporter();
      
      const mailOptions = {
        from: options.from || process.env.FROM_EMAIL,
        to: options.to,
        subject: options.subject,
        text: options.text,
        html: options.html,
        attachments: options.attachments || []
      };
      
      const info = await transporter.sendMail(mailOptions);
      
      console.log(`Email sent to ${options.to}, ID: ${info.messageId}`);
      
      return { success: true, messageId: info.messageId };
    } catch (error) {
      console.error('Failed to send email:', error);
      throw new Error(`Failed to send email: ${error.message}`);
    }
  }
  
  /**
   * Send welcome email to new user
   * @param {Object} user - User data
   * @returns {Promise<Object>} - Email sending result
   */
  static async sendWelcomeEmail(user) {
    try {
      const subject = 'Welcome to ISP Billing System';
      
      const text = `
        Hello ${user.full_name},
        
        Welcome to our ISP Billing System! Your account has been created successfully.
        
        Your login details:
        Username: ${user.username}
        
        You can now log in to your account and purchase internet plans.
        
        Thank you for choosing our service!
        
        Best regards,
        ISP Billing Team
      `.trim();
      
      const html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #4CAF50;">Welcome to ISP Billing System</h2>
          
          <p>Hello ${user.full_name},</p>
          
          <p>Welcome to our ISP Billing System! Your account has been created successfully.</p>
          
          <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <h3 style="margin-top: 0;">Your login details:</h3>
            <p><strong>Username:</strong> ${user.username}</p>
          </div>
          
          <p>You can now log in to your account and purchase internet plans.</p>
          
          <p>Thank you for choosing our service!</p>
          
          <p>Best regards,<br>ISP Billing Team</p>
        </div>
      `.trim();
      
      return await this.sendEmail({
        to: user.email,
        subject,
        text,
        html
      });
    } catch (error) {
      throw new Error(`Failed to send welcome email: ${error.message}`);
    }
  }
  
  /**
   * Send password reset email
   * @param {Object} data - Password reset data
   * @returns {Promise<Object>} - Email sending result
   */
  static async sendPasswordResetEmail(data) {
    try {
      const { email, resetToken, resetUrl } = data;
      
      const subject = 'Password Reset Request';
      
      const text = `
        You requested a password reset for your ISP Billing account.
        
        Please use the following link to reset your password:
        ${resetUrl}
        
        This link will expire in 1 hour.
        
        If you didn't request this, please ignore this email.
        
        Best regards,
        ISP Billing Team
      `.trim();
      
      const html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #4CAF50;">Password Reset Request</h2>
          
          <p>You requested a password reset for your ISP Billing account.</p>
          
          <div style="margin: 30px 0;">
            <a href="${resetUrl}" style="background-color: #4CAF50; color: white; padding: 12px 20px; text-decoration: none; border-radius: 4px; display: inline-block;">Reset Your Password</a>
          </div>
          
          <p>Or copy and paste this link in your browser:</p>
          <p style="word-break: break-all; color: #666;">${resetUrl}</p>
          
          <p>This link will expire in 1 hour.</p>
          
          <p>If you didn't request this, please ignore this email.</p>
          
          <p>Best regards,<br>ISP Billing Team</p>
        </div>
      `.trim();
      
      return await this.sendEmail({
        to: email,
        subject,
        text,
        html
      });
    } catch (error) {
      throw new Error(`Failed to send password reset email: ${error.message}`);
    }
  }
  
  /**
   * Send payment receipt email
   * @param {Object} data - Payment data
   * @returns {Promise<Object>} - Email sending result
   */
  static async sendPaymentReceiptEmail(data) {
    try {
      const { transaction, user, plan } = data;
      
      // Generate PDF receipt
      const pdfPath = await this.generatePDFReceipt(data);
      
      const subject = `Payment Receipt - ${transaction.receipt_number}`;
      
      const text = `
        Hello ${user.full_name},
        
        Thank you for your payment. Please find your receipt attached.
        
        Receipt Number: ${transaction.receipt_number}
        Amount: ${transaction.amount}
        Plan: ${plan.name}
        Date: ${new Date(transaction.createdAt).toLocaleString()}
        Valid until: ${new Date(transaction.end_date).toLocaleString()}
        
        Thank you for your business!
        
        Best regards,
        ISP Billing Team
      `.trim();
      
      const html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #4CAF50;">Payment Receipt</h2>
          
          <p>Hello ${user.full_name},</p>
          
          <p>Thank you for your payment. Please find your receipt attached.</p>
          
          <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <h3 style="margin-top: 0;">Payment Details:</h3>
            <p><strong>Receipt Number:</strong> ${transaction.receipt_number}</p>
            <p><strong>Amount:</strong> ${transaction.amount}</p>
            <p><strong>Plan:</strong> ${plan.name}</p>
            <p><strong>Date:</strong> ${new Date(transaction.createdAt).toLocaleString()}</p>
            <p><strong>Valid until:</strong> ${new Date(transaction.end_date).toLocaleString()}</p>
          </div>
          
          <p>Thank you for your business!</p>
          
          <p>Best regards,<br>ISP Billing Team</p>
        </div>
      `.trim();
      
      const result = await this.sendEmail({
        to: user.email,
        subject,
        text,
        html,
        attachments: [
          {
            filename: `Receipt-${transaction.receipt_number}.pdf`,
            path: pdfPath,
            contentType: 'application/pdf'
          }
        ]
      });
      
      // Delete temporary PDF file
      fs.unlinkSync(pdfPath);
      
      return result;
    } catch (error) {
      throw new Error(`Failed to send payment receipt email: ${error.message}`);
    }
  }
  
  /**
   * Generate PDF receipt
   * @param {Object} data - Receipt data
   * @returns {Promise<string>} - Path to generated PDF file
   */
  static async generatePDFReceipt(data) {
    return new Promise((resolve, reject) => {
      try {
        const { transaction, user, plan } = data;
        
        // Create temporary file path
        const tempDir = path.join(__dirname, '../../temp');
        
        // Create temp directory if it doesn't exist
        if (!fs.existsSync(tempDir)) {
          fs.mkdirSync(tempDir, { recursive: true });
        }
        
        const filePath = path.join(tempDir, `receipt-${transaction.receipt_number}.pdf`);
        
        // Create PDF document
        const doc = new PDFDocument({ margin: 50 });
        
        // Pipe output to file
        doc.pipe(fs.createWriteStream(filePath));
        
        // Add company logo (placeholder)
        // doc.image('path/to/logo.png', 50, 45, { width: 150 });
        
        // Add title
        doc.fontSize(20).text('PAYMENT RECEIPT', { align: 'center' });
        doc.moveDown();
        
        // Add receipt details
        doc.fontSize(12).text(`Receipt Number: ${transaction.receipt_number}`, { align: 'right' });
        doc.fontSize(12).text(`Date: ${new Date(transaction.createdAt).toLocaleString()}`, { align: 'right' });
        doc.moveDown(2);
        
        // Add customer details
        doc.fontSize(14).text('Customer Details');
        doc.moveDown(0.5);
        doc.fontSize(10).text(`Name: ${user.full_name}`);
        doc.fontSize(10).text(`Email: ${user.email}`);
        doc.fontSize(10).text(`Phone: ${user.phone || 'N/A'}`);
        doc.moveDown(2);
        
        // Add payment details
        doc.fontSize(14).text('Payment Details');
        doc.moveDown(0.5);
        
        // Create table for payment details
        const tableTop = doc.y;
        const itemX = 50;
        const descriptionX = 150;
        const amountX = 400;
        
        // Add table headers
        doc.fontSize(10).text('Item', itemX, tableTop);
        doc.text('Description', descriptionX, tableTop);
        doc.text('Amount', amountX, tableTop);
        
        // Add horizontal line
        doc.moveDown(0.5);
        doc.strokeColor('#aaaaaa').lineWidth(1).moveTo(50, doc.y).lineTo(550, doc.y).stroke();
        doc.moveDown(0.5);
        
        // Add plan details
        const planY = doc.y;
        doc.fontSize(10).text('Internet Plan', itemX, planY);
        doc.text(`${plan.name} (${plan.duration} hours)`, descriptionX, planY);
        doc.text(`$${transaction.amount.toFixed(2)}`, amountX, planY);
        
        // Add horizontal line
        doc.moveDown(2);
        doc.strokeColor('#aaaaaa').lineWidth(1).moveTo(50, doc.y).lineTo(550, doc.y).stroke();
        doc.moveDown(0.5);
        
        // Add total
        doc.fontSize(12).text('Total:', 350, doc.y);
        doc.fontSize(12).text(`$${transaction.amount.toFixed(2)}`, amountX, doc.y);
        
        // Add payment method
        doc.moveDown(2);
        doc.fontSize(10).text(`Payment Method: ${transaction.payment_method.toUpperCase()}`);
        doc.fontSize(10).text(`Transaction Reference: ${transaction.reference}`);
        
        // Add validity period
        doc.moveDown(2);
        doc.fontSize(12).text('Plan Validity Period');
        doc.moveDown(0.5);
        doc.fontSize(10).text(`Start Date: ${new Date(transaction.start_date).toLocaleString()}`);
        doc.fontSize(10).text(`End Date: ${new Date(transaction.end_date).toLocaleString()}`);
        
        // Add footer
        doc.moveDown(4);
        doc.fontSize(10).text('Thank you for your business!', { align: 'center' });
        doc.moveDown(0.5);
        doc.fontSize(8).text('This is a computer-generated receipt and does not require a signature.', { align: 'center' });
        
        // Finalize PDF
        doc.end();
        
        // Resolve with file path when PDF is created
        doc.on('end', () => {
          resolve(filePath);
        });
      } catch (error) {
        reject(new Error(`Failed to generate PDF receipt: ${error.message}`));
      }
    });
  }
  
  /**
   * Send plan expiry reminder email
   * @param {Object} data - Reminder data
   * @returns {Promise<Object>} - Email sending result
   */
  static async sendExpiryReminderEmail(data) {
    try {
      const { user, plan, expiryDate, daysLeft } = data;
      
      const subject = `Your ${plan.name} Plan Expires Soon`;
      
      const text = `
        Hello ${user.full_name},
        
        This is a reminder that your ${plan.name} plan will expire on ${expiryDate} (${daysLeft} days left).
        
        Please log in to your account to renew your plan and avoid service interruption.
        
        Thank you for using our service!
        
        Best regards,
        ISP Billing Team
      `.trim();
      
      const html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #4CAF50;">Plan Expiry Reminder</h2>
          
          <p>Hello ${user.full_name},</p>
          
          <p>This is a reminder that your <strong>${plan.name}</strong> plan will expire on <strong>${expiryDate}</strong> (${daysLeft} days left).</p>
          
          <div style="margin: 30px 0;">
            <a href="${process.env.FRONTEND_URL}/dashboard" style="background-color: #4CAF50; color: white; padding: 12px 20px; text-decoration: none; border-radius: 4px; display: inline-block;">Renew Your Plan</a>
          </div>
          
          <p>Please log in to your account to renew your plan and avoid service interruption.</p>
          
          <p>Thank you for using our service!</p>
          
          <p>Best regards,<br>ISP Billing Team</p>
        </div>
      `.trim();
      
      return await this.sendEmail({
        to: user.email,
        subject,
        text,
        html
      });
    } catch (error) {
      throw new Error(`Failed to send expiry reminder email: ${error.message}`);
    }
  }
}

module.exports = EmailService;