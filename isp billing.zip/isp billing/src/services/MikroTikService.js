const RouterOS = require('node-routeros').RouterOSAPI;
const Router = require('../models/Router');

class MikroTikService {
  /**
   * Connect to a MikroTik router
   * @param {Object} config - Router connection configuration
   * @returns {Promise<RouterOSAPI>} - RouterOS API connection
   */
  static async connect(config) {
    const conn = new RouterOS({
      host: config.host,
      port: config.port || 8728,
      user: config.username,
      password: config.password,
      timeout: 10000
    });
    
    try {
      await conn.connect();
      return conn;
    } catch (error) {
      throw new Error(`Failed to connect to MikroTik router: ${error.message}`);
    }
  }
  
  /**
   * Get default router connection
   * @returns {Promise<RouterOSAPI>} - RouterOS API connection
   */
  static async getDefaultRouter() {
    try {
      const router = await Router.findOne({ where: { is_active: true } });
      
      if (!router) {
        throw new Error('No active router found');
      }
      
      return await this.connect({
        host: router.ip_address,
        port: router.port,
        username: router.username,
        password: router.decryptPassword()
      });
    } catch (error) {
      throw new Error(`Failed to get default router: ${error.message}`);
    }
  }
  
  /**
   * Create a MikroTik hotspot user profile
   * @param {Object} plan - Plan model instance
   * @returns {Promise<Object>} - Created profile
   */
  static async createHotspotUserProfile(plan) {
    let conn;
    
    try {
      conn = await this.getDefaultRouter();
      
      // Check if profile already exists
      const profileName = `plan_${plan.id.substring(0, 8)}`;
      const existingProfiles = await conn.write('/ip/hotspot/user/profile/print', [
        '=.proplist=name',
        `?name=${profileName}`
      ]);
      
      // If profile exists, update it
      if (existingProfiles.length > 0) {
        return await this.updateHotspotUserProfile(plan);
      }
      
      // Convert speeds to proper format (e.g., 2M for 2 Mbps)
      const downloadSpeed = `${Math.floor(plan.download_speed / 1024)}M/${Math.floor(plan.download_speed / 1024)}M`;
      const uploadSpeed = `${Math.floor(plan.upload_speed / 1024)}M/${Math.floor(plan.upload_speed / 1024)}M`;
      
      // Create new profile
      const result = await conn.write('/ip/hotspot/user/profile/add', [
        `=name=${profileName}`,
        `=rate-limit=${uploadSpeed}/${downloadSpeed}`,
        `=shared-users=${plan.shared_users}`,
        `=transparent-proxy=no`,
        `=session-timeout=${plan.duration}h`,
        `=keepalive-timeout=2m`,
        `=status-autorefresh=1m`
      ]);
      
      // Update plan with profile name
      await plan.update({ mikrotik_profile: profileName });
      
      return { success: true, profileName, result };
    } catch (error) {
      throw new Error(`Failed to create hotspot user profile: ${error.message}`);
    } finally {
      if (conn) {
        conn.close();
      }
    }
  }
  
  /**
   * Update a MikroTik hotspot user profile
   * @param {Object} plan - Plan model instance
   * @returns {Promise<Object>} - Updated profile
   */
  static async updateHotspotUserProfile(plan) {
    let conn;
    
    try {
      conn = await this.getDefaultRouter();
      
      // Get profile name from plan or generate it
      const profileName = plan.mikrotik_profile || `plan_${plan.id.substring(0, 8)}`;
      
      // Find profile ID
      const profiles = await conn.write('/ip/hotspot/user/profile/print', [
        '=.proplist=.id,name',
        `?name=${profileName}`
      ]);
      
      if (profiles.length === 0) {
        // Profile doesn't exist, create it
        return await this.createHotspotUserProfile(plan);
      }
      
      const profileId = profiles[0]['.id'];
      
      // Convert speeds to proper format (e.g., 2M for 2 Mbps)
      const downloadSpeed = `${Math.floor(plan.download_speed / 1024)}M/${Math.floor(plan.download_speed / 1024)}M`;
      const uploadSpeed = `${Math.floor(plan.upload_speed / 1024)}M/${Math.floor(plan.upload_speed / 1024)}M`;
      
      // Update profile
      const result = await conn.write('/ip/hotspot/user/profile/set', [
        `=.id=${profileId}`,
        `=rate-limit=${uploadSpeed}/${downloadSpeed}`,
        `=shared-users=${plan.shared_users}`,
        `=session-timeout=${plan.duration}h`
      ]);
      
      // Update plan with profile name if it's not set
      if (!plan.mikrotik_profile) {
        await plan.update({ mikrotik_profile: profileName });
      }
      
      return { success: true, profileName, result };
    } catch (error) {
      throw new Error(`Failed to update hotspot user profile: ${error.message}`);
    } finally {
      if (conn) {
        conn.close();
      }
    }
  }
  
  /**
   * Create a MikroTik hotspot user
   * @param {Object} userData - User data
   * @returns {Promise<Object>} - Created user
   */
  static async createHotspotUser(userData) {
    let conn;
    
    try {
      conn = await this.getDefaultRouter();
      
      // Check if user already exists
      const existingUsers = await conn.write('/ip/hotspot/user/print', [
        '=.proplist=name',
        `?name=${userData.username}`
      ]);
      
      // If user exists, update it
      if (existingUsers.length > 0) {
        return await this.updateHotspotUser(userData);
      }
      
      // Create new user
      const result = await conn.write('/ip/hotspot/user/add', [
        `=name=${userData.username}`,
        `=password=${userData.password}`,
        `=profile=${userData.profile}`,
        `=limit-uptime=${userData.limit_uptime || '0'}`,
        `=comment=${userData.comment || ''}`
      ]);
      
      return { success: true, username: userData.username, result };
    } catch (error) {
      throw new Error(`Failed to create hotspot user: ${error.message}`);
    } finally {
      if (conn) {
        conn.close();
      }
    }
  }
  
  /**
   * Update a MikroTik hotspot user
   * @param {Object} userData - User data
   * @returns {Promise<Object>} - Updated user
   */
  static async updateHotspotUser(userData) {
    let conn;
    
    try {
      conn = await this.getDefaultRouter();
      
      // Find user ID
      const users = await conn.write('/ip/hotspot/user/print', [
        '=.proplist=.id,name',
        `?name=${userData.username}`
      ]);
      
      if (users.length === 0) {
        // User doesn't exist, create it
        return await this.createHotspotUser(userData);
      }
      
      const userId = users[0]['.id'];
      
      // Prepare update parameters
      const params = [`=.id=${userId}`];
      
      if (userData.password) {
        params.push(`=password=${userData.password}`);
      }
      
      if (userData.profile) {
        params.push(`=profile=${userData.profile}`);
      }
      
      if (userData.limit_uptime) {
        params.push(`=limit-uptime=${userData.limit_uptime}`);
      }
      
      if (userData.comment) {
        params.push(`=comment=${userData.comment}`);
      }
      
      // Update user
      const result = await conn.write('/ip/hotspot/user/set', params);
      
      return { success: true, username: userData.username, result };
    } catch (error) {
      throw new Error(`Failed to update hotspot user: ${error.message}`);
    } finally {
      if (conn) {
        conn.close();
      }
    }
  }
  
  /**
   * Create or update a MikroTik hotspot user
   * @param {Object} userData - User data
   * @returns {Promise<Object>} - Created or updated user
   */
  static async createOrUpdateHotspotUser(userData) {
    try {
      // Check if user exists and update or create accordingly
      return await this.createHotspotUser(userData);
    } catch (error) {
      throw new Error(`Failed to create or update hotspot user: ${error.message}`);
    }
  }
  
  /**
   * Delete a MikroTik hotspot user
   * @param {string} username - Username to delete
   * @returns {Promise<Object>} - Result
   */
  static async deleteHotspotUser(username) {
    let conn;
    
    try {
      conn = await this.getDefaultRouter();
      
      // Find user ID
      const users = await conn.write('/ip/hotspot/user/print', [
        '=.proplist=.id,name',
        `?name=${username}`
      ]);
      
      if (users.length === 0) {
        return { success: false, message: 'User not found' };
      }
      
      const userId = users[0]['.id'];
      
      // Delete user
      await conn.write('/ip/hotspot/user/remove', [`=.id=${userId}`]);
      
      return { success: true, message: 'User deleted successfully' };
    } catch (error) {
      throw new Error(`Failed to delete hotspot user: ${error.message}`);
    } finally {
      if (conn) {
        conn.close();
      }
    }
  }
  
  /**
   * Get active sessions from MikroTik router
   * @returns {Promise<Array>} - List of active sessions
   */
  static async getActiveSessions() {
    let conn;
    
    try {
      conn = await this.getDefaultRouter();
      
      // Get active sessions
      const sessions = await conn.write('/ip/hotspot/active/print');
      
      return sessions.map(session => ({
        id: session['.id'],
        user: session.user,
        address: session.address,
        mac_address: session['mac-address'],
        uptime: session.uptime,
        login_time: session['login-by'],
        bytes_in: parseInt(session['bytes-in'] || '0'),
        bytes_out: parseInt(session['bytes-out'] || '0')
      }));
    } catch (error) {
      throw new Error(`Failed to get active sessions: ${error.message}`);
    } finally {
      if (conn) {
        conn.close();
      }
    }
  }
  
  /**
   * Disconnect a MikroTik hotspot user session
   * @param {string} sessionId - Session ID to disconnect
   * @returns {Promise<Object>} - Result
   */
  static async disconnectSession(sessionId) {
    let conn;
    
    try {
      conn = await this.getDefaultRouter();
      
      // Disconnect session
      await conn.write('/ip/hotspot/active/remove', [`=.id=${sessionId}`]);
      
      return { success: true, message: 'Session disconnected successfully' };
    } catch (error) {
      throw new Error(`Failed to disconnect session: ${error.message}`);
    } finally {
      if (conn) {
        conn.close();
      }
    }
  }
  
  /**
   * Generate MikroTik hotspot login page with custom branding
   * @param {Object} options - Customization options
   * @returns {Promise<Object>} - Result
   */
  static async generateHotspotLoginPage(options) {
    let conn;
    
    try {
      conn = await this.getDefaultRouter();
      
      // Get router's hotspot directory
      const hotspotDir = await conn.write('/file/print', [
        '=.proplist=name',
        '?name=hotspot'
      ]);
      
      if (hotspotDir.length === 0) {
        throw new Error('Hotspot directory not found');
      }
      
      // Generate custom login page HTML
      const loginHtml = this.generateLoginPageHtml(options);
      
      // Upload login page to router
      // Note: This is a simplified example. In a real implementation,
      // you would need to use FTP or another method to upload files to the router.
      
      return { success: true, message: 'Login page generated successfully' };
    } catch (error) {
      throw new Error(`Failed to generate hotspot login page: ${error.message}`);
    } finally {
      if (conn) {
        conn.close();
      }
    }
  }
  
  /**
   * Generate HTML for custom hotspot login page
   * @param {Object} options - Customization options
   * @returns {string} - HTML content
   */
  static generateLoginPageHtml(options) {
    // This is a simplified example. In a real implementation,
    // you would use a template engine or more sophisticated HTML generation.
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <title>${options.title || 'Hotspot Login'}</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
          body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: ${options.backgroundColor || '#f5f5f5'};
          }
          .container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
          }
          .logo {
            text-align: center;
            margin-bottom: 20px;
          }
          .logo img {
            max-width: 200px;
            height: auto;
          }
          .form-group {
            margin-bottom: 15px;
          }
          .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
          }
          .form-group input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
          }
          .btn {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: ${options.buttonColor || '#4CAF50'};
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
          }
          .btn:hover {
            background-color: ${options.buttonHoverColor || '#45a049'};
          }
          .plans {
            margin-top: 30px;
          }
          .plan-item {
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 15px;
            margin-bottom: 15px;
            cursor: pointer;
            transition: all 0.3s;
          }
          .plan-item:hover {
            border-color: ${options.buttonColor || '#4CAF50'};
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
          }
          .plan-title {
            font-weight: bold;
            margin-bottom: 5px;
          }
          .plan-price {
            color: ${options.buttonColor || '#4CAF50'};
            font-size: 18px;
            margin-bottom: 5px;
          }
          .plan-details {
            color: #666;
            font-size: 14px;
          }
          .wifi-signal {
            text-align: center;
            margin: 20px 0;
          }
          @keyframes signal-animation {
            0% { opacity: 0.3; }
            50% { opacity: 1; }
            100% { opacity: 0.3; }
          }
          .signal-bar {
            display: inline-block;
            width: 6px;
            margin: 0 2px;
            background-color: ${options.buttonColor || '#4CAF50'};
            border-radius: 1px;
          }
          .bar-1 { height: 10px; animation: signal-animation 1.5s infinite; }
          .bar-2 { height: 15px; animation: signal-animation 1.5s infinite 0.2s; }
          .bar-3 { height: 20px; animation: signal-animation 1.5s infinite 0.4s; }
          .bar-4 { height: 25px; animation: signal-animation 1.5s infinite 0.6s; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="logo">
            <img src="${options.logoUrl || 'logo.png'}" alt="Logo">
          </div>
          
          <div class="wifi-signal">
            <div class="signal-bar bar-1"></div>
            <div class="signal-bar bar-2"></div>
            <div class="signal-bar bar-3"></div>
            <div class="signal-bar bar-4"></div>
          </div>
          
          <form name="login" action="$(link-login-only)" method="post">
            <input type="hidden" name="dst" value="$(link-orig)">
            <input type="hidden" name="popup" value="true">
            
            <div class="form-group">
              <label for="username">Username</label>
              <input type="text" name="username" id="username">
            </div>
            
            <div class="form-group">
              <label for="password">Password</label>
              <input type="password" name="password" id="password">
            </div>
            
            <button type="submit" class="btn">Login</button>
          </form>
          
          <div class="plans">
            <h3>Available Plans</h3>
            <div class="plan-item" onclick="location.href='$(link-signup)?plan=daily'">
              <div class="plan-title">Daily Plan</div>
              <div class="plan-price">$5.00</div>
              <div class="plan-details">24 hours, 5 Mbps, 1 device</div>
            </div>
            
            <div class="plan-item" onclick="location.href='$(link-signup)?plan=weekly'">
              <div class="plan-title">Weekly Plan</div>
              <div class="plan-price">$25.00</div>
              <div class="plan-details">7 days, 10 Mbps, 2 devices</div>
            </div>
            
            <div class="plan-item" onclick="location.href='$(link-signup)?plan=monthly'">
              <div class="plan-title">Monthly Plan</div>
              <div class="plan-price">$80.00</div>
              <div class="plan-details">30 days, 20 Mbps, 3 devices</div>
            </div>
          </div>
        </div>
        
        <script>
          // JavaScript for enhanced user experience
          document.addEventListener('DOMContentLoaded', function() {
            // Focus on username field
            document.getElementById('username').focus();
            
            // Handle plan selection
            const planItems = document.querySelectorAll('.plan-item');
            planItems.forEach(function(item) {
              item.addEventListener('click', function() {
                // You could add additional logic here
                console.log('Plan selected:', this.querySelector('.plan-title').textContent);
              });
            });
          });
        </script>
      </body>
      </html>
    `;
  }
}

module.exports = MikroTikService;