const twilio = require('twilio');

class TwilioService {
  /**
   * Initialize Twilio client with credentials
   * @returns {Object} - Twilio client
   */
  static getClient() {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    
    if (!accountSid || !authToken) {
      throw new Error('Twilio credentials are not configured');
    }
    
    return twilio(accountSid, authToken);
  }
  
  /**
   * Send SMS message
   * @param {string} to - Recipient phone number
   * @param {string} body - Message body
   * @returns {Promise<Object>} - SMS sending result
   */
  static async sendSMS(to, body) {
    try {
      // Format phone number if needed
      const formattedNumber = this.formatPhoneNumber(to);
      
      // Get Twilio client
      const client = this.getClient();
      
      // Send message
      const message = await client.messages.create({
        body,
        from: process.env.TWILIO_PHONE_NUMBER,
        to: formattedNumber
      });
      
      // Log message details
      console.log(`SMS sent to ${formattedNumber}, SID: ${message.sid}`);
      
      return { success: true, sid: message.sid };
    } catch (error) {
      console.error('Failed to send SMS:', error);
      throw new Error(`Failed to send SMS: ${error.message}`);
    }
  }
  
  /**
   * Format phone number to E.164 format
   * @param {string} phoneNumber - Phone number to format
   * @returns {string} - Formatted phone number
   */
  static formatPhoneNumber(phoneNumber) {
    // Remove any non-digit characters
    let digits = phoneNumber.replace(/\D/g, '');
    
    // Ensure number has country code
    if (digits.length === 10) {
      // Assume US number if 10 digits
      digits = `1${digits}`;
    }
    
    // Add + prefix for E.164 format
    return `+${digits}`;
  }
  
  /**
   * Send voucher credentials via SMS
   * @param {Object} data - Voucher data
   * @returns {Promise<Object>} - SMS sending result
   */
  static async sendVoucherCredentials(data) {
    try {
      const { phone, username, password, planName, duration } = data;
      
      const message = `
        Your internet access credentials:
        Username: ${username}
        Password: ${password}
        Plan: ${planName}
        Valid for: ${duration} hours
        
        Thank you for your purchase!
      `.trim();
      
      return await this.sendSMS(phone, message);
    } catch (error) {
      throw new Error(`Failed to send voucher credentials: ${error.message}`);
    }
  }
  
  /**
   * Send payment confirmation via SMS
   * @param {Object} data - Payment data
   * @returns {Promise<Object>} - SMS sending result
   */
  static async sendPaymentConfirmation(data) {
    try {
      const { phone, amount, planName, expiryDate, receiptNumber } = data;
      
      const message = `
        Payment Confirmation
        Amount: ${amount}
        Plan: ${planName}
        Valid until: ${expiryDate}
        Receipt: ${receiptNumber}
        
        Thank you for your payment!
      `.trim();
      
      return await this.sendSMS(phone, message);
    } catch (error) {
      throw new Error(`Failed to send payment confirmation: ${error.message}`);
    }
  }
  
  /**
   * Send plan expiry reminder via SMS
   * @param {Object} data - Reminder data
   * @returns {Promise<Object>} - SMS sending result
   */
  static async sendExpiryReminder(data) {
    try {
      const { phone, planName, expiryDate, daysLeft } = data;
      
      const message = `
        Plan Expiry Reminder
        Your ${planName} plan will expire on ${expiryDate} (${daysLeft} days left).
        Please renew your plan to avoid service interruption.
      `.trim();
      
      return await this.sendSMS(phone, message);
    } catch (error) {
      throw new Error(`Failed to send expiry reminder: ${error.message}`);
    }
  }
  
  /**
   * Send bulk SMS to multiple recipients
   * @param {Array} recipients - Array of recipient objects with phone and customVars
   * @param {string} messageTemplate - Message template with placeholders
   * @returns {Promise<Array>} - Array of SMS sending results
   */
  static async sendBulkSMS(recipients, messageTemplate) {
    try {
      const results = [];
      
      for (const recipient of recipients) {
        // Replace placeholders in template with custom variables
        let personalizedMessage = messageTemplate;
        
        for (const [key, value] of Object.entries(recipient.customVars || {})) {
          personalizedMessage = personalizedMessage.replace(
            new RegExp(`\\{\\{${key}\\}\\}`, 'g'),
            value
          );
        }
        
        // Send personalized message
        const result = await this.sendSMS(recipient.phone, personalizedMessage);
        results.push(result);
      }
      
      return results;
    } catch (error) {
      throw new Error(`Failed to send bulk SMS: ${error.message}`);
    }
  }
}

module.exports = TwilioService;