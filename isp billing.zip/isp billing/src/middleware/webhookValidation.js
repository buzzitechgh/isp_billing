const crypto = require('crypto');
const { createError } = require('../utils/errorUtils');

/**
 * Validates the Paystack webhook signature
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const validatePaystackSignature = (req, res, next) => {
  try {
    const paystackSecret = process.env.PAYSTACK_SECRET_KEY;
    if (!paystackSecret) {
      return next(createError(500, 'Paystack secret key not configured'));
    }

    // Get the signature from the header
    const signature = req.headers['x-paystack-signature'];
    if (!signature) {
      return next(createError(401, 'No signature found in the request'));
    }

    // Create a hash using the payload and the secret
    const hash = crypto
      .createHmac('sha512', paystackSecret)
      .update(JSON.stringify(req.body))
      .digest('hex');

    // Compare the hash with the signature
    if (hash !== signature) {
      return next(createError(401, 'Invalid signature'));
    }

    // If the signature is valid, proceed to the next middleware
    next();
  } catch (error) {
    next(createError(500, 'Error validating webhook signature', error));
  }
};

/**
 * Validates the MikroTik webhook API key
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const validateMikroTikApiKey = (req, res, next) => {
  try {
    const apiKey = req.headers['x-api-key'];
    const configuredApiKey = process.env.MIKROTIK_WEBHOOK_API_KEY;

    if (!configuredApiKey) {
      return next(createError(500, 'MikroTik webhook API key not configured'));
    }

    if (!apiKey || apiKey !== configuredApiKey) {
      return next(createError(401, 'Invalid or missing API key'));
    }

    next();
  } catch (error) {
    next(createError(500, 'Error validating MikroTik webhook API key', error));
  }
};

/**
 * Validates the Twilio webhook signature
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const validateTwilioSignature = (req, res, next) => {
  try {
    const twilioAuthToken = process.env.TWILIO_AUTH_TOKEN;
    if (!twilioAuthToken) {
      return next(createError(500, 'Twilio auth token not configured'));
    }

    const twilioSignature = req.headers['x-twilio-signature'];
    if (!twilioSignature) {
      return next(createError(401, 'No Twilio signature found in the request'));
    }

    // Get the full URL of the request
    const url = `${req.protocol}://${req.get('host')}${req.originalUrl}`;

    // Create a validation object from the request parameters
    const params = req.body || {};

    // Import the twilio module only when needed to avoid unnecessary dependencies
    const twilio = require('twilio');
    const isValid = twilio.validateRequest(
      twilioAuthToken,
      twilioSignature,
      url,
      params
    );

    if (!isValid) {
      return next(createError(401, 'Invalid Twilio signature'));
    }

    next();
  } catch (error) {
    next(createError(500, 'Error validating Twilio webhook signature', error));
  }
};

module.exports = {
  validatePaystackSignature,
  validateMikroTikApiKey,
  validateTwilioSignature
};