/**
 * Global error handling middleware
 * Formats and returns consistent error responses
 */
const errorHandler = (err, req, res, next) => {
  // Default error status and message
  let statusCode = err.statusCode || 500;
  let message = err.message || 'Something went wrong';
  let errors = err.errors || [];

  // Log error for server-side debugging
  console.error(`${req.method} ${req.path} - Error:`, err);

  // Handle Sequelize validation errors
  if (err.name === 'SequelizeValidationError' || err.name === 'SequelizeUniqueConstraintError') {
    statusCode = 400;
    message = 'Validation error';
    errors = err.errors.map(e => ({
      field: e.path,
      message: e.message
    }));
  }

  // Handle JWT errors
  if (err.name === 'JsonWebTokenError') {
    statusCode = 401;
    message = 'Invalid token';
  }

  if (err.name === 'TokenExpiredError') {
    statusCode = 401;
    message = 'Token expired';
  }

  // Handle Express Validator errors
  if (err.array && typeof err.array === 'function') {
    statusCode = 400;
    message = 'Validation error';
    errors = err.array().map(e => ({
      field: e.param,
      message: e.msg
    }));
  }

  // Send error response
  res.status(statusCode).json({
    success: false,
    message,
    errors: errors.length > 0 ? errors : undefined,
    stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
  });
};

/**
 * Request validation middleware
 * Validates request using express-validator
 */
const { validationResult } = require('express-validator');

const validateRequest = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const error = new Error('Validation error');
    error.statusCode = 400;
    error.errors = errors.array().map(e => ({
      field: e.param,
      message: e.msg
    }));
    return next(error);
  }
  next();
};

module.exports = {
  errorHandler,
  validateRequest
};