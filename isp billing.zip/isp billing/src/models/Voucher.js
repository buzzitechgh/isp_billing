const { DataTypes, Model } = require('sequelize');
const { sequelize } = require('../database/config');
const { v4: uuidv4 } = require('uuid');
const crypto = require('crypto');

class Voucher extends Model {
  // Generate a random voucher code
  static generateCode(length = 12) {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = '';
    
    for (let i = 0; i < length; i++) {
      const randomIndex = crypto.randomInt(0, chars.length);
      code += chars.charAt(randomIndex);
    }
    
    // Format code with dashes for readability (e.g., ABCD-EFGH-IJKL)
    return code.match(/.{1,4}/g).join('-');
  }
  
  // Generate multiple vouchers for a plan
  static async generateBatch(planId, quantity, expiryDays, createdBy) {
    const vouchers = [];
    const now = new Date();
    const expiryDate = new Date(now.getTime() + (expiryDays * 24 * 60 * 60 * 1000));
    
    for (let i = 0; i < quantity; i++) {
      vouchers.push({
        id: uuidv4(),
        code: this.generateCode(),
        plan_id: planId,
        created_by: createdBy,
        expiry_date: expiryDate,
        status: 'active'
      });
    }
    
    return await Voucher.bulkCreate(vouchers);
  }
}

Voucher.init(
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    code: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
      validate: {
        notEmpty: true
      }
    },
    plan_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'plans',
        key: 'id'
      }
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: true,
      references: {
        model: 'users',
        key: 'id'
      },
      comment: 'User who redeemed this voucher'
    },
    created_by: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      },
      comment: 'Admin who created this voucher'
    },
    status: {
      type: DataTypes.ENUM('active', 'used', 'expired', 'disabled'),
      allowNull: false,
      defaultValue: 'active'
    },
    redeemed_at: {
      type: DataTypes.DATE,
      allowNull: true,
      comment: 'When the voucher was redeemed'
    },
    redeemed_by: {
      type: DataTypes.STRING,
      allowNull: true,
      comment: 'MAC address of the device that redeemed this voucher'
    },
    expiry_date: {
      type: DataTypes.DATE,
      allowNull: false,
      comment: 'When the voucher expires'
    },
    mikrotik_username: {
      type: DataTypes.STRING,
      allowNull: true,
      comment: 'MikroTik hotspot username created for this voucher'
    },
    mikrotik_password: {
      type: DataTypes.STRING,
      allowNull: true,
      comment: 'MikroTik hotspot password created for this voucher'
    },
    batch_id: {
      type: DataTypes.STRING,
      allowNull: true,
      comment: 'Batch identifier for bulk-generated vouchers'
    },
    notes: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  },
  {
    sequelize,
    modelName: 'Voucher',
    tableName: 'vouchers',
    hooks: {
      afterCreate: async (voucher) => {
        // Log voucher creation
        console.log(`Voucher created: ${voucher.code}`);
      },
      afterUpdate: async (voucher) => {
        // If voucher status changed to 'used', create MikroTik hotspot user
        if (voucher.changed('status') && voucher.status === 'used' && voucher.user_id) {
          try {
            const MikroTikService = require('../services/MikroTikService');
            const Plan = require('./Plan');
            const plan = await Plan.findByPk(voucher.plan_id);
            
            if (plan) {
              // Generate MikroTik credentials
              const username = `voucher_${voucher.id.substring(0, 8)}`;
              const password = crypto.randomBytes(4).toString('hex');
              
              // Create MikroTik hotspot user
              await MikroTikService.createHotspotUser({
                username,
                password,
                profile: plan.mikrotik_profile,
                limit_uptime: `${plan.duration}h`,
                comment: `Voucher: ${voucher.code}`
              });
              
              // Update voucher with MikroTik credentials
              await voucher.update({
                mikrotik_username: username,
                mikrotik_password: password
              });
              
              // Send credentials to user via SMS if phone number is available
              const User = require('./User');
              const user = await User.findByPk(voucher.user_id);
              
              if (user && user.phone) {
                const TwilioService = require('../services/TwilioService');
                await TwilioService.sendSMS(
                  user.phone,
                  `Your internet access credentials:\nUsername: ${username}\nPassword: ${password}\nValid for: ${plan.duration} hours`
                );
              }
            }
          } catch (error) {
            console.error('Error processing voucher activation:', error);
          }
        }
      }
    }
  }
);

module.exports = Voucher;