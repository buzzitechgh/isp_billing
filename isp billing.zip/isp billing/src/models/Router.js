const { DataTypes, Model } = require('sequelize');
const { sequelize } = require('../database/config');
const crypto = require('crypto');

class Router extends Model {
  // Test connection to the router
  async testConnection() {
    try {
      const MikroTikService = require('../services/MikroTikService');
      const connection = await MikroTikService.connect({
        host: this.ip_address,
        port: this.port,
        username: this.username,
        password: this.decryptPassword()
      });
      
      await connection.close();
      return { success: true, message: 'Connection successful' };
    } catch (error) {
      return { success: false, message: error.message };
    }
  }
  
  // Encrypt router password before saving
  encryptPassword(password) {
    const algorithm = 'aes-256-cbc';
    const key = Buffer.from(process.env.JWT_SECRET.padEnd(32, '0').slice(0, 32));
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv(algorithm, key, iv);
    
    let encrypted = cipher.update(password, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    return `${iv.toString('hex')}:${encrypted}`;
  }
  
  // Decrypt router password
  decryptPassword() {
    try {
      const algorithm = 'aes-256-cbc';
      const key = Buffer.from(process.env.JWT_SECRET.padEnd(32, '0').slice(0, 32));
      
      const parts = this.password.split(':');
      const iv = Buffer.from(parts[0], 'hex');
      const encryptedText = parts[1];
      
      const decipher = crypto.createDecipheriv(algorithm, key, iv);
      
      let decrypted = decipher.update(encryptedText, 'hex', 'utf8');
      decrypted += decipher.final('utf8');
      
      return decrypted;
    } catch (error) {
      console.error('Error decrypting password:', error);
      return '';
    }
  }
}

Router.init(
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        notEmpty: true
      }
    },
    description: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    ip_address: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        isIP: true
      }
    },
    port: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 8728,
      validate: {
        min: 1,
        max: 65535
      }
    },
    username: {
      type: DataTypes.STRING,
      allowNull: false
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false
    },
    api_ssl: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    hotspot_server: {
      type: DataTypes.STRING,
      allowNull: true,
      comment: 'MikroTik hotspot server name'
    },
    dns_name: {
      type: DataTypes.STRING,
      allowNull: true,
      comment: 'DNS name for the router'
    },
    location: {
      type: DataTypes.STRING,
      allowNull: true
    },
    is_active: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    },
    last_sync: {
      type: DataTypes.DATE,
      allowNull: true
    },
    sync_status: {
      type: DataTypes.ENUM('success', 'failed', 'pending', 'never'),
      defaultValue: 'never'
    },
    sync_error: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    config: {
      type: DataTypes.JSON,
      allowNull: true,
      comment: 'Additional router configuration'
    }
  },
  {
    sequelize,
    modelName: 'Router',
    tableName: 'routers',
    hooks: {
      beforeCreate: async (router) => {
        // Encrypt password before saving
        if (router.password) {
          router.password = router.encryptPassword(router.password);
        }
      },
      beforeUpdate: async (router) => {
        // Encrypt password if changed
        if (router.changed('password')) {
          router.password = router.encryptPassword(router.password);
        }
      },
      afterCreate: async (router) => {
        // Test connection after creating router
        try {
          const result = await router.testConnection();
          await router.update({
            sync_status: result.success ? 'success' : 'failed',
            sync_error: result.success ? null : result.message,
            last_sync: new Date()
          });
        } catch (error) {
          console.error('Error testing router connection:', error);
        }
      }
    }
  }
);

module.exports = Router;