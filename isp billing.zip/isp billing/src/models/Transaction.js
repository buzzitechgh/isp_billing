const { DataTypes, Model } = require('sequelize');
const { sequelize } = require('../database/config');

class Transaction extends Model {}

Transaction.init(
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      }
    },
    plan_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'plans',
        key: 'id'
      }
    },
    amount: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false,
      validate: {
        min: 0
      }
    },
    payment_method: {
      type: DataTypes.ENUM('paystack', 'cash', 'bank_transfer', 'voucher', 'other'),
      allowNull: false
    },
    status: {
      type: DataTypes.ENUM('pending', 'completed', 'failed', 'refunded'),
      allowNull: false,
      defaultValue: 'pending'
    },
    reference: {
      type: DataTypes.STRING,
      allowNull: true,
      comment: 'Payment reference or transaction ID'
    },
    payment_gateway_response: {
      type: DataTypes.JSON,
      allowNull: true,
      comment: 'Full response from payment gateway'
    },
    receipt_number: {
      type: DataTypes.STRING,
      allowNull: true,
      unique: true
    },
    notes: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    processed_by: {
      type: DataTypes.UUID,
      allowNull: true,
      references: {
        model: 'users',
        key: 'id'
      },
      comment: 'Admin who processed this transaction (for manual payments)'
    },
    voucher_id: {
      type: DataTypes.UUID,
      allowNull: true,
      references: {
        model: 'vouchers',
        key: 'id'
      },
      comment: 'If payment was made using a voucher'
    },
    start_date: {
      type: DataTypes.DATE,
      allowNull: true,
      comment: 'When the plan starts'
    },
    end_date: {
      type: DataTypes.DATE,
      allowNull: true,
      comment: 'When the plan expires'
    }
  },
  {
    sequelize,
    modelName: 'Transaction',
    tableName: 'transactions',
    hooks: {
      beforeCreate: async (transaction) => {
        // Generate receipt number
        const prefix = 'RCP';
        const timestamp = Date.now().toString().slice(-8);
        const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
        transaction.receipt_number = `${prefix}${timestamp}${random}`;
      },
      afterCreate: async (transaction) => {
        // Log transaction creation
        console.log(`Transaction created: ${transaction.id}, Amount: ${transaction.amount}`);
      },
      afterUpdate: async (transaction) => {
        // If transaction status changed to 'completed', process the plan activation
        if (transaction.changed('status') && transaction.status === 'completed') {
          try {
            // Get the plan details
            const Plan = require('./Plan');
            const plan = await Plan.findByPk(transaction.plan_id);
            
            if (plan) {
              // Calculate plan start and end dates
              const startDate = new Date();
              const endDate = new Date(startDate.getTime() + (plan.duration * 60 * 60 * 1000));
              
              // Update transaction with plan dates
              await transaction.update({
                start_date: startDate,
                end_date: endDate
              });
              
              // Create or update MikroTik hotspot user for this plan
              const User = require('./User');
              const user = await User.findByPk(transaction.user_id);
              
              if (user) {
                const MikroTikService = require('../services/MikroTikService');
                const username = `user_${user.id.substring(0, 8)}`;
                
                // Create or update MikroTik hotspot user
                await MikroTikService.createOrUpdateHotspotUser({
                  username,
                  profile: plan.mikrotik_profile,
                  limit_uptime: `${plan.duration}h`,
                  comment: `User: ${user.username}, Plan: ${plan.name}`
                });
                
                // Send confirmation SMS
                if (user.phone) {
                  const TwilioService = require('../services/TwilioService');
                  await TwilioService.sendSMS(
                    user.phone,
                    `Your payment of ${transaction.amount} for ${plan.name} plan has been confirmed. Valid until: ${endDate.toLocaleString()}`
                  );
                }
                
                // Create notification
                const Notification = require('./Notification');
                await Notification.create({
                  user_id: user.id,
                  title: 'Payment Confirmed',
                  message: `Your payment of ${transaction.amount} for ${plan.name} plan has been confirmed. Valid until: ${endDate.toLocaleString()}`,
                  type: 'payment'
                });
              }
            }
          } catch (error) {
            console.error('Error processing completed transaction:', error);
          }
        }
      }
    }
  }
);

module.exports = Transaction;