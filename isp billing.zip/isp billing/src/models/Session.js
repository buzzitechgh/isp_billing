const { DataTypes, Model } = require('sequelize');
const { sequelize } = require('../database/config');

class Session extends Model {}

Session.init(
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: true,
      references: {
        model: 'users',
        key: 'id'
      },
      comment: 'Can be null for anonymous hotspot users'
    },
    router_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'routers',
        key: 'id'
      }
    },
    mikrotik_session_id: {
      type: DataTypes.STRING,
      allowNull: true,
      comment: 'MikroTik active session ID'
    },
    ip_address: {
      type: DataTypes.STRING,
      allowNull: true
    },
    mac_address: {
      type: DataTypes.STRING,
      allowNull: true
    },
    username: {
      type: DataTypes.STRING,
      allowNull: false,
      comment: 'MikroTik hotspot username'
    },
    start_time: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW
    },
    end_time: {
      type: DataTypes.DATE,
      allowNull: true
    },
    duration: {
      type: DataTypes.INTEGER,
      allowNull: true,
      comment: 'Session duration in seconds'
    },
    bytes_in: {
      type: DataTypes.BIGINT,
      allowNull: false,
      defaultValue: 0,
      comment: 'Downloaded bytes'
    },
    bytes_out: {
      type: DataTypes.BIGINT,
      allowNull: false,
      defaultValue: 0,
      comment: 'Uploaded bytes'
    },
    status: {
      type: DataTypes.ENUM('active', 'ended', 'terminated'),
      allowNull: false,
      defaultValue: 'active'
    },
    is_trial: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
      comment: 'Indicates if this is a free trial session'
    },
    plan_id: {
      type: DataTypes.UUID,
      allowNull: true,
      references: {
        model: 'plans',
        key: 'id'
      },
      comment: 'Associated plan (null for free trials)'
    },
    voucher_id: {
      type: DataTypes.UUID,
      allowNull: true,
      references: {
        model: 'vouchers',
        key: 'id'
      },
      comment: 'Associated voucher (if applicable)'
    },
    termination_reason: {
      type: DataTypes.STRING,
      allowNull: true,
      comment: 'Reason for session termination'
    },
    device_info: {
      type: DataTypes.JSON,
      allowNull: true,
      comment: 'Client device information'
    },
    location: {
      type: DataTypes.JSON,
      allowNull: true,
      comment: 'Geographic location data'
    }
  },
  {
    sequelize,
    modelName: 'Session',
    tableName: 'sessions',
    hooks: {
      afterCreate: async (session) => {
        // Log session start
        console.log(`Session started: ${session.id}, User: ${session.user_id}`);
      },
      afterUpdate: async (session) => {
        // If session status changed to 'ended' or 'terminated', calculate duration
        if (session.changed('status') && 
            (session.status === 'ended' || session.status === 'terminated') && 
            session.end_time) {
          try {
            // Calculate session duration
            const startTime = new Date(session.start_time).getTime();
            const endTime = new Date(session.end_time).getTime();
            const durationSeconds = Math.floor((endTime - startTime) / 1000);
            
            // Update session with duration
            await session.update({ duration: durationSeconds });
            
            // Log session end
            console.log(`Session ended: ${session.id}, Duration: ${durationSeconds} seconds`);
            
            // Update user's data usage statistics
            const User = require('./User');
            const user = await User.findByPk(session.user_id);
            
            if (user) {
              // You could update user's total data usage or other statistics here
              console.log(`Updated data usage for user: ${user.username}`);
            }
          } catch (error) {
            console.error('Error processing ended session:', error);
          }
        }
      }
    }
  }
);

module.exports = Session;