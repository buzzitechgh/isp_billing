const { DataTypes, Model } = require('sequelize');
const { sequelize } = require('../database/config');

class Notification extends Model {}

Notification.init(
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    user_id: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      }
    },
    title: {
      type: DataTypes.STRING,
      allowNull: false
    },
    message: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    type: {
      type: DataTypes.ENUM('payment', 'system', 'plan', 'session', 'alert'),
      allowNull: false,
      defaultValue: 'system'
    },
    is_read: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    read_at: {
      type: DataTypes.DATE,
      allowNull: true
    },
    action_url: {
      type: DataTypes.STRING,
      allowNull: true,
      comment: 'URL to redirect when notification is clicked'
    },
    icon: {
      type: DataTypes.STRING,
      allowNull: true,
      comment: 'Icon class for the notification'
    },
    priority: {
      type: DataTypes.ENUM('low', 'normal', 'high'),
      defaultValue: 'normal'
    },
    sms_sent: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
      comment: 'Whether SMS notification was sent'
    },
    email_sent: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
      comment: 'Whether email notification was sent'
    },
    metadata: {
      type: DataTypes.JSON,
      allowNull: true,
      comment: 'Additional data related to the notification'
    }
  },
  {
    sequelize,
    modelName: 'Notification',
    tableName: 'notifications',
    hooks: {
      afterCreate: async (notification) => {
        // Send SMS for high priority notifications if configured
        if (notification.priority === 'high' && !notification.sms_sent) {
          try {
            const User = require('./User');
            const user = await User.findByPk(notification.user_id);
            
            if (user && user.phone) {
              const TwilioService = require('../services/TwilioService');
              await TwilioService.sendSMS(user.phone, `${notification.title}: ${notification.message}`);
              
              // Update notification to mark SMS as sent
              await notification.update({ sms_sent: true });
            }
          } catch (error) {
            console.error('Error sending notification SMS:', error);
          }
        }
        
        // Send email notification if configured
        if (!notification.email_sent) {
          try {
            const User = require('./User');
            const user = await User.findByPk(notification.user_id);
            
            if (user && user.email) {
              const EmailService = require('../services/EmailService');
              await EmailService.sendEmail({
                to: user.email,
                subject: notification.title,
                text: notification.message,
                html: `<h3>${notification.title}</h3><p>${notification.message}</p>`
              });
              
              // Update notification to mark email as sent
              await notification.update({ email_sent: true });
            }
          } catch (error) {
            console.error('Error sending notification email:', error);
          }
        }
      }
    }
  }
);

module.exports = Notification;