const { DataTypes, Model } = require('sequelize');
const { sequelize } = require('../database/config');

class Plan extends Model {}

Plan.init(
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        notEmpty: true
      }
    },
    description: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    type: {
      type: DataTypes.ENUM('hourly', 'daily', 'weekly', 'monthly', 'yearly'),
      allowNull: false,
      defaultValue: 'monthly'
    },
    price: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false,
      validate: {
        min: 0
      }
    },
    duration: {
      type: DataTypes.INTEGER,
      allowNull: false,
      comment: 'Duration in hours'
    },
    data_limit: {
      type: DataTypes.BIGINT,
      allowNull: true,
      comment: 'Data limit in bytes, null means unlimited'
    },
    download_speed: {
      type: DataTypes.INTEGER,
      allowNull: false,
      comment: 'Download speed in kbps'
    },
    upload_speed: {
      type: DataTypes.INTEGER,
      allowNull: false,
      comment: 'Upload speed in kbps'
    },
    simultaneous_use: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 1,
      comment: 'Number of devices that can use this plan simultaneously'
    },
    is_active: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    },
    mikrotik_profile: {
      type: DataTypes.STRING,
      allowNull: true,
      comment: 'MikroTik hotspot user profile name'
    },
    shared_users: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 1,
      comment: 'Number of users sharing the bandwidth'
    },
    burst_limit: {
      type: DataTypes.JSON,
      allowNull: true,
      comment: 'Burst limit configuration for MikroTik'
    },
    priority: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 8,
      validate: {
        min: 1,
        max: 8
      },
      comment: 'Priority level (1-8, where 1 is highest)'
    },
    is_public: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
      comment: 'Whether this plan is visible on the public hotspot page'
    }
  },
  {
    sequelize,
    modelName: 'Plan',
    tableName: 'plans',
    hooks: {
      afterCreate: async (plan) => {
        // Create corresponding MikroTik profile if it doesn't exist
        try {
          const MikroTikService = require('../services/MikroTikService');
          await MikroTikService.createHotspotUserProfile(plan);
        } catch (error) {
          console.error('Error creating MikroTik profile:', error);
        }
      },
      afterUpdate: async (plan) => {
        // Update corresponding MikroTik profile if plan is modified
        if (plan.changed('download_speed') || 
            plan.changed('upload_speed') || 
            plan.changed('data_limit') || 
            plan.changed('burst_limit') || 
            plan.changed('priority')) {
          try {
            const MikroTikService = require('../services/MikroTikService');
            await MikroTikService.updateHotspotUserProfile(plan);
          } catch (error) {
            console.error('Error updating MikroTik profile:', error);
          }
        }
      }
    }
  }
);

module.exports = Plan;