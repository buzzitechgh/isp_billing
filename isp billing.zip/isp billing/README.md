# ISP Billing System with MikroTik Hotspot Integration

A comprehensive billing solution for ISPs with MikroTik hotspot integration, Paystack payment processing, and Twilio SMS notifications.

## Key Features

### User Management
- Secure user registration and login with role-based access
- Voucher and free trial functionality with automated activation
- User dashboard for plan balance, active sessions, and purchase history

### Payment & Billing
- Paystack payment gateway integration
- Automated payment confirmation and receipt generation
- Admin dashboard for sales tracking and revenue monitoring

### MikroTik Hotspot Integration
- Auto-sync hotspot plans with MikroTik router
- Dynamic hotspot file generation for bandwidth and session management
- Auto-detection of active sessions for seamless reconnection

### Notifications & Alerts
- Twilio SMS gateway for sending login credentials
- Automated overdue plan notifications
- Real-time alerts for online/offline users

### Admin & Backend Features
- Complete user, plan, and session management
- MikroTik router integration for real-time monitoring
- Backup and restore functionality
- Sales analytics and reporting

### UI/UX Enhancements
- Animated WiFi signal strength indicator
- Clear purchase instructions
- Responsive design

## Installation

1. Clone the repository
2. Install dependencies with `npm install`
3. Configure environment variables
4. Run database migrations
5. Start the application with `npm start`

## Technologies Used

- Node.js and Express for backend
- React for frontend
- MySQL for database
- MikroTik API for router integration
- Paystack API for payment processing
- Twilio API for SMS notifications

## License

MIT